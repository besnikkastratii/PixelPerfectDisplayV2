package com.besnik.pixelperfect;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Charging diagnostics; USB data function refresh is manual and cannot reset USB PD hardware. */
public final class UsbChargingRecovery {
    private final Context context;
    private final SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private final BatteryManager batteryManager;
    private TextView status, history;
    private BroadcastReceiver receiver;
    private int lastPlugged = -1;
    private long lastChange;
    public UsbChargingRecovery(Context context) {
        this.context = context;
        prefs = context.getSharedPreferences("vpq_usb_charging", Context.MODE_PRIVATE);
        batteryManager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
    }
    public View buildView() {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        TextView title = new TextView(context);
        title.setText("USB Charging Recovery • V4.5"); title.setTextSize(18); title.setTextColor(0xFFC8A96B);
        card.addView(title);
        status = new TextView(context);
        status.setTextColor(0xFFF4F1EA); status.setTextSize(14);
        status.setPadding(0, 12, 0, 12);
        card.addView(status);
        history = new TextView(context);
        history.setTextColor(0xFFA5A19A);
        history.setTextSize(12);
        card.addView(history);
        Button refresh = new Button(context);
        refresh.setText("Manual USB Functions Refresh (Shizuku)");
        card.addView(refresh);
        TextView note = new TextView(context);
        note.setText("Refreshes Android USB data functions only. Cannot repair an incompatible cable or reset USB-PD charging. No automatic resets.");
        note.setTextSize(12); note.setTextColor(0xFFA5A19A);
        card.addView(note);
        refresh.setOnClickListener(v -> new AlertDialog.Builder(context)
            .setTitle("Attempt USB data refresh?")
            .setMessage("This may disconnect USB accessories. It does not guarantee a charging fix. Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue", (dialog, which) -> {
                refresh.setEnabled(false);
                work.execute(() -> {
                    String output;
                    try { output = ShizukuBridge.exec("svc usb setFunctions", 6000); }
                    catch (Exception e) { output = "Unavailable: " + e.getMessage(); }
                    final String result = output == null || output.isEmpty() ? "Command requested; observe charging manually." : output;
                    main.post(() -> {refresh.setEnabled(true); new AlertDialog.Builder(context)
                        .setTitle("USB refresh result").setMessage(result).setPositiveButton("OK", null).show();});
                });
            }).show());
        showHistory();
        update(null);
        return card;
    }
    public void start() {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent intent) { update(intent); }
        };
        context.registerReceiver(receiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }
    public void stop() {
        if (receiver != null) { try { context.unregisterReceiver(receiver); } catch (Exception ignored) {} receiver = null; }
    }
    private void showHistory() {
        if (history != null) history.setText("Last events:\n" + prefs.getString("events", "No interruptions recorded"));
    }
    private void update(Intent broadcast) {
        Intent battery = broadcast == null ? context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)) : broadcast;
        if (battery == null) return;
        int plugged = battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        int mv = battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        int current = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
        long now = android.os.SystemClock.elapsedRealtime();
        if (lastPlugged >= 0 && (plugged == 0) != (lastPlugged == 0) && now - lastChange > 600) {
            String item = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date()) +
                    (plugged == 0 ? "  DISCONNECTED" : "  CONNECTED");
            String older = prefs.getString("events", "");
            String combined = item + "\n" + older;
            if (combined.length() > 1500) combined = combined.substring(0, 1500);
            prefs.edit().putString("events", combined).apply();
            showHistory();
            lastChange = now;
        }
        lastPlugged = plugged;
        if (status != null) status.setText("Power: " + (plugged == 0 ? "Disconnected" : "Connected") +
            "\nBattery: " + (scale > 0 && level >= 0 ? (level * 100 / scale) + "%" : "N/A") +
            "  |  " + (temp < 0 ? "N/A" : (temp / 10f) + "°C") +
            "\nBattery voltage: " + (mv < 0 ? "N/A" : mv + " mV") +
            "\nBattery current: " + (current == Integer.MIN_VALUE ? "N/A" : current / 1000 + " mA") +
            " (not charger input)");
    }
}
