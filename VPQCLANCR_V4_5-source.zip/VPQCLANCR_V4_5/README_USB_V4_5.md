# VPQCLAN C.R V4.5 — USB Charging Recovery

Added to MainActivity below Diagnostics: charging status, battery current/voltage/temperature, persistent connection event history, and a confirmation-gated Shizuku `svc usb setFunctions` request. No automated USB controller resets.

The recovery command refreshes Android USB **data functions** only, not USB Power Delivery or charger negotiation. Not a guaranteed remedy for cable-specific dropouts.

The charging monitor operates while the activity is open. History persists across launches.

Build through GitHub Actions with `VPQCLANCR_V4_5-source.zip` at repository root and the companion workflow `build-apk.yml` under `.github/workflows/`.
