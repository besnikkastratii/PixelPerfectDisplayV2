package com.besnik.pixelperfect;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.InputType;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity implements DisplayManager.DisplayListener {

    private static final int REQ_SHIZUKU = 4102;
    private static final long SAFETY_MS = 15_000L;
    private static final String PREFS = "vpqclan_cr_v4";
    private static final String KEY_PROFILES = "profiles_json";

    private static final int BG = Color.parseColor("#0F1011");
    private static final int CARD = Color.parseColor("#17181A");
    private static final int FIELD = Color.parseColor("#202225");
    private static final int FIELD_2 = Color.parseColor("#25272A");
    private static final int TEXT = Color.parseColor("#F4F1EA");
    private static final int MUTED = Color.parseColor("#A5A19A");
    private static final int ACCENT = Color.parseColor("#C8A96B");
    private static final int ACCENT_DARK = Color.parseColor("#6F5D3D");
    private static final int BORDER = Color.parseColor("#303236");
    private static final int DANGER = Color.parseColor("#8A4D4D");

    private static final BuiltInPreset[] BUILT_INS = new BuiltInPreset[] {
            new BuiltInPreset("iPad View Classic", 1536, 2048, 420, "4:3 tablet-style view"),
            new BuiltInPreset("iPad View Plus", 1728, 2304, 440, "Stronger 4:3 tablet-style view"),
            new BuiltInPreset("Tablet View Safe", 1440, 1920, 420, "Safer 4:3-style preset"),
            new BuiltInPreset("Balanced 16:10", 1200, 1920, 420, "Your original stable style"),
            new BuiltInPreset("Balanced 3:2", 1440, 2160, 440, "Tall tablet-style preset"),
            new BuiltInPreset("16:9 Clean", 1080, 1920, 420, "Standard 16:9-style render")
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private TextView status;
    private TextView presetHint;
    private TextView displayInfo;
    private TextView safetyText;
    private TextView logView;

    private Spinner presetSpinner;
    private Spinner displaySpinner;
    private Spinner modeSpinner;

    private EditText profileName;
    private EditText phoneWidth;
    private EditText phoneHeight;
    private EditText phoneDensity;
    private EditText externalWidth;
    private EditText externalHeight;
    private EditText externalHz;
    private EditText externalDensity;

    private Button keepButton;
    private Button diagnosticsButton;

    private DisplayManager displayManager;
    private final List<Display> displayList = new ArrayList<>();
    private final List<Display.Mode> modeList = new ArrayList<>();
    private final List<PresetEntry> presetEntries = new ArrayList<>();

    private IUserService shellService;
    private boolean binding;
    private RevertState pendingRevert;
    private Runnable autoRevertRunnable;
    private long safetyDeadline;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::onShizukuBinderReady;
    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> runOnUiThread(() -> {
        shellService = null;
        binding = false;
        setStatus("Shizuku stopped — start it again and return here.", DANGER);
    });

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_SHIZUKU) return;
        runOnUiThread(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setStatus("Connecting to Shizuku…", ACCENT);
                bindShellService();
            } else {
                setStatus("Shizuku permission denied.", DANGER);
            }
        });
    };

    private final Shizuku.UserServiceArgs serviceArgs = new Shizuku.UserServiceArgs(
            new ComponentName(BuildConfig.APPLICATION_ID, UserService.class.getName()))
            .daemon(false)
            .processNameSuffix("vpqclan-cr-v4")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
            .tag("vpqclan-cr-v4");

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            runOnUiThread(() -> {
                binding = false;
                if (binder != null && binder.pingBinder()) {
                    shellService = IUserService.Stub.asInterface(binder);
                    setStatus("Ready", ACCENT);
                    appendLog("Shizuku service connected.");
                } else {
                    shellService = null;
                    setStatus("Privileged service unavailable.", DANGER);
                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            runOnUiThread(() -> {
                shellService = null;
                binding = false;
                setStatus("Shizuku disconnected.", DANGER);
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        displayManager.registerDisplayListener(this, main);

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionListener);

        presetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyPresetSelection(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        displaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshModes();
                fillExternalFromSelectedMode();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        refreshPresetDropdown(null);
        refreshDisplays();
        ensureShizuku();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        displayManager.unregisterDisplayListener(this);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        cancelSafetyCountdown(false);
        try {
            if (binding || shellService != null) {
                Shizuku.unbindUserService(serviceArgs, serviceConnection, true);
            }
        } catch (Throwable ignored) { }
        worker.shutdownNow();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(26));
        root.setBackgroundColor(BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(buildHeader(), matchWithBottom(14));
        root.addView(buildStatusCard(), matchWithBottom(14));
        root.addView(buildGameCard(), matchWithBottom(14));
        root.addView(buildMonitorCard(), matchWithBottom(14));
        root.addView(buildSafetyCard(), matchWithBottom(14));
        root.addView(buildDiagnosticsCard(), matchWithBottom(14));

        TextView footer = label("This App is part of VPQCLAN, made by VPQ SNIKA", 12, true, MUTED);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(0, dp(6), 0, 0);
        root.addView(footer, match());

        return scroll;
    }

    private View buildHeader() {
        LinearLayout box = vertical();
        box.setPadding(dp(2), dp(4), dp(2), dp(4));

        TextView brand = label("VPQCLAN Custom Resolution", 26, true, TEXT);
        box.addView(brand, match());

        TextView app = label("VPQCLAN C.R  •  V4", 13, true, ACCENT);
        app.setPadding(0, dp(4), 0, dp(5));
        box.addView(app, match());

        TextView sub = label("Game view and monitor output are now completely separate.", 13, false, MUTED);
        box.addView(sub, match());
        return box;
    }

    private View buildStatusCard() {
        LinearLayout card = card();
        LinearLayout row = row();
        LinearLayout textCol = vertical();
        textCol.setPadding(0, 0, dp(8), 0);

        TextView title = label("Shizuku", 14, true, TEXT);
        textCol.addView(title);
        status = label("Checking…", 13, true, MUTED);
        textCol.addView(status);
        row.addView(textCol, weight());

        Button connect = button("Connect", false);
        connect.setOnClickListener(v -> ensureShizuku());
        row.addView(connect, wrap());
        card.addView(row, match());
        return card;
    }

    private View buildGameCard() {
        LinearLayout card = card();
        sectionTitle(card, "Game View");
        mutedText(card, "Choose a built-in preset or one of your saved custom profiles.");

        presetSpinner = spinner();
        card.addView(presetSpinner, matchWithTop(10));
        presetHint = label("", 12, false, MUTED);
        presetHint.setPadding(dp(2), dp(6), dp(2), 0);
        card.addView(presetHint, match());

        miniTitle(card, "Resolution");
        LinearLayout size = row();
        phoneWidth = numberField("Width", "1536");
        phoneHeight = numberField("Height", "2048");
        size.addView(phoneWidth, weight());
        size.addView(phoneHeight, weight());
        card.addView(size, match());

        phoneDensity = numberField("DPI (optional)", "420");
        card.addView(phoneDensity, matchWithTop(8));

        LinearLayout gameActions = row();
        Button applyGame = button("Apply Game View", true);
        applyGame.setOnClickListener(v -> applyPhoneCustom());
        gameActions.addView(applyGame, weight());

        Button resetGame = button("Reset", false);
        resetGame.setOnClickListener(v -> runCommands("Reset game view", Arrays.asList(
                "wm size reset -d 0",
                "wm density reset -d 0",
                "wm scaling auto -d 0")));
        gameActions.addView(resetGame, weight());
        card.addView(gameActions, matchWithTop(8));

        divider(card);
        miniTitle(card, "Save Custom Profile");
        profileName = textField("Profile name", "");
        card.addView(profileName, match());

        LinearLayout profileActions = row();
        Button save = button("Save / Update", true);
        save.setOnClickListener(v -> saveProfile());
        profileActions.addView(save, weight());

        Button delete = button("Delete Selected", false);
        delete.setTextColor(Color.parseColor("#E0A0A0"));
        delete.setOnClickListener(v -> deleteSelectedProfile());
        profileActions.addView(delete, weight());
        card.addView(profileActions, matchWithTop(8));

        return card;
    }

    private View buildMonitorCard() {
        LinearLayout card = card();
        sectionTitle(card, "Monitor Output");
        mutedText(card, "Changing monitor settings will no longer change your game-view resolution.");

        displaySpinner = spinner();
        card.addView(displaySpinner, matchWithTop(10));

        displayInfo = label("No display selected", 12, false, MUTED);
        displayInfo.setPadding(dp(2), dp(6), dp(2), dp(6));
        card.addView(displayInfo, match());

        modeSpinner = spinner();
        card.addView(modeSpinner, match());

        LinearLayout quick = row();
        Button best = button("Best Quality", false);
        best.setOnClickListener(v -> selectBestQuality());
        quick.addView(best, weight());

        Button best120 = button("Best ≥120 Hz", false);
        best120.setOnClickListener(v -> selectBest120());
        quick.addView(best120, weight());
        card.addView(quick, matchWithTop(8));

        Button applySelected = button("Apply Selected Monitor Mode", true);
        applySelected.setOnClickListener(v -> applySelectedExternalMode());
        card.addView(applySelected, matchWithTop(8));

        divider(card);
        miniTitle(card, "Custom Monitor Mode");

        LinearLayout extSize = row();
        externalWidth = numberField("Width", "1920");
        externalHeight = numberField("Height", "1080");
        extSize.addView(externalWidth, weight());
        extSize.addView(externalHeight, weight());
        card.addView(extSize, match());

        LinearLayout extMeta = row();
        externalHz = decimalField("Hz", "120");
        externalDensity = numberField("DPI (optional)", "");
        extMeta.addView(externalHz, weight());
        extMeta.addView(externalDensity, weight());
        card.addView(extMeta, matchWithTop(8));

        LinearLayout customActions = row();
        Button copy = button("Use Selected", false);
        copy.setOnClickListener(v -> fillExternalFromSelectedMode());
        customActions.addView(copy, weight());

        Button applyCustom = button("Apply Custom", true);
        applyCustom.setOnClickListener(v -> applyCustomExternalMode());
        customActions.addView(applyCustom, weight());
        card.addView(customActions, matchWithTop(8));

        Button restoreMonitor = button("Restore Monitor Defaults", false);
        restoreMonitor.setOnClickListener(v -> restoreSelectedExternal());
        card.addView(restoreMonitor, matchWithTop(8));

        return card;
    }

    private View buildSafetyCard() {
        LinearLayout card = card();
        sectionTitle(card, "Safety");
        safetyText = label("Safety rollback: inactive", 13, true, MUTED);
        card.addView(safetyText, match());

        keepButton = button("KEEP NEW MONITOR MODE", true);
        keepButton.setEnabled(false);
        keepButton.setAlpha(0.5f);
        keepButton.setOnClickListener(v -> cancelSafetyCountdown(true));
        card.addView(keepButton, matchWithTop(8));

        Button restoreAll = button("Restore Everything", false);
        restoreAll.setTextColor(Color.parseColor("#E0A0A0"));
        restoreAll.setOnClickListener(v -> restoreAllDefaults());
        card.addView(restoreAll, matchWithTop(8));
        return card;
    }

    private View buildDiagnosticsCard() {
        LinearLayout card = card();
        diagnosticsButton = button("Show Diagnostics", false);
        diagnosticsButton.setOnClickListener(v -> {
            boolean show = logView.getVisibility() != View.VISIBLE;
            logView.setVisibility(show ? View.VISIBLE : View.GONE);
            diagnosticsButton.setText(show ? "Hide Diagnostics" : "Show Diagnostics");
        });
        card.addView(diagnosticsButton, match());

        logView = label("", 11, false, MUTED);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(10), dp(10), dp(10), dp(10));
        logView.setBackground(rounded(FIELD, dp(12), BORDER));
        logView.setVisibility(View.GONE);
        card.addView(logView, matchWithTop(8));
        return card;
    }

    private void refreshPresetDropdown(String selectProfileName) {
        presetEntries.clear();
        List<SavedProfile> saved = loadProfiles();
        for (SavedProfile p : saved) {
            presetEntries.add(PresetEntry.saved(p));
        }
        for (BuiltInPreset p : BUILT_INS) {
            presetEntries.add(PresetEntry.builtIn(p));
        }

        List<String> labels = new ArrayList<>();
        int wanted = 0;
        for (int i = 0; i < presetEntries.size(); i++) {
            PresetEntry e = presetEntries.get(i);
            labels.add(e.saved ? "★  " + e.savedProfile.name : e.builtInPreset.name);
            if (selectProfileName != null && e.saved && e.savedProfile.name.equalsIgnoreCase(selectProfileName)) {
                wanted = i;
            }
        }
        presetSpinner.setAdapter(spinnerAdapter(labels));
        if (!labels.isEmpty()) presetSpinner.setSelection(Math.min(wanted, labels.size() - 1));
    }

    private void applyPresetSelection(int position) {
        if (position < 0 || position >= presetEntries.size()) return;
        PresetEntry e = presetEntries.get(position);
        if (e.saved) {
            SavedProfile p = e.savedProfile;
            profileName.setText(p.name);
            phoneWidth.setText(String.valueOf(p.phoneWidth));
            phoneHeight.setText(String.valueOf(p.phoneHeight));
            phoneDensity.setText(p.phoneDensity > 0 ? String.valueOf(p.phoneDensity) : "");
            externalWidth.setText(String.valueOf(p.externalWidth));
            externalHeight.setText(String.valueOf(p.externalHeight));
            externalHz.setText(trimFloat(p.externalHz));
            externalDensity.setText(p.externalDensity > 0 ? String.valueOf(p.externalDensity) : "");
            presetHint.setText("Saved profile • game + monitor values loaded");
            presetHint.setTextColor(ACCENT);
        } else {
            BuiltInPreset p = e.builtInPreset;
            profileName.setText("");
            phoneWidth.setText(String.valueOf(p.width));
            phoneHeight.setText(String.valueOf(p.height));
            phoneDensity.setText(String.valueOf(p.dpi));
            presetHint.setText(p.note + "  •  " + p.width + "×" + p.height + "  •  DPI " + p.dpi);
            presetHint.setTextColor(MUTED);
        }
    }

    private void saveProfile() {
        String name = profileName.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter a profile name first.", Toast.LENGTH_LONG).show();
            return;
        }

        Integer pw = parseInt(phoneWidth.getText().toString());
        Integer ph = parseInt(phoneHeight.getText().toString());
        Integer pd = parseOptionalInt(phoneDensity.getText().toString());
        Integer ew = parseInt(externalWidth.getText().toString());
        Integer eh = parseInt(externalHeight.getText().toString());
        Float hz = parseFloat(externalHz.getText().toString());
        Integer ed = parseOptionalInt(externalDensity.getText().toString());

        if (pw == null || ph == null || ew == null || eh == null || hz == null) {
            Toast.makeText(this, "Complete the resolution and Hz fields before saving.", Toast.LENGTH_LONG).show();
            return;
        }

        SavedProfile profile = new SavedProfile(name, pw, ph, pd == null ? 0 : pd,
                ew, eh, hz, ed == null ? 0 : ed);

        List<SavedProfile> profiles = loadProfiles();
        int existing = -1;
        for (int i = 0; i < profiles.size(); i++) {
            if (profiles.get(i).name.equalsIgnoreCase(name)) {
                existing = i;
                break;
            }
        }
        if (existing >= 0) profiles.set(existing, profile);
        else profiles.add(0, profile);

        saveProfiles(profiles);
        refreshPresetDropdown(name);
        Toast.makeText(this, existing >= 0 ? "Profile updated" : "Profile saved", Toast.LENGTH_SHORT).show();
    }

    private void deleteSelectedProfile() {
        int pos = presetSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= presetEntries.size()) return;
        PresetEntry e = presetEntries.get(pos);
        if (!e.saved) {
            Toast.makeText(this, "Built-in presets cannot be deleted.", Toast.LENGTH_LONG).show();
            return;
        }

        String name = e.savedProfile.name;
        List<SavedProfile> profiles = loadProfiles();
        profiles.removeIf(p -> p.name.equalsIgnoreCase(name));
        saveProfiles(profiles);
        profileName.setText("");
        refreshPresetDropdown(null);
        Toast.makeText(this, "Deleted: " + name, Toast.LENGTH_SHORT).show();
    }

    private List<SavedProfile> loadProfiles() {
        List<SavedProfile> out = new ArrayList<>();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PROFILES, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new SavedProfile(
                        o.optString("name", "Profile"),
                        o.optInt("phoneWidth", 1536),
                        o.optInt("phoneHeight", 2048),
                        o.optInt("phoneDensity", 420),
                        o.optInt("externalWidth", 1920),
                        o.optInt("externalHeight", 1080),
                        (float) o.optDouble("externalHz", 120.0),
                        o.optInt("externalDensity", 0)
                ));
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private void saveProfiles(List<SavedProfile> profiles) {
        JSONArray arr = new JSONArray();
        try {
            for (SavedProfile p : profiles) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("phoneWidth", p.phoneWidth);
                o.put("phoneHeight", p.phoneHeight);
                o.put("phoneDensity", p.phoneDensity);
                o.put("externalWidth", p.externalWidth);
                o.put("externalHeight", p.externalHeight);
                o.put("externalHz", p.externalHz);
                o.put("externalDensity", p.externalDensity);
                arr.put(o);
            }
        } catch (Throwable ignored) { }
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(KEY_PROFILES, arr.toString())
                .apply();
    }

    private void ensureShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                setStatus("Start Shizuku first", MUTED);
                return;
            }
            if (Shizuku.isPreV11()) {
                setStatus("Shizuku v11+ required", DANGER);
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Permission required", MUTED);
                Shizuku.requestPermission(REQ_SHIZUKU);
                return;
            }
            bindShellService();
        } catch (Throwable t) {
            setStatus("Shizuku error", DANGER);
            appendLog(String.valueOf(t));
        }
    }

    private void onShizukuBinderReady() {
        runOnUiThread(this::ensureShizuku);
    }

    private void bindShellService() {
        if (shellService != null || binding) return;
        try {
            binding = true;
            setStatus("Connecting…", MUTED);
            Shizuku.bindUserService(serviceArgs, serviceConnection);
        } catch (Throwable t) {
            binding = false;
            setStatus("Could not connect", DANGER);
            appendLog(String.valueOf(t));
        }
    }

    private void refreshDisplays() {
        displayList.clear();
        Display[] all = displayManager.getDisplays();
        Arrays.sort(all, (a, b) -> Integer.compare(
                a.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0,
                b.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0));
        displayList.addAll(Arrays.asList(all));

        List<String> labels = new ArrayList<>();
        for (Display d : displayList) {
            Display.Mode m = d.getMode();
            labels.add(String.format(Locale.US, "%s  •  %d×%d @ %.0f Hz%s",
                    d.getName(), m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    d.getDisplayId() == 0 ? "  (phone)" : ""));
        }
        if (labels.isEmpty()) labels.add("No displays found");
        displaySpinner.setAdapter(spinnerAdapter(labels));
        if (!displayList.isEmpty()) displaySpinner.setSelection(0);
        refreshModes();
    }

    private void refreshModes() {
        modeList.clear();
        Display d = selectedDisplay();
        if (d == null) {
            modeSpinner.setAdapter(spinnerAdapter(Collections.singletonList("No modes")));
            displayInfo.setText("No display selected");
            return;
        }

        Display.Mode active = d.getMode();
        List<Display.Mode> modes = new ArrayList<>(Arrays.asList(d.getSupportedModes()));
        modes.sort(Comparator
                .comparingLong((Display.Mode m) -> (long) m.getPhysicalWidth() * m.getPhysicalHeight()).reversed()
                .thenComparing(Comparator.comparingDouble(Display.Mode::getRefreshRate).reversed()));
        modeList.addAll(modes);

        List<String> labels = new ArrayList<>();
        int activeIndex = 0;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            boolean isActive = m.getModeId() == active.getModeId();
            if (isActive) activeIndex = i;
            labels.add(String.format(Locale.US, "%d×%d @ %.2f Hz%s",
                    m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    isActive ? "  • active" : ""));
        }
        modeSpinner.setAdapter(spinnerAdapter(labels));
        if (!modeList.isEmpty()) modeSpinner.setSelection(activeIndex);

        displayInfo.setText(String.format(Locale.US, "Display %d  •  %d supported mode(s)",
                d.getDisplayId(), modeList.size()));
    }

    private void fillExternalFromSelectedMode() {
        Display.Mode m = selectedMode();
        if (m == null) return;
        externalWidth.setText(String.valueOf(m.getPhysicalWidth()));
        externalHeight.setText(String.valueOf(m.getPhysicalHeight()));
        externalHz.setText(trimFloat(m.getRefreshRate()));
    }

    private void selectBestQuality() {
        if (modeList.isEmpty()) return;
        int best = 0;
        long bestPixels = -1;
        float bestHz = -1f;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            long pixels = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (pixels > bestPixels || (pixels == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = pixels;
                bestHz = m.getRefreshRate();
            }
        }
        modeSpinner.setSelection(best);
        fillExternalFromSelectedMode();
    }

    private void selectBest120() {
        int best = -1;
        long bestPixels = -1;
        float bestHz = -1f;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            if (m.getRefreshRate() < 119f) continue;
            long pixels = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (pixels > bestPixels || (pixels == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = pixels;
                bestHz = m.getRefreshRate();
            }
        }
        if (best < 0) {
            Toast.makeText(this, "No ≥120 Hz mode reported by this display.", Toast.LENGTH_LONG).show();
            return;
        }
        modeSpinner.setSelection(best);
        fillExternalFromSelectedMode();
    }

    private void applySelectedExternalMode() {
        Display d = selectedDisplay();
        Display.Mode m = selectedMode();
        if (d == null || m == null) return;
        if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_LONG).show();
            return;
        }
        applyExternalModeInternal(d.getDisplayId(), m.getPhysicalWidth(), m.getPhysicalHeight(),
                m.getRefreshRate(), externalDensity.getText().toString().trim());
    }

    private void applyCustomExternalMode() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_LONG).show();
            return;
        }
        Integer w = parseInt(externalWidth.getText().toString());
        Integer h = parseInt(externalHeight.getText().toString());
        Float hz = parseFloat(externalHz.getText().toString());
        if (w == null || h == null || hz == null || w < 640 || h < 480 || hz <= 0f) {
            Toast.makeText(this, "Enter valid monitor width, height and Hz.", Toast.LENGTH_LONG).show();
            return;
        }
        applyExternalModeInternal(d.getDisplayId(), w, h, hz,
                externalDensity.getText().toString().trim());
    }

    private void applyExternalModeInternal(int displayId, int w, int h, float hz, String dpiText) {
        if (!requireShell()) return;
        Integer density = parseOptionalInt(dpiText);
        worker.execute(() -> {
            try {
                RevertState state = captureRevertState(displayId);
                StringBuilder out = new StringBuilder();

                out.append(execPriv(String.format(Locale.US,
                        "cmd display set-user-preferred-display-mode %d %d %.3f %d",
                        w, h, hz, displayId))).append('\n');

                out.append(execPriv("wm size reset -d " + displayId)).append('\n');
                out.append(execPriv("wm density reset -d " + displayId)).append('\n');
                if (density != null && density >= 72 && density <= 1000) {
                    out.append(execPriv("wm density " + density + " -d " + displayId)).append('\n');
                }

                pendingRevert = state;
                runOnUiThread(() -> {
                    appendLog("Monitor request: " + w + "×" + h + " @ " + hz + " Hz\n" + out);
                    startSafetyCountdown();
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Monitor apply failed: " + t));
            }
        });
    }

    private void applyPhoneCustom() {
        Integer w = parseInt(phoneWidth.getText().toString());
        Integer h = parseInt(phoneHeight.getText().toString());
        if (w == null || h == null || w < 480 || h < 480) {
            Toast.makeText(this, "Enter a valid game-view width and height.", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> cmds = new ArrayList<>();
        cmds.add("wm size " + w + "x" + h + " -d 0");
        Integer dpi = parseOptionalInt(phoneDensity.getText().toString());
        if (dpi != null && dpi >= 72 && dpi <= 1000) {
            cmds.add("wm density " + dpi + " -d 0");
        }
        runCommands("Apply game view", cmds);
    }

    private RevertState captureRevertState(int displayId) throws RemoteException {
        RevertState s = new RevertState();
        s.displayId = displayId;
        s.preferredMode = execPriv("cmd display get-user-preferred-display-mode " + displayId);
        s.externalSize = execPriv("wm size -d " + displayId);
        s.externalDensity = execPriv("wm density -d " + displayId);
        return s;
    }

    private void startSafetyCountdown() {
        cancelSafetyCountdown(false);
        keepButton.setEnabled(true);
        keepButton.setAlpha(1f);
        safetyDeadline = System.currentTimeMillis() + SAFETY_MS;
        autoRevertRunnable = () -> {
            RevertState state = pendingRevert;
            pendingRevert = null;
            if (state != null) restoreState(state, "Safety rollback");
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.5f);
            safetyText.setText("Safety rollback: reverted");
            safetyText.setTextColor(Color.parseColor("#E0A0A0"));
        };
        main.postDelayed(autoRevertRunnable, SAFETY_MS);
        tickSafety();
    }

    private void tickSafety() {
        if (autoRevertRunnable == null) return;
        long remain = Math.max(0, safetyDeadline - System.currentTimeMillis());
        safetyText.setText("Monitor rollback in " + ((remain + 999) / 1000) + " s");
        safetyText.setTextColor(ACCENT);
        if (remain > 0) main.postDelayed(this::tickSafety, 500);
    }

    private void cancelSafetyCountdown(boolean keep) {
        if (autoRevertRunnable != null) main.removeCallbacks(autoRevertRunnable);
        autoRevertRunnable = null;
        if (keep) {
            pendingRevert = null;
            safetyText.setText("Safety rollback: mode kept");
            safetyText.setTextColor(ACCENT);
            appendLog("Monitor mode confirmed.");
        } else if (pendingRevert == null) {
            safetyText.setText("Safety rollback: inactive");
            safetyText.setTextColor(MUTED);
        }
        if (keepButton != null) {
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.5f);
        }
    }

    private void restoreState(RevertState state, String reason) {
        if (!requireShell()) return;
        worker.execute(() -> {
            try {
                List<String> cmds = Arrays.asList(
                        preferredModeRestoreCommand(state.displayId, state.preferredMode),
                        sizeRestoreCommand(state.displayId, state.externalSize),
                        densityRestoreCommand(state.displayId, state.externalDensity),
                        "wm scaling auto -d " + state.displayId
                );
                StringBuilder out = new StringBuilder();
                for (String c : cmds) {
                    out.append("$ ").append(c).append('\n').append(execPriv(c)).append('\n');
                }
                runOnUiThread(() -> {
                    appendLog(reason + "\n" + out);
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Rollback failed: " + t));
            }
        });
    }

    private String preferredModeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("User preferred display mode:\\s*(\\d+)\\s+(\\d+)\\s+([0-9.]+)")
                .matcher(output == null ? "" : output);
        if (m.find()) {
            return "cmd display set-user-preferred-display-mode " + m.group(1) + " " + m.group(2)
                    + " " + m.group(3) + " " + displayId;
        }
        return "cmd display clear-user-preferred-display-mode " + displayId;
    }

    private String sizeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override size:\\s*(\\d+)x(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm size " + m.group(1) + "x" + m.group(2) + " -d " + displayId;
        return "wm size reset -d " + displayId;
    }

    private String densityRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override density:\\s*(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm density " + m.group(1) + " -d " + displayId;
        return "wm density reset -d " + displayId;
    }

    private void restoreSelectedExternal() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == 0) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_SHORT).show();
            return;
        }
        cancelSafetyCountdown(false);
        int id = d.getDisplayId();
        runCommands("Restore monitor", Arrays.asList(
                "cmd display clear-user-preferred-display-mode " + id,
                "wm size reset -d " + id,
                "wm density reset -d " + id,
                "wm scaling auto -d " + id));
    }

    private void restoreAllDefaults() {
        Display d = selectedDisplay();
        int id = d == null ? -1 : d.getDisplayId();
        cancelSafetyCountdown(false);
        List<String> cmds = new ArrayList<>();
        if (id > 0) {
            cmds.add("cmd display clear-user-preferred-display-mode " + id);
            cmds.add("wm size reset -d " + id);
            cmds.add("wm density reset -d " + id);
            cmds.add("wm scaling auto -d " + id);
        }
        cmds.add("wm size reset -d 0");
        cmds.add("wm density reset -d 0");
        cmds.add("wm scaling auto -d 0");
        runCommands("Restore everything", cmds);
    }

    private void runCommands(String title, List<String> commands) {
        if (!requireShell()) return;
        worker.execute(() -> {
            StringBuilder out = new StringBuilder();
            try {
                for (String c : commands) {
                    out.append("$ ").append(c).append('\n');
                    out.append(execPriv(c)).append('\n');
                }
            } catch (Throwable t) {
                out.append("ERROR: ").append(t);
            }
            runOnUiThread(() -> {
                appendLog(title + "\n" + out);
                refreshDisplays();
            });
        });
    }

    private String execPriv(String command) throws RemoteException {
        IUserService s = shellService;
        if (s == null) throw new RemoteException("Shizuku service not connected");
        return s.exec(command);
    }

    private boolean requireShell() {
        if (shellService != null) return true;
        Toast.makeText(this, "Connect Shizuku first.", Toast.LENGTH_LONG).show();
        ensureShizuku();
        return false;
    }

    private Display selectedDisplay() {
        int p = displaySpinner.getSelectedItemPosition();
        return (p >= 0 && p < displayList.size()) ? displayList.get(p) : null;
    }

    private Display.Mode selectedMode() {
        int p = modeSpinner.getSelectedItemPosition();
        return (p >= 0 && p < modeList.size()) ? modeList.get(p) : null;
    }

    private void setStatus(String value, int color) {
        status.setText(value);
        status.setTextColor(color);
    }

    private void appendLog(String value) {
        if (logView == null) return;
        String old = logView.getText().toString();
        if (old.length() > 9000) old = old.substring(old.length() - 7000);
        logView.setText(old + (old.isEmpty() ? "" : "\n\n") + value.trim());
    }

    @Override public void onDisplayAdded(int displayId) { refreshDisplays(); }
    @Override public void onDisplayRemoved(int displayId) { refreshDisplays(); }
    @Override public void onDisplayChanged(int displayId) { refreshDisplays(); }

    private LinearLayout card() {
        LinearLayout v = vertical();
        v.setPadding(dp(14), dp(14), dp(14), dp(14));
        v.setBackground(rounded(CARD, dp(18), BORDER));
        return v;
    }

    private void sectionTitle(LinearLayout parent, String value) {
        TextView t = label(value, 18, true, TEXT);
        parent.addView(t, match());
    }

    private void miniTitle(LinearLayout parent, String value) {
        TextView t = label(value, 12, true, ACCENT);
        t.setPadding(dp(2), dp(14), dp(2), dp(6));
        parent.addView(t, match());
    }

    private void mutedText(LinearLayout parent, String value) {
        TextView t = label(value, 12, false, MUTED);
        t.setPadding(0, dp(4), 0, 0);
        parent.addView(t, match());
    }

    private void divider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        p.setMargins(0, dp(16), 0, 0);
        parent.addView(line, p);
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTextColor(primary ? Color.parseColor("#141311") : TEXT);
        b.setBackground(rounded(primary ? ACCENT : FIELD_2, dp(14), primary ? ACCENT : BORDER));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        return b;
    }

    private Spinner spinner() {
        Spinner s = new Spinner(this);
        s.setPadding(dp(10), dp(4), dp(10), dp(4));
        s.setBackground(rounded(FIELD, dp(14), BORDER));
        return s;
    }

    private EditText numberField(String hint, String value) {
        EditText e = textField(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private EditText decimalField(String hint, String value) {
        EditText e = textField(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private EditText textField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.parseColor("#77736E"));
        e.setText(value);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setBackground(rounded(FIELD, dp(14), BORDER));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    private ArrayAdapter<String> spinnerAdapter(List<String> items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(TEXT);
                    t.setTextSize(13f);
                    t.setPadding(dp(4), dp(7), dp(4), dp(7));
                    t.setBackgroundColor(Color.TRANSPARENT);
                }
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(TEXT);
                    t.setTextSize(13f);
                    t.setPadding(dp(14), dp(12), dp(14), dp(12));
                    t.setBackgroundColor(FIELD);
                }
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private GradientDrawable rounded(int fill, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWithTop(int topDp) {
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, dp(topDp), 0, 0);
        return p;
    }

    private LinearLayout.LayoutParams matchWithBottom(int bottomDp) {
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, 0, 0, dp(bottomDp));
        return p;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private Integer parseInt(String value) {
        try { return Integer.parseInt(value.trim()); }
        catch (Throwable t) { return null; }
    }

    private Integer parseOptionalInt(String value) {
        String s = value == null ? "" : value.trim();
        if (s.isEmpty()) return null;
        return parseInt(s);
    }

    private Float parseFloat(String value) {
        try { return Float.parseFloat(value.trim()); }
        catch (Throwable t) { return null; }
    }

    private String trimFloat(float value) {
        if (Math.abs(value - Math.round(value)) < 0.01f) {
            return String.valueOf(Math.round(value));
        }
        return String.format(Locale.US, "%.2f", value);
    }

    private static class BuiltInPreset {
        final String name;
        final int width;
        final int height;
        final int dpi;
        final String note;

        BuiltInPreset(String name, int width, int height, int dpi, String note) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.dpi = dpi;
            this.note = note;
        }
    }

    private static class SavedProfile {
        final String name;
        final int phoneWidth;
        final int phoneHeight;
        final int phoneDensity;
        final int externalWidth;
        final int externalHeight;
        final float externalHz;
        final int externalDensity;

        SavedProfile(String name, int phoneWidth, int phoneHeight, int phoneDensity,
                     int externalWidth, int externalHeight, float externalHz, int externalDensity) {
            this.name = name;
            this.phoneWidth = phoneWidth;
            this.phoneHeight = phoneHeight;
            this.phoneDensity = phoneDensity;
            this.externalWidth = externalWidth;
            this.externalHeight = externalHeight;
            this.externalHz = externalHz;
            this.externalDensity = externalDensity;
        }
    }

    private static class PresetEntry {
        final boolean saved;
        final SavedProfile savedProfile;
        final BuiltInPreset builtInPreset;

        private PresetEntry(boolean saved, SavedProfile savedProfile, BuiltInPreset builtInPreset) {
            this.saved = saved;
            this.savedProfile = savedProfile;
            this.builtInPreset = builtInPreset;
        }

        static PresetEntry saved(SavedProfile profile) {
            return new PresetEntry(true, profile, null);
        }

        static PresetEntry builtIn(BuiltInPreset preset) {
            return new PresetEntry(false, null, preset);
        }
    }

    private static class RevertState {
        int displayId;
        String preferredMode;
        String externalSize;
        String externalDensity;
    }
}
