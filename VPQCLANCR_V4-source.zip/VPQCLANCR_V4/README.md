# VPQCLAN C.R V4

**VPQCLAN Custom Resolution** — elegant Android/Shizuku display tool.

## V4 changes
- Elegant graphite / champagne interface
- Much simpler layout
- Game View and Monitor Output are completely separated
- Built-in iPad / tablet presets
- Custom width / height / DPI
- Saved custom profiles appear at the top of the preset dropdown
- Custom profile names
- Save / update profiles
- Delete unwanted saved profiles
- Saved profiles remember both game-view and monitor values
- Custom monitor width / height / Hz / optional DPI
- 15-second monitor safety rollback
- Collapsible diagnostics
- New elegant VPQ C.R icon

## Branding
- App name: **VPQCLAN C.R**
- Banner: **VPQCLAN Custom Resolution**
- Footer: **This App is part of VPQCLAN, made by VPQ SNIKA**

## Note
The tablet/iPad presets change Android's logical render size/aspect ratio. They do not modify PUBG's private internal FOV engine setting.
