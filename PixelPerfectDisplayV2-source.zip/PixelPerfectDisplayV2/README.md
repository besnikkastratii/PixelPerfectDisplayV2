# PixelPerfect Display V2

A small Android utility for REDMAGIC/PUBG external-display testing. It uses Shizuku UserService (shell/root identity) to change display modes without root.

## What it does

- Detects Android displays and their reported physical modes.
- Lets you select a real monitor mode (resolution + refresh rate).
- `Best quality` selects the highest pixel-count mode.
- `Best >=120 Hz` selects the highest-resolution mode at 119 Hz or above.
- `Match phone render to monitor` changes the phone's logical natural-orientation size to the reverse of the external mode. Example: 1920x1080 monitor -> phone `wm size 1080x1920`. This is intended to avoid the extra 1920x1200 -> 1920x1080 scaling step.
- Optional `wm scaling off` on the external display.
- 15-second automatic rollback after changing the external mode unless **KEEP NEW MODE** is tapped.
- Separate phone/PUBG custom-resolution controls, including the user's old 1200x1920 preset.
- Restore buttons.

## Requirements

- Android 8+ (intended for modern Android / REDMAGIC).
- Shizuku installed and running. On non-rooted Android 11+, Shizuku can be started with Wireless Debugging.
- The device/OEM must allow the relevant shell display commands. Some vendor mirroring stacks may ignore per-display mode overrides.

## Build in Android Studio

Open this folder in Android Studio and build `app`.

The project uses:
- compileSdk 36
- Java 17
- Shizuku API/provider 13.1.5

## GitHub Actions

Push this folder to GitHub and run the included **Build APK** workflow. The debug APK is uploaded as an Actions artifact.

## Important display note

A 16:10 render such as landscape 1920x1200 cannot fill a 16:9 1920x1080 monitor without either scaling/cropping or black bars. For maximum sharpness while mirroring, use a logical render matching the physical monitor mode exactly (for 1080p: phone natural-orientation 1080x1920).
