package com.besnik.pixelperfect;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.InputType;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity implements DisplayManager.DisplayListener {

    private static final int REQ_SHIZUKU = 4102;
    private static final long SAFETY_MS = 15_000L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private TextView status;
    private TextView displayInfo;
    private TextView safetyText;
    private TextView logView;
    private Spinner displaySpinner;
    private Spinner modeSpinner;
    private EditText phoneWidth;
    private EditText phoneHeight;
    private EditText phoneDensity;
    private CheckBox matchPhoneToMonitor;
    private CheckBox disableExternalScaling;
    private Button keepButton;

    private DisplayManager displayManager;
    private final List<Display> displayList = new ArrayList<>();
    private final List<Display.Mode> modeList = new ArrayList<>();

    private IUserService shellService;
    private boolean binding;
    private RevertState pendingRevert;
    private Runnable autoRevertRunnable;
    private long safetyDeadline;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::onShizukuBinderReady;
    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> runOnUiThread(() -> {
        shellService = null;
        binding = false;
        setStatus("Shizuku stopped — start it again, then return here.");
    });
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_SHIZUKU) return;
        runOnUiThread(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setStatus("Shizuku permission granted. Connecting…");
                bindShellService();
            } else {
                setStatus("Shizuku permission denied.");
            }
        });
    };

    private final Shizuku.UserServiceArgs serviceArgs = new Shizuku.UserServiceArgs(
            new ComponentName(BuildConfig.APPLICATION_ID, UserService.class.getName()))
            .daemon(false)
            .processNameSuffix("pixelperfect")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
            .tag("pixelperfect-v2");

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            runOnUiThread(() -> {
                binding = false;
                if (binder != null && binder.pingBinder()) {
                    shellService = IUserService.Stub.asInterface(binder);
                    setStatus("Ready — Shizuku shell connected.");
                    appendLog("Shizuku UserService connected.");
                } else {
                    shellService = null;
                    setStatus("Shizuku connected, but privileged service is unavailable.");
                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            runOnUiThread(() -> {
                shellService = null;
                binding = false;
                setStatus("Privileged service disconnected.");
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        displayManager.registerDisplayListener(this, main);

        displaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshModes();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionListener);

        refreshDisplays();
        ensureShizuku();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        displayManager.unregisterDisplayListener(this);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        cancelSafetyCountdown(false);
        try {
            if (binding || shellService != null) {
                Shizuku.unbindUserService(serviceArgs, serviceConnection, true);
            }
        } catch (Throwable ignored) { }
        worker.shutdownNow();
    }

    private View buildUi() {
        int p = dp(16);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, dp(32));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("PixelPerfect Display V2", 25, true);
        root.addView(title);
        TextView subtitle = text("PUBG / external monitor resolution manager", 14, false);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        status = text("Checking Shizuku…", 14, true);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(status, match());

        Button connect = button("Connect / request Shizuku permission");
        connect.setOnClickListener(v -> ensureShizuku());
        root.addView(connect, match());

        section(root, "EXTERNAL MONITOR");
        displaySpinner = new Spinner(this);
        root.addView(displaySpinner, match());

        displayInfo = text("No display selected", 13, false);
        displayInfo.setPadding(0, dp(8), 0, dp(8));
        root.addView(displayInfo);

        modeSpinner = new Spinner(this);
        root.addView(modeSpinner, match());

        LinearLayout row = row();
        Button refresh = button("Refresh displays");
        refresh.setOnClickListener(v -> refreshDisplays());
        row.addView(refresh, weight());
        Button bestQuality = button("Best quality");
        bestQuality.setOnClickListener(v -> selectBestQuality());
        row.addView(bestQuality, weight());
        root.addView(row, match());

        LinearLayout row2 = row();
        Button best120 = button("Best ≥120 Hz");
        best120.setOnClickListener(v -> selectBest120());
        row2.addView(best120, weight());
        Button applyExternal = button("Apply selected");
        applyExternal.setOnClickListener(v -> applySelectedExternalMode());
        row2.addView(applyExternal, weight());
        root.addView(row2, match());

        matchPhoneToMonitor = new CheckBox(this);
        matchPhoneToMonitor.setText("Match phone render to monitor (sharpest mirroring)");
        matchPhoneToMonitor.setChecked(true);
        root.addView(matchPhoneToMonitor);

        disableExternalScaling = new CheckBox(this);
        disableExternalScaling.setText("Disable Android forced scaling on external display");
        disableExternalScaling.setChecked(true);
        root.addView(disableExternalScaling);

        TextView sharpNote = text(
                "For a 1920×1080 monitor, matching sets the phone's natural portrait render to 1080×1920. " +
                "That removes the 1920×1200 → 1920×1080 stretch that causes blur. If you keep a 16:10 game render on a 16:9 monitor, some scaling or black bars are unavoidable.",
                13, false);
        sharpNote.setPadding(0, dp(6), 0, dp(8));
        root.addView(sharpNote);

        safetyText = text("Safety rollback: inactive", 13, true);
        root.addView(safetyText);
        keepButton = button("KEEP NEW MODE");
        keepButton.setEnabled(false);
        keepButton.setOnClickListener(v -> cancelSafetyCountdown(true));
        root.addView(keepButton, match());

        LinearLayout restoreRow = row();
        Button restoreExternal = button("Restore selected monitor");
        restoreExternal.setOnClickListener(v -> restoreSelectedExternal());
        restoreRow.addView(restoreExternal, weight());
        Button restoreAll = button("Restore all defaults");
        restoreAll.setOnClickListener(v -> restoreAllDefaults());
        restoreRow.addView(restoreAll, weight());
        root.addView(restoreRow, match());

        section(root, "PHONE / PUBG LOGICAL RESOLUTION");
        TextView currentPreset = text("Your old working preset: 1200 × 1920", 13, false);
        root.addView(currentPreset);

        LinearLayout sizeRow = row();
        phoneWidth = numberField("Width", "1200");
        phoneHeight = numberField("Height", "1920");
        sizeRow.addView(phoneWidth, weight());
        sizeRow.addView(phoneHeight, weight());
        root.addView(sizeRow, match());

        phoneDensity = numberField("DPI (optional)", "");
        root.addView(phoneDensity, match());

        LinearLayout phoneButtons = row();
        Button applyPhone = button("Apply phone size");
        applyPhone.setOnClickListener(v -> applyPhoneCustom());
        phoneButtons.addView(applyPhone, weight());
        Button resetPhone = button("Reset phone");
        resetPhone.setOnClickListener(v -> runCommands("Reset phone", Arrays.asList(
                "wm size reset -d 0", "wm density reset -d 0", "wm scaling auto -d 0")));
        phoneButtons.addView(resetPhone, weight());
        root.addView(phoneButtons, match());

        Button matchSelected = button("MATCH PHONE TO SELECTED MONITOR NOW");
        matchSelected.setOnClickListener(v -> matchPhoneOnly());
        root.addView(matchSelected, match());

        section(root, "COMMAND LOG");
        logView = text("", 12, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(logView, match());

        return scroll;
    }

    private void ensureShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                setStatus("Shizuku is not running. Start Shizuku, then come back.");
                return;
            }
            if (Shizuku.isPreV11()) {
                setStatus("This Shizuku version is too old. Use Shizuku v11+.");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Waiting for Shizuku permission…");
                Shizuku.requestPermission(REQ_SHIZUKU);
                return;
            }
            bindShellService();
        } catch (Throwable t) {
            setStatus("Shizuku error: " + t.getMessage());
        }
    }

    private void onShizukuBinderReady() {
        runOnUiThread(this::ensureShizuku);
    }

    private void bindShellService() {
        if (shellService != null || binding) return;
        try {
            binding = true;
            setStatus("Connecting privileged shell…");
            Shizuku.bindUserService(serviceArgs, serviceConnection);
        } catch (Throwable t) {
            binding = false;
            setStatus("Could not bind Shizuku service: " + t.getMessage());
        }
    }

    private void refreshDisplays() {
        displayList.clear();
        Display[] all = displayManager.getDisplays();
        // Put external displays first so the intended monitor is the default selection.
        Arrays.sort(all, (a, b) -> Integer.compare(a.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0,
                b.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0));
        displayList.addAll(Arrays.asList(all));

        List<String> labels = new ArrayList<>();
        for (Display d : displayList) {
            Display.Mode m = d.getMode();
            labels.add(String.format(Locale.US, "%s  [id %d]  %d×%d @ %.2f Hz%s",
                    d.getName(), d.getDisplayId(), m.getPhysicalWidth(), m.getPhysicalHeight(),
                    m.getRefreshRate(), d.getDisplayId() == 0 ? "  (phone)" : ""));
        }
        if (labels.isEmpty()) labels.add("No displays found");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels);
        displaySpinner.setAdapter(adapter);
        if (!displayList.isEmpty()) displaySpinner.setSelection(0);
        refreshModes();
    }

    private void refreshModes() {
        modeList.clear();
        Display d = selectedDisplay();
        if (d == null) {
            modeSpinner.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_dropdown_item,
                    Collections.singletonList("No supported modes")));
            displayInfo.setText("No display selected");
            return;
        }

        Display.Mode active = d.getMode();
        List<Display.Mode> modes = new ArrayList<>(Arrays.asList(d.getSupportedModes()));
        modes.sort(Comparator
                .comparingLong((Display.Mode m) -> (long)m.getPhysicalWidth() * m.getPhysicalHeight()).reversed()
                .thenComparing(Comparator.comparingDouble(Display.Mode::getRefreshRate).reversed()));
        modeList.addAll(modes);

        List<String> labels = new ArrayList<>();
        int activeIndex = 0;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            boolean isActive = m.getModeId() == active.getModeId();
            if (isActive) activeIndex = i;
            labels.add(String.format(Locale.US, "%d×%d @ %.2f Hz%s",
                    m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    isActive ? "   • ACTIVE" : ""));
        }
        modeSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels));
        if (!modeList.isEmpty()) modeSpinner.setSelection(activeIndex);

        displayInfo.setText(String.format(Locale.US,
                "Display id %d • current %d×%d @ %.2f Hz • %d supported mode(s)",
                d.getDisplayId(), active.getPhysicalWidth(), active.getPhysicalHeight(),
                active.getRefreshRate(), modeList.size()));
    }

    private void selectBestQuality() {
        if (modeList.isEmpty()) return;
        int best = 0;
        long bestPixels = -1;
        float bestHz = -1;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            long px = (long)m.getPhysicalWidth() * m.getPhysicalHeight();
            if (px > bestPixels || (px == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i; bestPixels = px; bestHz = m.getRefreshRate();
            }
        }
        modeSpinner.setSelection(best);
        Toast.makeText(this, "Highest-resolution mode selected", Toast.LENGTH_SHORT).show();
    }

    private void selectBest120() {
        int best = -1;
        long bestPixels = -1;
        float bestHz = -1;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            if (m.getRefreshRate() < 119.0f) continue;
            long px = (long)m.getPhysicalWidth() * m.getPhysicalHeight();
            if (px > bestPixels || (px == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i; bestPixels = px; bestHz = m.getRefreshRate();
            }
        }
        if (best < 0) {
            Toast.makeText(this, "This display reports no ≥120 Hz mode", Toast.LENGTH_LONG).show();
        } else {
            modeSpinner.setSelection(best);
            Toast.makeText(this, "Best ≥120 Hz mode selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void applySelectedExternalMode() {
        Display d = selectedDisplay();
        Display.Mode m = selectedMode();
        if (d == null || m == null) return;
        if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor, not display 0.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!requireShell()) return;

        final int displayId = d.getDisplayId();
        final int w = m.getPhysicalWidth();
        final int h = m.getPhysicalHeight();
        final float hz = m.getRefreshRate();
        final boolean matchPhone = matchPhoneToMonitor.isChecked();
        final boolean scalingOff = disableExternalScaling.isChecked();

        worker.execute(() -> {
            try {
                RevertState state = captureRevertState(displayId, matchPhone);
                StringBuilder result = new StringBuilder();

                result.append(execPriv(String.format(Locale.US,
                        "cmd display set-user-preferred-display-mode %d %d %.3f %d",
                        w, h, hz, displayId))).append('\n');

                // Remove any logical override on the monitor so its physical mode can stay pixel-clean.
                result.append(execPriv("wm size reset -d " + displayId)).append('\n');
                result.append(execPriv("wm density reset -d " + displayId)).append('\n');
                if (scalingOff) {
                    result.append(execPriv("wm scaling off -d " + displayId)).append('\n');
                }

                // Mirroring is sharpest when the phone compositor renders the same pixel grid.
                // Android phones have portrait natural orientation, hence external W×H becomes H×W.
                if (matchPhone) {
                    result.append(execPriv("wm size " + h + "x" + w + " -d 0")).append('\n');
                }

                pendingRevert = state;
                runOnUiThread(() -> {
                    appendLog("APPLY display " + displayId + ": " + w + "×" + h + " @ " + hz + " Hz");
                    appendLog(result.toString());
                    startSafetyCountdown();
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Apply failed: " + t));
            }
        });
    }

    private RevertState captureRevertState(int displayId, boolean capturePhone) throws RemoteException {
        RevertState s = new RevertState();
        s.displayId = displayId;
        s.preferredMode = execPriv("cmd display get-user-preferred-display-mode " + displayId);
        s.externalSize = execPriv("wm size -d " + displayId);
        s.externalDensity = execPriv("wm density -d " + displayId);
        if (capturePhone) {
            s.phoneSize = execPriv("wm size -d 0");
            s.phoneDensity = execPriv("wm density -d 0");
        }
        return s;
    }

    private void startSafetyCountdown() {
        cancelSafetyCountdown(false);
        keepButton.setEnabled(true);
        safetyDeadline = System.currentTimeMillis() + SAFETY_MS;
        autoRevertRunnable = () -> {
            RevertState state = pendingRevert;
            pendingRevert = null;
            if (state != null) {
                restoreState(state, "Safety rollback");
            }
            keepButton.setEnabled(false);
            safetyText.setText("Safety rollback: reverted");
        };
        main.postDelayed(autoRevertRunnable, SAFETY_MS);
        tickSafety();
    }

    private void tickSafety() {
        if (autoRevertRunnable == null) return;
        long remain = Math.max(0, safetyDeadline - System.currentTimeMillis());
        safetyText.setText("Safety rollback in " + ((remain + 999) / 1000) + " s — tap KEEP if picture is good");
        if (remain > 0) main.postDelayed(this::tickSafety, 500);
    }

    private void cancelSafetyCountdown(boolean keep) {
        if (autoRevertRunnable != null) main.removeCallbacks(autoRevertRunnable);
        autoRevertRunnable = null;
        if (keep) {
            pendingRevert = null;
            safetyText.setText("Safety rollback: mode kept");
            appendLog("Mode confirmed by user.");
        } else if (pendingRevert == null) {
            safetyText.setText("Safety rollback: inactive");
        }
        if (keepButton != null) keepButton.setEnabled(false);
    }

    private void restoreState(RevertState state, String reason) {
        if (!requireShell()) return;
        worker.execute(() -> {
            try {
                List<String> cmds = new ArrayList<>();
                cmds.add(preferredModeRestoreCommand(state.displayId, state.preferredMode));
                cmds.add(sizeRestoreCommand(state.displayId, state.externalSize));
                cmds.add(densityRestoreCommand(state.displayId, state.externalDensity));
                cmds.add("wm scaling auto -d " + state.displayId);
                if (state.phoneSize != null) cmds.add(sizeRestoreCommand(0, state.phoneSize));
                if (state.phoneDensity != null) cmds.add(densityRestoreCommand(0, state.phoneDensity));
                StringBuilder out = new StringBuilder();
                for (String c : cmds) out.append("$ ").append(c).append('\n').append(execPriv(c)).append('\n');
                runOnUiThread(() -> {
                    appendLog(reason + "\n" + out);
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Rollback failed: " + t));
            }
        });
    }

    private String preferredModeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("User preferred display mode:\\s*(\\d+)\\s+(\\d+)\\s+([0-9.]+)")
                .matcher(output == null ? "" : output);
        if (m.find()) {
            return "cmd display set-user-preferred-display-mode " + m.group(1) + " " + m.group(2) + " " + m.group(3) + " " + displayId;
        }
        return "cmd display clear-user-preferred-display-mode " + displayId;
    }

    private String sizeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override size:\\s*(\\d+)x(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm size " + m.group(1) + "x" + m.group(2) + " -d " + displayId;
        return "wm size reset -d " + displayId;
    }

    private String densityRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override density:\\s*(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm density " + m.group(1) + " -d " + displayId;
        return "wm density reset -d " + displayId;
    }

    private void restoreSelectedExternal() {
        Display d = selectedDisplay();
        if (d == null) return;
        int id = d.getDisplayId();
        if (id == 0) {
            Toast.makeText(this, "Display 0 is the phone.", Toast.LENGTH_SHORT).show();
            return;
        }
        cancelSafetyCountdown(false);
        runCommands("Restore display " + id, Arrays.asList(
                "cmd display clear-user-preferred-display-mode " + id,
                "wm size reset -d " + id,
                "wm density reset -d " + id,
                "wm scaling auto -d " + id));
    }

    private void restoreAllDefaults() {
        Display d = selectedDisplay();
        int id = d == null ? -1 : d.getDisplayId();
        cancelSafetyCountdown(false);
        List<String> cmds = new ArrayList<>();
        if (id > 0) {
            cmds.add("cmd display clear-user-preferred-display-mode " + id);
            cmds.add("wm size reset -d " + id);
            cmds.add("wm density reset -d " + id);
            cmds.add("wm scaling auto -d " + id);
        }
        cmds.add("wm size reset -d 0");
        cmds.add("wm density reset -d 0");
        cmds.add("wm scaling auto -d 0");
        runCommands("Restore defaults", cmds);
    }

    private void applyPhoneCustom() {
        Integer w = parseInt(phoneWidth.getText().toString());
        Integer h = parseInt(phoneHeight.getText().toString());
        if (w == null || h == null || w < 480 || h < 480) {
            Toast.makeText(this, "Enter a valid width and height.", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> cmds = new ArrayList<>();
        cmds.add("wm size " + w + "x" + h + " -d 0");
        String dpi = phoneDensity.getText().toString().trim();
        if (!dpi.isEmpty()) {
            Integer d = parseInt(dpi);
            if (d != null && d >= 72 && d <= 1000) cmds.add("wm density " + d + " -d 0");
        }
        runCommands("Apply phone logical size", cmds);
    }

    private void matchPhoneOnly() {
        Display.Mode m = selectedMode();
        if (m == null) return;
        runCommands("Match phone to monitor", Collections.singletonList(
                "wm size " + m.getPhysicalHeight() + "x" + m.getPhysicalWidth() + " -d 0"));
    }

    private void runCommands(String title, List<String> commands) {
        if (!requireShell()) return;
        worker.execute(() -> {
            StringBuilder out = new StringBuilder();
            try {
                for (String c : commands) {
                    out.append("$ ").append(c).append('\n');
                    out.append(execPriv(c)).append('\n');
                }
            } catch (Throwable t) {
                out.append("ERROR: ").append(t);
            }
            runOnUiThread(() -> {
                appendLog(title + "\n" + out);
                refreshDisplays();
            });
        });
    }

    private String execPriv(String command) throws RemoteException {
        IUserService s = shellService;
        if (s == null) throw new RemoteException("Shizuku UserService is not connected");
        return s.exec(command);
    }

    private boolean requireShell() {
        if (shellService != null) return true;
        Toast.makeText(this, "Connect Shizuku first.", Toast.LENGTH_LONG).show();
        ensureShizuku();
        return false;
    }

    private Display selectedDisplay() {
        int p = displaySpinner.getSelectedItemPosition();
        if (p < 0 || p >= displayList.size()) return null;
        return displayList.get(p);
    }

    private Display.Mode selectedMode() {
        int p = modeSpinner.getSelectedItemPosition();
        if (p < 0 || p >= modeList.size()) return null;
        return modeList.get(p);
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    private void appendLog(String s) {
        String old = logView.getText().toString();
        if (old.length() > 9000) old = old.substring(old.length() - 7000);
        logView.setText(old + (old.isEmpty() ? "" : "\n\n") + s.trim());
    }

    @Override public void onDisplayAdded(int displayId) { refreshDisplays(); }
    @Override public void onDisplayRemoved(int displayId) { refreshDisplays(); }
    @Override public void onDisplayChanged(int displayId) { refreshDisplays(); }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private EditText numberField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setPadding(dp(8), 0, dp(8), 0);
        return e;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 15, true);
        t.setPadding(0, dp(20), 0, dp(8));
        root.addView(t);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Integer parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Throwable t) { return null; }
    }

    private static class RevertState {
        int displayId;
        String preferredMode;
        String externalSize;
        String externalDensity;
        String phoneSize;
        String phoneDensity;
    }
}
