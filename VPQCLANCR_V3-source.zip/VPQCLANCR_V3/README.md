# VPQCLAN C.R (V3)

**VPQCLAN Custom Resolution** is an Android/Shizuku app for:

- custom phone logical resolution
- iPad-style / tablet-style render presets
- custom external monitor resolution and refresh-rate mode
- matching phone render to monitor for sharper output
- saved profiles
- safety rollback

## Branding
- App name: **VPQCLAN C.R**
- In-app banner: **VPQCLAN Custom Resolution**
- Footer text: **This App is part of VPQCLAN, made by VPQ SNIKA**

## Main V3 additions
- redesigned dark gaming-style interface
- iPad View presets
- custom monitor width / height / Hz / optional DPI
- save + load profile
- VPQ icon

## Build for free with GitHub Actions
1. Put this full project in a GitHub repository.
2. Push to `main`.
3. Open the **Actions** tab.
4. The workflow **Build VPQCLAN C.R APK** will run automatically.
5. Download the artifact **VPQCLAN-CR-v3-debug-apk**.

## Requirements
- Android 8+
- Shizuku v11+

## Important note
This app changes Android display and logical resolution settings. It can create a more tablet-like PUBG view by changing aspect ratio, but it does **not** modify PUBG's private internal game code or unlock a true engine-level FOV hack.
