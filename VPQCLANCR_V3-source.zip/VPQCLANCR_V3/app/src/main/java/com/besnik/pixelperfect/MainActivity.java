package com.besnik.pixelperfect;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.InputType;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity implements DisplayManager.DisplayListener {

    private static final int REQ_SHIZUKU = 4102;
    private static final long SAFETY_MS = 15_000L;
    private static final String PREFS = "vpqclan_cr_v3";

    private static final int BG = Color.parseColor("#0B1020");
    private static final int CARD = Color.parseColor("#141B34");
    private static final int CARD_ALT = Color.parseColor("#10172B");
    private static final int TEXT = Color.parseColor("#F4F7FF");
    private static final int MUTED = Color.parseColor("#9FB0D0");
    private static final int ACCENT = Color.parseColor("#4CF2C2");
    private static final int ACCENT_2 = Color.parseColor("#57A9FF");
    private static final int WARNING = Color.parseColor("#FFC857");
    private static final int ERROR = Color.parseColor("#FF6B6B");

    private static final Preset[] PHONE_PRESETS = new Preset[] {
            new Preset("Balanced 16:10", 1200, 1920, 420, "Your old stable style"),
            new Preset("iPad View Classic", 1536, 2048, 420, "4:3 style • more tablet-like view"),
            new Preset("iPad View Plus", 1728, 2304, 440, "Stronger 4:3 style"),
            new Preset("Tablet View Safe", 1440, 1920, 420, "Safe 4:3-ish mode"),
            new Preset("Balanced 3:2", 1440, 2160, 440, "Wider tablet-style framing"),
            new Preset("16:9 Clean", 1080, 1920, 420, "Standard tall mode"),
            new Preset("Monitor Match 1080p", 1080, 1920, 400, "Best for 1920×1080 mirroring")
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private TextView status;
    private TextView displayInfo;
    private TextView safetyText;
    private TextView logView;
    private TextView presetInfo;
    private Spinner displaySpinner;
    private Spinner modeSpinner;
    private Spinner presetSpinner;
    private EditText phoneWidth;
    private EditText phoneHeight;
    private EditText phoneDensity;
    private EditText externalWidth;
    private EditText externalHeight;
    private EditText externalHz;
    private EditText externalDensity;
    private CheckBox matchPhoneToMonitor;
    private CheckBox disableExternalScaling;
    private Button keepButton;

    private DisplayManager displayManager;
    private final List<Display> displayList = new ArrayList<>();
    private final List<Display.Mode> modeList = new ArrayList<>();

    private IUserService shellService;
    private boolean binding;
    private RevertState pendingRevert;
    private Runnable autoRevertRunnable;
    private long safetyDeadline;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::onShizukuBinderReady;
    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> runOnUiThread(() -> {
        shellService = null;
        binding = false;
        setStatus("Shizuku stopped — start it again, then return here.", ERROR);
    });
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_SHIZUKU) return;
        runOnUiThread(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setStatus("Shizuku permission granted. Connecting…", ACCENT);
                bindShellService();
            } else {
                setStatus("Shizuku permission denied.", ERROR);
            }
        });
    };

    private final Shizuku.UserServiceArgs serviceArgs = new Shizuku.UserServiceArgs(
            new ComponentName(BuildConfig.APPLICATION_ID, UserService.class.getName()))
            .daemon(false)
            .processNameSuffix("vpqclan-cr-v3")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
            .tag("vpqclan-cr-v3");

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            runOnUiThread(() -> {
                binding = false;
                if (binder != null && binder.pingBinder()) {
                    shellService = IUserService.Stub.asInterface(binder);
                    setStatus("Ready — Shizuku shell connected.", ACCENT);
                    appendLog("Shizuku UserService connected.");
                } else {
                    shellService = null;
                    setStatus("Shizuku connected, but privileged service is unavailable.", ERROR);
                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            runOnUiThread(() -> {
                shellService = null;
                binding = false;
                setStatus("Privileged service disconnected.", ERROR);
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        displayManager.registerDisplayListener(this, main);

        displaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshModes();
                fillExternalFieldsFromSelectedMode();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        presetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyPresetToFields(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionListener);

        setupPresetSpinner();
        loadSavedProfile();
        refreshDisplays();
        ensureShizuku();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        displayManager.unregisterDisplayListener(this);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        cancelSafetyCountdown(false);
        try {
            if (binding || shellService != null) {
                Shizuku.unbindUserService(serviceArgs, serviceConnection, true);
            }
        } catch (Throwable ignored) { }
        worker.shutdownNow();
    }

    private View buildUi() {
        int p = dp(16);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, dp(28));
        root.setBackgroundColor(BG);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(heroCard(), match());

        LinearLayout statusCard = cardLayout();
        status = text("Checking Shizuku…", 14, true, TEXT);
        status.setPadding(dp(12), dp(10), dp(12), dp(6));
        statusCard.addView(status, match());
        TextView statusHint = text("Start Shizuku first, then grant permission here.", 12, false, MUTED);
        statusHint.setPadding(dp(12), 0, dp(12), dp(6));
        statusCard.addView(statusHint, match());
        Button connect = actionButton("Connect / request Shizuku permission", ACCENT_2);
        connect.setOnClickListener(v -> ensureShizuku());
        statusCard.addView(connect, match());
        root.addView(statusCard, match());

        LinearLayout externalCard = cardLayout();
        addSectionTitle(externalCard, "EXTERNAL MONITOR");
        displaySpinner = darkSpinner();
        externalCard.addView(displaySpinner, match());

        displayInfo = text("No display selected", 13, false, MUTED);
        displayInfo.setPadding(0, dp(8), 0, dp(8));
        externalCard.addView(displayInfo);

        modeSpinner = darkSpinner();
        externalCard.addView(modeSpinner, match());

        LinearLayout extQuick1 = row();
        Button refresh = actionButton("Refresh displays", ACCENT_2);
        refresh.setOnClickListener(v -> refreshDisplays());
        extQuick1.addView(refresh, weight());
        Button bestQuality = actionButton("Best quality", ACCENT);
        bestQuality.setOnClickListener(v -> selectBestQuality());
        extQuick1.addView(bestQuality, weight());
        externalCard.addView(extQuick1, match());

        LinearLayout extQuick2 = row();
        Button best120 = actionButton("Best ≥120 Hz", ACCENT);
        best120.setOnClickListener(v -> selectBest120());
        extQuick2.addView(best120, weight());
        Button applyExternal = actionButton("Apply selected mode", ACCENT);
        applyExternal.setOnClickListener(v -> applySelectedExternalMode());
        extQuick2.addView(applyExternal, weight());
        externalCard.addView(extQuick2, match());

        addMiniLabel(externalCard, "Custom monitor mode");
        LinearLayout extSizeRow = row();
        externalWidth = numberField("Width", "1920");
        externalHeight = numberField("Height", "1080");
        extSizeRow.addView(externalWidth, weight());
        extSizeRow.addView(externalHeight, weight());
        externalCard.addView(extSizeRow, match());

        LinearLayout extInfoRow = row();
        externalHz = decimalField("Hz", "120");
        externalDensity = numberField("DPI (optional)", "");
        extInfoRow.addView(externalHz, weight());
        extInfoRow.addView(externalDensity, weight());
        externalCard.addView(extInfoRow, match());

        LinearLayout extQuick3 = row();
        Button fillFromMode = actionButton("Use selected mode", ACCENT_2);
        fillFromMode.setOnClickListener(v -> fillExternalFieldsFromSelectedMode());
        extQuick3.addView(fillFromMode, weight());
        Button applyCustomExternal = actionButton("Apply custom monitor mode", WARNING);
        applyCustomExternal.setOnClickListener(v -> applyCustomExternalMode());
        extQuick3.addView(applyCustomExternal, weight());
        externalCard.addView(extQuick3, match());

        matchPhoneToMonitor = darkCheckBox("Match phone render to monitor (sharpest mirroring)");
        matchPhoneToMonitor.setChecked(true);
        externalCard.addView(matchPhoneToMonitor);

        disableExternalScaling = darkCheckBox("Disable Android forced scaling on external display");
        disableExternalScaling.setChecked(true);
        externalCard.addView(disableExternalScaling);

        TextView sharpNote = text(
                "Quality tip: when the phone render matches the monitor's pixel grid, mirroring looks much sharper. " +
                        "If you use a 4:3 or iPad-style phone render on a 16:9 monitor, Android may still add black bars or scaling.",
                12, false, MUTED);
        sharpNote.setPadding(0, dp(6), 0, dp(8));
        externalCard.addView(sharpNote);

        safetyText = text("Safety rollback: inactive", 13, true, WARNING);
        externalCard.addView(safetyText);
        keepButton = actionButton("KEEP NEW MODE", ACCENT);
        keepButton.setEnabled(false);
        keepButton.setAlpha(0.65f);
        keepButton.setOnClickListener(v -> cancelSafetyCountdown(true));
        externalCard.addView(keepButton, match());

        LinearLayout restoreRow = row();
        Button restoreExternal = actionButton("Restore selected monitor", ERROR);
        restoreExternal.setOnClickListener(v -> restoreSelectedExternal());
        restoreRow.addView(restoreExternal, weight());
        Button restoreAll = actionButton("Restore all defaults", ERROR);
        restoreAll.setOnClickListener(v -> restoreAllDefaults());
        restoreRow.addView(restoreAll, weight());
        externalCard.addView(restoreRow, match());
        root.addView(externalCard, match());

        LinearLayout phoneCard = cardLayout();
        addSectionTitle(phoneCard, "PHONE / PUBG LOGICAL RESOLUTION");
        TextView currentPreset = text("Use iPad-style aspect ratios to get a more tablet-like view. This changes the render shape, not PUBG's true internal FOV code.", 12, false, MUTED);
        phoneCard.addView(currentPreset);

        presetSpinner = darkSpinner();
        phoneCard.addView(presetSpinner, match());
        presetInfo = text("", 12, false, ACCENT);
        presetInfo.setPadding(0, dp(6), 0, dp(6));
        phoneCard.addView(presetInfo, match());

        HorizontalScrollView presetScroller = new HorizontalScrollView(this);
        presetScroller.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = row();
        chips.setPadding(0, 0, 0, dp(6));
        for (int i = 0; i < PHONE_PRESETS.length; i++) {
            final int index = i;
            Button chip = smallChip(PHONE_PRESETS[i].name);
            chip.setOnClickListener(v -> {
                presetSpinner.setSelection(index);
                applyPresetToFields(index);
            });
            chips.addView(chip);
        }
        presetScroller.addView(chips);
        phoneCard.addView(presetScroller, match());

        LinearLayout sizeRow = row();
        phoneWidth = numberField("Width", "1536");
        phoneHeight = numberField("Height", "2048");
        sizeRow.addView(phoneWidth, weight());
        sizeRow.addView(phoneHeight, weight());
        phoneCard.addView(sizeRow, match());

        phoneDensity = numberField("DPI (optional)", "420");
        phoneCard.addView(phoneDensity, match());

        LinearLayout phoneButtons1 = row();
        Button applyPhone = actionButton("Apply phone size", ACCENT);
        applyPhone.setOnClickListener(v -> applyPhoneCustom());
        phoneButtons1.addView(applyPhone, weight());
        Button resetPhone = actionButton("Reset phone", ERROR);
        resetPhone.setOnClickListener(v -> runCommands("Reset phone", Arrays.asList(
                "wm size reset -d 0", "wm density reset -d 0", "wm scaling auto -d 0")));
        phoneButtons1.addView(resetPhone, weight());
        phoneCard.addView(phoneButtons1, match());

        LinearLayout phoneButtons2 = row();
        Button matchSelected = actionButton("Match phone to selected monitor", ACCENT_2);
        matchSelected.setOnClickListener(v -> matchPhoneOnly());
        phoneButtons2.addView(matchSelected, weight());
        Button applyPreset = actionButton("Apply selected preset", WARNING);
        applyPreset.setOnClickListener(v -> {
            applyPresetToFields(presetSpinner.getSelectedItemPosition());
            applyPhoneCustom();
        });
        phoneButtons2.addView(applyPreset, weight());
        phoneCard.addView(phoneButtons2, match());

        LinearLayout profileRow = row();
        Button saveProfile = actionButton("Save profile", ACCENT_2);
        saveProfile.setOnClickListener(v -> saveCurrentProfile());
        profileRow.addView(saveProfile, weight());
        Button loadProfile = actionButton("Load saved", ACCENT_2);
        loadProfile.setOnClickListener(v -> loadSavedProfile());
        profileRow.addView(loadProfile, weight());
        phoneCard.addView(profileRow, match());
        root.addView(phoneCard, match());

        LinearLayout logCard = cardLayout();
        addSectionTitle(logCard, "COMMAND LOG");
        logView = text("", 12, false, TEXT);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setBackgroundColor(CARD_ALT);
        logView.setPadding(dp(10), dp(10), dp(10), dp(10));
        logCard.addView(logView, match());
        root.addView(logCard, match());

        TextView footer = text("This App is part of VPQCLAN, made by VPQ SNIKA", 12, true, MUTED);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(0, dp(8), 0, dp(8));
        root.addView(footer, match());

        return scroll;
    }

    private View heroCard() {
        LinearLayout card = cardLayout();
        card.setBackgroundColor(CARD_ALT);
        TextView title = text("VPQCLAN Custom Resolution", 25, true, TEXT);
        card.addView(title);
        TextView subtitle = text("VPQCLAN C.R • PUBG + external monitor tool", 13, false, ACCENT);
        subtitle.setPadding(0, dp(4), 0, dp(8));
        card.addView(subtitle);
        TextView desc = text("Advanced custom resolution control with iPad-style view presets, custom monitor modes, profile saving, and safety rollback.", 13, false, MUTED);
        card.addView(desc);
        return card;
    }

    private void setupPresetSpinner() {
        List<String> labels = new ArrayList<>();
        for (Preset p : PHONE_PRESETS) labels.add(p.name);
        ArrayAdapter<String> adapter = spinnerAdapter(labels);
        presetSpinner.setAdapter(adapter);
    }

    private void ensureShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                setStatus("Shizuku is not running. Start Shizuku, then come back.", WARNING);
                return;
            }
            if (Shizuku.isPreV11()) {
                setStatus("This Shizuku version is too old. Use Shizuku v11+.", ERROR);
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Waiting for Shizuku permission…", WARNING);
                Shizuku.requestPermission(REQ_SHIZUKU);
                return;
            }
            bindShellService();
        } catch (Throwable t) {
            setStatus("Shizuku error: " + t.getMessage(), ERROR);
        }
    }

    private void onShizukuBinderReady() {
        runOnUiThread(this::ensureShizuku);
    }

    private void bindShellService() {
        if (shellService != null || binding) return;
        try {
            binding = true;
            setStatus("Connecting privileged shell…", WARNING);
            Shizuku.bindUserService(serviceArgs, serviceConnection);
        } catch (Throwable t) {
            binding = false;
            setStatus("Could not bind Shizuku service: " + t.getMessage(), ERROR);
        }
    }

    private void refreshDisplays() {
        displayList.clear();
        Display[] all = displayManager.getDisplays();
        Arrays.sort(all, (a, b) -> Integer.compare(a.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0,
                b.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0));
        displayList.addAll(Arrays.asList(all));

        List<String> labels = new ArrayList<>();
        for (Display d : displayList) {
            Display.Mode m = d.getMode();
            labels.add(String.format(Locale.US, "%s  [id %d]  %d×%d @ %.2f Hz%s",
                    d.getName(), d.getDisplayId(), m.getPhysicalWidth(), m.getPhysicalHeight(),
                    m.getRefreshRate(), d.getDisplayId() == 0 ? "  (phone)" : ""));
        }
        if (labels.isEmpty()) labels.add("No displays found");
        displaySpinner.setAdapter(spinnerAdapter(labels));
        if (!displayList.isEmpty()) displaySpinner.setSelection(0);
        refreshModes();
    }

    private void refreshModes() {
        modeList.clear();
        Display d = selectedDisplay();
        if (d == null) {
            modeSpinner.setAdapter(spinnerAdapter(Collections.singletonList("No supported modes")));
            displayInfo.setText("No display selected");
            return;
        }

        Display.Mode active = d.getMode();
        List<Display.Mode> modes = new ArrayList<>(Arrays.asList(d.getSupportedModes()));
        modes.sort(Comparator
                .comparingLong((Display.Mode m) -> (long) m.getPhysicalWidth() * m.getPhysicalHeight()).reversed()
                .thenComparing(Comparator.comparingDouble(Display.Mode::getRefreshRate).reversed()));
        modeList.addAll(modes);

        List<String> labels = new ArrayList<>();
        int activeIndex = 0;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            boolean isActive = m.getModeId() == active.getModeId();
            if (isActive) activeIndex = i;
            labels.add(String.format(Locale.US, "%d×%d @ %.2f Hz%s",
                    m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    isActive ? "   • ACTIVE" : ""));
        }
        modeSpinner.setAdapter(spinnerAdapter(labels));
        if (!modeList.isEmpty()) modeSpinner.setSelection(activeIndex);

        displayInfo.setText(String.format(Locale.US,
                "Display id %d • current %d×%d @ %.2f Hz • %d supported mode(s)",
                d.getDisplayId(), active.getPhysicalWidth(), active.getPhysicalHeight(),
                active.getRefreshRate(), modeList.size()));
        displayInfo.setTextColor(MUTED);
    }

    private void fillExternalFieldsFromSelectedMode() {
        Display.Mode m = selectedMode();
        if (m == null) return;
        externalWidth.setText(String.valueOf(m.getPhysicalWidth()));
        externalHeight.setText(String.valueOf(m.getPhysicalHeight()));
        externalHz.setText(String.format(Locale.US, "%.0f", m.getRefreshRate()));
    }

    private void applyPresetToFields(int position) {
        if (position < 0 || position >= PHONE_PRESETS.length) return;
        Preset p = PHONE_PRESETS[position];
        phoneWidth.setText(String.valueOf(p.width));
        phoneHeight.setText(String.valueOf(p.height));
        phoneDensity.setText(String.valueOf(p.dpi));
        presetInfo.setText(p.note + " • " + p.width + "×" + p.height + " • DPI " + p.dpi);
        presetInfo.setTextColor(ACCENT);
    }

    private void selectBestQuality() {
        if (modeList.isEmpty()) return;
        int best = 0;
        long bestPixels = -1;
        float bestHz = -1;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            long px = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (px > bestPixels || (px == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = px;
                bestHz = m.getRefreshRate();
            }
        }
        modeSpinner.setSelection(best);
        fillExternalFieldsFromSelectedMode();
        Toast.makeText(this, "Highest-resolution mode selected", Toast.LENGTH_SHORT).show();
    }

    private void selectBest120() {
        int best = -1;
        long bestPixels = -1;
        float bestHz = -1;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            if (m.getRefreshRate() < 119.0f) continue;
            long px = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (px > bestPixels || (px == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = px;
                bestHz = m.getRefreshRate();
            }
        }
        if (best < 0) {
            Toast.makeText(this, "This display reports no ≥120 Hz mode", Toast.LENGTH_LONG).show();
        } else {
            modeSpinner.setSelection(best);
            fillExternalFieldsFromSelectedMode();
            Toast.makeText(this, "Best ≥120 Hz mode selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void applySelectedExternalMode() {
        Display d = selectedDisplay();
        Display.Mode m = selectedMode();
        if (d == null || m == null) return;
        if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor, not display 0.", Toast.LENGTH_LONG).show();
            return;
        }
        applyExternalModeInternal(d.getDisplayId(), m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(), externalDensity.getText().toString().trim());
    }

    private void applyCustomExternalMode() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select an external display first.", Toast.LENGTH_LONG).show();
            return;
        }
        Integer w = parseInt(externalWidth.getText().toString());
        Integer h = parseInt(externalHeight.getText().toString());
        Float hz = parseFloat(externalHz.getText().toString());
        if (w == null || h == null || w < 640 || h < 480 || hz == null || hz <= 0f) {
            Toast.makeText(this, "Enter valid custom monitor width, height and Hz.", Toast.LENGTH_LONG).show();
            return;
        }
        applyExternalModeInternal(d.getDisplayId(), w, h, hz, externalDensity.getText().toString().trim());
    }

    private void applyExternalModeInternal(int displayId, int w, int h, float hz, String dpiText) {
        if (!requireShell()) return;
        final boolean matchPhone = matchPhoneToMonitor.isChecked();
        final boolean scalingOff = disableExternalScaling.isChecked();
        final Integer density = parseInt(dpiText);

        worker.execute(() -> {
            try {
                RevertState state = captureRevertState(displayId, matchPhone);
                StringBuilder result = new StringBuilder();

                result.append(execPriv(String.format(Locale.US,
                        "cmd display set-user-preferred-display-mode %d %d %.3f %d",
                        w, h, hz, displayId))).append('\n');

                result.append(execPriv("wm size reset -d " + displayId)).append('\n');
                result.append(execPriv("wm density reset -d " + displayId)).append('\n');
                if (density != null && density >= 72 && density <= 1000) {
                    result.append(execPriv("wm density " + density + " -d " + displayId)).append('\n');
                }
                if (scalingOff) {
                    result.append(execPriv("wm scaling off -d " + displayId)).append('\n');
                }

                if (matchPhone) {
                    result.append(execPriv("wm size " + h + "x" + w + " -d 0")).append('\n');
                }

                pendingRevert = state;
                runOnUiThread(() -> {
                    appendLog("APPLY display " + displayId + ": " + w + "×" + h + " @ " + hz + " Hz");
                    appendLog(result.toString());
                    startSafetyCountdown();
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Apply failed: " + t));
            }
        });
    }

    private RevertState captureRevertState(int displayId, boolean capturePhone) throws RemoteException {
        RevertState s = new RevertState();
        s.displayId = displayId;
        s.preferredMode = execPriv("cmd display get-user-preferred-display-mode " + displayId);
        s.externalSize = execPriv("wm size -d " + displayId);
        s.externalDensity = execPriv("wm density -d " + displayId);
        if (capturePhone) {
            s.phoneSize = execPriv("wm size -d 0");
            s.phoneDensity = execPriv("wm density -d 0");
        }
        return s;
    }

    private void startSafetyCountdown() {
        cancelSafetyCountdown(false);
        keepButton.setEnabled(true);
        keepButton.setAlpha(1f);
        safetyDeadline = System.currentTimeMillis() + SAFETY_MS;
        autoRevertRunnable = () -> {
            RevertState state = pendingRevert;
            pendingRevert = null;
            if (state != null) {
                restoreState(state, "Safety rollback");
            }
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.65f);
            safetyText.setText("Safety rollback: reverted");
            safetyText.setTextColor(ERROR);
        };
        main.postDelayed(autoRevertRunnable, SAFETY_MS);
        tickSafety();
    }

    private void tickSafety() {
        if (autoRevertRunnable == null) return;
        long remain = Math.max(0, safetyDeadline - System.currentTimeMillis());
        safetyText.setText("Safety rollback in " + ((remain + 999) / 1000) + " s — tap KEEP if picture is good");
        safetyText.setTextColor(WARNING);
        if (remain > 0) main.postDelayed(this::tickSafety, 500);
    }

    private void cancelSafetyCountdown(boolean keep) {
        if (autoRevertRunnable != null) main.removeCallbacks(autoRevertRunnable);
        autoRevertRunnable = null;
        if (keep) {
            pendingRevert = null;
            safetyText.setText("Safety rollback: mode kept");
            safetyText.setTextColor(ACCENT);
            appendLog("Mode confirmed by user.");
        } else if (pendingRevert == null) {
            safetyText.setText("Safety rollback: inactive");
            safetyText.setTextColor(WARNING);
        }
        if (keepButton != null) {
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.65f);
        }
    }

    private void restoreState(RevertState state, String reason) {
        if (!requireShell()) return;
        worker.execute(() -> {
            try {
                List<String> cmds = new ArrayList<>();
                cmds.add(preferredModeRestoreCommand(state.displayId, state.preferredMode));
                cmds.add(sizeRestoreCommand(state.displayId, state.externalSize));
                cmds.add(densityRestoreCommand(state.displayId, state.externalDensity));
                cmds.add("wm scaling auto -d " + state.displayId);
                if (state.phoneSize != null) cmds.add(sizeRestoreCommand(0, state.phoneSize));
                if (state.phoneDensity != null) cmds.add(densityRestoreCommand(0, state.phoneDensity));
                StringBuilder out = new StringBuilder();
                for (String c : cmds) out.append("$ ").append(c).append('\n').append(execPriv(c)).append('\n');
                runOnUiThread(() -> {
                    appendLog(reason + "\n" + out);
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Rollback failed: " + t));
            }
        });
    }

    private String preferredModeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("User preferred display mode:\\s*(\\d+)\\s+(\\d+)\\s+([0-9.]+)")
                .matcher(output == null ? "" : output);
        if (m.find()) {
            return "cmd display set-user-preferred-display-mode " + m.group(1) + " " + m.group(2) + " " + m.group(3) + " " + displayId;
        }
        return "cmd display clear-user-preferred-display-mode " + displayId;
    }

    private String sizeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override size:\\s*(\\d+)x(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm size " + m.group(1) + "x" + m.group(2) + " -d " + displayId;
        return "wm size reset -d " + displayId;
    }

    private String densityRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override density:\\s*(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm density " + m.group(1) + " -d " + displayId;
        return "wm density reset -d " + displayId;
    }

    private void restoreSelectedExternal() {
        Display d = selectedDisplay();
        if (d == null) return;
        int id = d.getDisplayId();
        if (id == 0) {
            Toast.makeText(this, "Display 0 is the phone.", Toast.LENGTH_SHORT).show();
            return;
        }
        cancelSafetyCountdown(false);
        runCommands("Restore display " + id, Arrays.asList(
                "cmd display clear-user-preferred-display-mode " + id,
                "wm size reset -d " + id,
                "wm density reset -d " + id,
                "wm scaling auto -d " + id));
    }

    private void restoreAllDefaults() {
        Display d = selectedDisplay();
        int id = d == null ? -1 : d.getDisplayId();
        cancelSafetyCountdown(false);
        List<String> cmds = new ArrayList<>();
        if (id > 0) {
            cmds.add("cmd display clear-user-preferred-display-mode " + id);
            cmds.add("wm size reset -d " + id);
            cmds.add("wm density reset -d " + id);
            cmds.add("wm scaling auto -d " + id);
        }
        cmds.add("wm size reset -d 0");
        cmds.add("wm density reset -d 0");
        cmds.add("wm scaling auto -d 0");
        runCommands("Restore defaults", cmds);
    }

    private void applyPhoneCustom() {
        Integer w = parseInt(phoneWidth.getText().toString());
        Integer h = parseInt(phoneHeight.getText().toString());
        if (w == null || h == null || w < 480 || h < 480) {
            Toast.makeText(this, "Enter a valid width and height.", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> cmds = new ArrayList<>();
        cmds.add("wm size " + w + "x" + h + " -d 0");
        String dpi = phoneDensity.getText().toString().trim();
        if (!dpi.isEmpty()) {
            Integer d = parseInt(dpi);
            if (d != null && d >= 72 && d <= 1000) cmds.add("wm density " + d + " -d 0");
        }
        runCommands("Apply phone logical size", cmds);
    }

    private void matchPhoneOnly() {
        Display.Mode m = selectedMode();
        if (m == null) return;
        runCommands("Match phone to monitor", Collections.singletonList(
                "wm size " + m.getPhysicalHeight() + "x" + m.getPhysicalWidth() + " -d 0"));
    }

    private void saveCurrentProfile() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit()
                .putString("phoneWidth", phoneWidth.getText().toString())
                .putString("phoneHeight", phoneHeight.getText().toString())
                .putString("phoneDensity", phoneDensity.getText().toString())
                .putString("externalWidth", externalWidth.getText().toString())
                .putString("externalHeight", externalHeight.getText().toString())
                .putString("externalHz", externalHz.getText().toString())
                .putString("externalDensity", externalDensity.getText().toString())
                .putBoolean("matchPhone", matchPhoneToMonitor.isChecked())
                .putBoolean("disableScaling", disableExternalScaling.isChecked())
                .putInt("presetIndex", presetSpinner.getSelectedItemPosition())
                .apply();
        Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
        appendLog("Profile saved locally.");
    }

    private void loadSavedProfile() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        phoneWidth.setText(sp.getString("phoneWidth", "1536"));
        phoneHeight.setText(sp.getString("phoneHeight", "2048"));
        phoneDensity.setText(sp.getString("phoneDensity", "420"));
        externalWidth.setText(sp.getString("externalWidth", "1920"));
        externalHeight.setText(sp.getString("externalHeight", "1080"));
        externalHz.setText(sp.getString("externalHz", "120"));
        externalDensity.setText(sp.getString("externalDensity", ""));
        matchPhoneToMonitor.setChecked(sp.getBoolean("matchPhone", true));
        disableExternalScaling.setChecked(sp.getBoolean("disableScaling", true));
        int preset = sp.getInt("presetIndex", 1);
        if (preset < 0 || preset >= PHONE_PRESETS.length) preset = 1;
        presetSpinner.setAdapter(spinnerAdapter(presetLabels()));
        presetSpinner.setSelection(preset);
        applyPresetToFields(preset);
        appendLog("Profile loaded.");
    }

    private List<String> presetLabels() {
        List<String> labels = new ArrayList<>();
        for (Preset p : PHONE_PRESETS) labels.add(p.name);
        return labels;
    }

    private void runCommands(String title, List<String> commands) {
        if (!requireShell()) return;
        worker.execute(() -> {
            StringBuilder out = new StringBuilder();
            try {
                for (String c : commands) {
                    out.append("$ ").append(c).append('\n');
                    out.append(execPriv(c)).append('\n');
                }
            } catch (Throwable t) {
                out.append("ERROR: ").append(t);
            }
            runOnUiThread(() -> {
                appendLog(title + "\n" + out);
                refreshDisplays();
            });
        });
    }

    private String execPriv(String command) throws RemoteException {
        IUserService s = shellService;
        if (s == null) throw new RemoteException("Shizuku UserService is not connected");
        return s.exec(command);
    }

    private boolean requireShell() {
        if (shellService != null) return true;
        Toast.makeText(this, "Connect Shizuku first.", Toast.LENGTH_LONG).show();
        ensureShizuku();
        return false;
    }

    private Display selectedDisplay() {
        int p = displaySpinner.getSelectedItemPosition();
        if (p < 0 || p >= displayList.size()) return null;
        return displayList.get(p);
    }

    private Display.Mode selectedMode() {
        int p = modeSpinner.getSelectedItemPosition();
        if (p < 0 || p >= modeList.size()) return null;
        return modeList.get(p);
    }

    private void setStatus(String s, int color) {
        status.setText(s);
        status.setTextColor(color);
    }

    private void appendLog(String s) {
        String old = logView.getText().toString();
        if (old.length() > 9000) old = old.substring(old.length() - 7000);
        logView.setText(old + (old.isEmpty() ? "" : "\n\n") + s.trim());
    }

    @Override public void onDisplayAdded(int displayId) { refreshDisplays(); }
    @Override public void onDisplayRemoved(int displayId) { refreshDisplays(); }
    @Override public void onDisplayChanged(int displayId) { refreshDisplays(); }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button actionButton(String s, int bgColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setBackgroundColor(bgColor);
        return b;
    }

    private Button smallChip(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTextSize(12f);
        b.setBackgroundColor(CARD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(p);
        return b;
    }

    private EditText numberField(String hint, String value) {
        EditText e = darkEditText(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private EditText decimalField(String hint, String value) {
        EditText e = darkEditText(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private EditText darkEditText(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setBackgroundColor(CARD_ALT);
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        return e;
    }

    private CheckBox darkCheckBox(String text) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(TEXT);
        return c;
    }

    private Spinner darkSpinner() {
        Spinner s = new Spinner(this);
        s.setBackgroundColor(CARD_ALT);
        return s;
    }

    private ArrayAdapter<String> spinnerAdapter(List<String> items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(TEXT);
                    ((TextView) v).setBackgroundColor(CARD_ALT);
                    ((TextView) v).setPadding(dp(8), dp(8), dp(8), dp(8));
                }
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(TEXT);
                    ((TextView) v).setBackgroundColor(CARD);
                }
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private void addSectionTitle(LinearLayout root, String title) {
        TextView t = text(title, 15, true, TEXT);
        t.setPadding(0, 0, 0, dp(8));
        root.addView(t);
    }

    private void addMiniLabel(LinearLayout root, String title) {
        TextView t = text(title, 12, true, ACCENT);
        t.setPadding(0, dp(8), 0, dp(4));
        root.addView(t);
    }

    private LinearLayout cardLayout() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(CARD);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(p);
        return card;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Integer parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Throwable t) { return null; }
    }

    private Float parseFloat(String s) {
        try { return Float.parseFloat(s.trim()); } catch (Throwable t) { return null; }
    }

    private static class RevertState {
        int displayId;
        String preferredMode;
        String externalSize;
        String externalDensity;
        String phoneSize;
        String phoneDensity;
    }

    private static class Preset {
        final String name;
        final int width;
        final int height;
        final int dpi;
        final String note;

        Preset(String name, int width, int height, int dpi, String note) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.dpi = dpi;
            this.note = note;
        }
    }
}
