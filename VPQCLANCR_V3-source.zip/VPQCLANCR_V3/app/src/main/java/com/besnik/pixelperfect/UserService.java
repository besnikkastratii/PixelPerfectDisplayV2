package com.besnik.pixelperfect;

import android.content.Context;
import android.os.RemoteException;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Runs inside Shizuku's shell/root process.  Do not put UI code here.
 */
public class UserService extends IUserService.Stub {

    public UserService() {
    }

    // Shizuku API v13+ may prefer this constructor.
    public UserService(Context context) {
    }

    @Override
    public void destroy() throws RemoteException {
        System.exit(0);
    }

    @Override
    public String exec(String command) throws RemoteException {
        StringBuilder out = new StringBuilder();
        try {
            Process process = new ProcessBuilder("/system/bin/sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    out.append(line).append('\n');
                }
            }

            int code = process.waitFor();
            out.append("[exit=").append(code).append("]");
        } catch (Throwable t) {
            out.append("ERROR: ").append(t.getClass().getSimpleName())
                    .append(": ").append(t.getMessage());
        }
        return out.toString();
    }
}
