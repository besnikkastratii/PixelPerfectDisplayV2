# VPQCLAN C.R V4.6

Package: `com.besnik.pixelperfect`

V4.6 keeps the clean performance-monitor home page and moves display tools to the separate Custom Resolution screen.

## Main page
- FPS overlay with SurfaceFlinger layer latency, TimeStats, gfxinfo and compositor fallback.
- CPU / SoC temperature overlay.
- Battery temperature overlay.
- Root-first privileged backend with persistent Shizuku fallback.
- Direct `su` root and Shizuku-as-UID-0 are both recognized as root-capable.

## Custom Resolution Tools
- Existing Game View, Navigation Safe DPI, profiles, monitor physical mode, logical output, reset and safety rollback.
- New **CRYSTAL ROOT ENGINE**.
- PUBG package detection plus manual package entry.
- Uniform X/Y inverse scaling presets: 1.25x, 1.33x, 1.43x, 1.67x and 2.00x.
- Uses Android compatibility changes `DOWNSCALED_INVERSE` (273564678) and the matching inverse factor change.
- Reads `dumpsys platform_compat` after applying and reports whether Android exposed the package override.
- Reset Crystal removes the V4.6 inverse/factor overrides.

## Important
Crystal mode does not edit PUBG files or process memory. Android/OEM production builds can still reject per-app compatibility overrides even with a root shell; V4.6 reports this rather than claiming the mode is active. A higher internal/app-space request also cannot create physical pixels that the phone panel or external monitor does not have.

Footer: `This App is part of VPQCLAN, made by VPQ SNIKA`
