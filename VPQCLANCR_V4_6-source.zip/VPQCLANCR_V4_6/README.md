# VPQCLAN C.R V4.6

V4.6 keeps the simplified performance-monitor layout and separate Custom Resolution Tools screen from V4.5, with the version bumped for the next release.

## Main page
- FPS overlay
- CPU temperature overlay
- Battery temperature overlay
- Independent draggable positions
- Lock / touch-through mode
- Shizuku connection status and direct Shizuku launch when it is not running
- One button opens Custom Resolution Tools

## CPU temperature
- First uses Android thermalservice CPU sensors (TYPE_CPU / CPU/SoC names)
- Falls back to CPU/SoC thermal zones under `/sys/class/thermal`
- Excludes battery, GPU, skin, USB and charger sensors
- Stores the selected sensor name for diagnostics

## FPS V4.6
FPS collection now uses multiple methods in order:
1. SurfaceFlinger per-layer latency
2. SurfaceFlinger TimeStats (`averageFPS`) for the active game layer/package
3. `gfxinfo framestats`
4. Display compositor cadence as an approximate `FPS~` fallback

TimeStats is enabled through Shizuku and reset when the foreground game package changes so native-rendered games have a better chance of returning a real frame rate.

## Custom Resolution screen
The existing Game View, Navigation Safe, saved profiles, external monitor physical mode, forced logical output, safety rollback and diagnostics are preserved in `CustomResolutionActivity`.

The old USB audio and other gaming-tool controls are removed from the visible UI in this version.
