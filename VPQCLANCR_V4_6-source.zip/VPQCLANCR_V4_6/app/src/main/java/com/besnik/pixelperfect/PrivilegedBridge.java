package com.besnik.pixelperfect;

import android.content.Context;
import android.os.RemoteException;

/** Root-first privileged shell with Shizuku fallback, including Shizuku started as UID 0. */
public final class PrivilegedBridge {
    private static volatile Boolean shizukuRoot;

    private PrivilegedBridge() { }

    public static void init(Context context) {
        ShizukuBridge.init(context);
        RootBridge.probeAsync((state, message) -> { });
        refreshShizukuRootAsync();
    }

    public static boolean isReady() {
        return RootBridge.isReady() || ShizukuBridge.isReady();
    }

    public static boolean isRootCapable() {
        return RootBridge.isReady() || Boolean.TRUE.equals(shizukuRoot);
    }

    public static String rootBackendLabel() {
        if (RootBridge.isReady()) return "ROOT direct";
        if (Boolean.TRUE.equals(shizukuRoot)) return "SHIZUKU root";
        return "root unavailable";
    }

    public static String backendLabel() {
        if (RootBridge.isReady()) return "ROOT";
        if (Boolean.TRUE.equals(shizukuRoot)) return "SHIZUKU ROOT";
        if (ShizukuBridge.isReady()) return "SHIZUKU";
        if (RootBridge.getState() == RootBridge.State.CHECKING) return "ROOT CHECKING";
        return "WAITING";
    }

    public static void refreshShizukuRootAsync() {
        if (!ShizukuBridge.isReady()) {
            shizukuRoot = null;
            return;
        }
        new Thread(() -> {
            try {
                String id = ShizukuBridge.exec("id", 3000L);
                shizukuRoot = id != null && id.contains("uid=0");
            } catch (Throwable t) {
                shizukuRoot = false;
            }
        }, "vpq-shizuku-root-probe").start();
    }

    public static IUserService awaitService(long timeoutMs) throws RemoteException {
        IUserService root = RootBridge.getService();
        if (root != null) return root;
        if (RootBridge.getState() == RootBridge.State.UNKNOWN) {
            RootBridge.probeBlocking(Math.min(3000L, timeoutMs));
            root = RootBridge.getService();
            if (root != null) return root;
        }
        return ShizukuBridge.awaitService(timeoutMs);
    }

    public static String exec(String command, long timeoutMs) throws RemoteException {
        IUserService service = awaitService(timeoutMs);
        return service.exec(command);
    }

    /** Execute only when the selected backend really has UID 0. */
    public static String execRoot(String command, long timeoutMs) throws Exception {
        if (!RootBridge.isReady()) RootBridge.probeBlocking(Math.min(timeoutMs, 5000L));
        if (RootBridge.isReady()) return RootBridge.exec(command, timeoutMs);
        if (ShizukuBridge.isReady()) {
            String id = ShizukuBridge.exec("id", Math.min(timeoutMs, 3000L));
            boolean root = id != null && id.contains("uid=0");
            shizukuRoot = root;
            if (root) return ShizukuBridge.exec(command, timeoutMs);
        }
        throw new SecurityException("A UID 0 backend is required");
    }
}
