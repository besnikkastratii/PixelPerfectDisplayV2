package com.besnik.pixelperfect;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.provider.Settings;
import android.text.InputType;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CustomResolutionActivity extends Activity implements DisplayManager.DisplayListener, ShizukuBridge.Listener {

    private static final int REQ_SHIZUKU = 4102;
    private static final long SAFETY_MS = 15_000L;
    private static final String PREFS = "vpqclan_cr_v4";
    private static final String KEY_PROFILES = "profiles_json";

    private static final int BG = Color.parseColor("#0F1011");
    private static final int CARD = Color.parseColor("#17181A");
    private static final int FIELD = Color.parseColor("#202225");
    private static final int FIELD_2 = Color.parseColor("#25272A");
    private static final int TEXT = Color.parseColor("#F4F1EA");
    private static final int MUTED = Color.parseColor("#A5A19A");
    private static final int ACCENT = Color.parseColor("#C8A96B");
    private static final int ACCENT_DARK = Color.parseColor("#6F5D3D");
    private static final int BORDER = Color.parseColor("#303236");
    private static final int DANGER = Color.parseColor("#8A4D4D");

    private static final BuiltInPreset[] BUILT_INS = new BuiltInPreset[] {
            new BuiltInPreset("iPad View Classic", 1536, 2048, 420, "4:3 tablet-style view"),
            new BuiltInPreset("iPad View Plus", 1728, 2304, 440, "Stronger 4:3 tablet-style view"),
            new BuiltInPreset("Tablet View Safe", 1440, 1920, 420, "Safer 4:3-style preset"),
            new BuiltInPreset("Balanced 16:10", 1200, 1920, 420, "Your original stable style"),
            new BuiltInPreset("Balanced 3:2", 1440, 2160, 440, "Tall tablet-style preset"),
            new BuiltInPreset("16:9 Clean", 1080, 1920, 420, "Standard 16:9-style render")
    };

    private static final CrystalPreset[] CRYSTAL_PRESETS = new CrystalPreset[] {
            new CrystalPreset("Crystal 1.25×  • recommended", 1.25f, 176926753L, "DOWNSCALE_80"),
            new CrystalPreset("Crystal 1.33×", 1.333333f, 189969779L, "DOWNSCALE_75"),
            new CrystalPreset("Crystal 1.43×", 1.428571f, 176926829L, "DOWNSCALE_70"),
            new CrystalPreset("Crystal 1.67×", 1.666667f, 176926771L, "DOWNSCALE_60"),
            new CrystalPreset("Ultra 2.00×  • very heavy", 2.0f, 176926741L, "DOWNSCALE_50")
    };

    private static final long CRYSTAL_INVERSE_ID = 273564678L;
    private static final long[] CRYSTAL_FACTOR_IDS = {176926753L, 189969779L, 176926829L, 176926771L, 176926741L};
    private static final String[] PUBG_PACKAGES = {
            "com.tencent.ig", "com.pubg.imobile", "com.vng.pubgmobile",
            "com.rekoo.pubgm", "com.pubg.krmobile", "com.pubg.newstate"
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private TextView status;
    private TextView presetHint;
    private TextView displayInfo;
    private TextView monitorStatus;
    private TextView safetyText;
    private TextView logView;
    private TextView fpsDiagnosticsText;

    private Spinner presetSpinner;
    private Spinner displaySpinner;
    private Spinner modeSpinner;
    private Spinner crystalPresetSpinner;


    private EditText profileName;
    private EditText phoneWidth;
    private EditText phoneHeight;
    private EditText phoneDensity;
    private CheckBox navigationSafe;
    private TextView navigationSafeInfo;
    private EditText externalWidth;
    private EditText externalHeight;
    private EditText externalHz;
    private EditText externalDensity;
    private EditText crystalPackage;
    private TextView crystalPreview;
    private TextView crystalStatus;

    private Button keepButton;
    private Button diagnosticsButton;

    private DisplayManager displayManager;
    private final List<Display> displayList = new ArrayList<>();
    private final List<Display.Mode> modeList = new ArrayList<>();
    private final List<PresetEntry> presetEntries = new ArrayList<>();

    private final ArrayDeque<PendingShellAction> pendingShellActions = new ArrayDeque<>();

    private RevertState pendingRevert;
    private Runnable autoRevertRunnable;
    private long safetyDeadline;

    private final Runnable fpsDiagnosticsUpdater = new Runnable() {
        @Override
        public void run() {
            refreshFpsDiagnosticsText();
            main.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        displayManager.registerDisplayListener(this, main);

        PrivilegedBridge.init(this);
        ShizukuBridge.addListener(this);

        presetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyPresetSelection(position);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        displaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshModes();
                fillExternalFromSelectedMode();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        refreshPresetDropdown(null);
        refreshDisplays();
        ensureShizuku();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        displayManager.unregisterDisplayListener(this);
        ShizukuBridge.removeListener(this);
        main.removeCallbacks(fpsDiagnosticsUpdater);
        cancelSafetyCountdown(false);
        worker.shutdownNow();
    }

    private View buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);

        ImageView wallpaper = new ImageView(this);
        wallpaper.setImageResource(com.besnik.pixelperfect.R.drawable.vpqclan_wallpaper);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setAlpha(0.25f);
        frame.addView(wallpaper, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(26));
        root.setBackgroundColor(Color.TRANSPARENT);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(buildHeader(), matchWithBottom(14));
        root.addView(buildStatusCard(), matchWithBottom(14));
        root.addView(buildGameCard(), matchWithBottom(14));
        root.addView(buildCrystalRootCard(), matchWithBottom(14));
        root.addView(buildMonitorCard(), matchWithBottom(14));
        root.addView(buildSafetyCard(), matchWithBottom(14));
        root.addView(buildDiagnosticsCard(), matchWithBottom(14));

        TextView footer = label("This App is part of VPQCLAN, made by VPQ SNIKA", 12, true, MUTED);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(0, dp(6), 0, 0);
        root.addView(footer, match());

        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return frame;
    }

    private View buildHeader() {
        LinearLayout box = vertical();
        box.setPadding(dp(2), dp(4), dp(2), dp(4));

        TextView brand = label("VPQCLAN Custom Resolution", 26, true, TEXT);
        box.addView(brand, match());

        TextView app = label("VPQCLAN C.R  •  V4.6", 13, true, ACCENT);
        app.setPadding(0, dp(4), 0, dp(5));
        box.addView(app, match());

        TextView sub = label("Game view, physical monitor mode and forced output are separate.", 13, false, MUTED);
        box.addView(sub, match());

        Button back = button("← Performance Monitor", false);
        back.setOnClickListener(v -> finish());
        box.addView(back, matchWithTop(10));
        return box;
    }

    private View buildStatusCard() {
        LinearLayout card = card();
        LinearLayout row = row();
        LinearLayout textCol = vertical();
        textCol.setPadding(0, 0, dp(8), 0);

        TextView title = label("Privilege Backend", 14, true, TEXT);
        textCol.addView(title);
        status = label("Checking…", 13, true, MUTED);
        textCol.addView(status);
        row.addView(textCol, weight());

        Button connect = button("Root / Shizuku", false);
        connect.setOnClickListener(v -> connectPrivileges());
        row.addView(connect, wrap());
        card.addView(row, match());
        return card;
    }

    private View buildGameCard() {
        LinearLayout card = card();
        sectionTitle(card, "Game View");
        mutedText(card, "Choose a built-in preset or one of your saved custom profiles.");

        presetSpinner = spinner();
        card.addView(presetSpinner, matchWithTop(10));
        presetHint = label("", 12, false, MUTED);
        presetHint.setPadding(dp(2), dp(6), dp(2), 0);
        card.addView(presetHint, match());

        miniTitle(card, "Resolution");
        LinearLayout size = row();
        phoneWidth = numberField("Width", "1536");
        phoneHeight = numberField("Height", "2048");
        size.addView(phoneWidth, weight());
        size.addView(phoneHeight, weight());
        card.addView(size, match());

        phoneDensity = numberField("DPI", "420");
        card.addView(phoneDensity, matchWithTop(8));

        navigationSafe = new CheckBox(this);
        navigationSafe.setText("Navigation Safe  •  auto DPI (recommended)");
        navigationSafe.setTextColor(TEXT);
        navigationSafe.setTextSize(13f);
        navigationSafe.setChecked(true);
        navigationSafe.setPadding(dp(2), dp(8), dp(2), 0);
        navigationSafe.setOnCheckedChangeListener((buttonView, isChecked) -> updateNavigationSafeUi());
        card.addView(navigationSafe, match());

        navigationSafeInfo = label("Auto DPI will be calculated from the phone's physical display when you apply.",
                12, false, MUTED);
        navigationSafeInfo.setPadding(dp(2), dp(4), dp(2), 0);
        card.addView(navigationSafeInfo, match());
        updateNavigationSafeUi();

        LinearLayout gameActions = row();
        Button applyGame = button("Apply Game View", true);
        applyGame.setOnClickListener(v -> applyPhoneCustom());
        gameActions.addView(applyGame, weight());

        Button resetGame = button("Reset", false);
        resetGame.setOnClickListener(v -> runCommands("Reset game view", Arrays.asList(
                "wm size reset -d 0",
                "wm density reset -d 0",
                "wm scaling auto -d 0")));
        gameActions.addView(resetGame, weight());
        card.addView(gameActions, matchWithTop(8));

        divider(card);
        miniTitle(card, "Save Custom Profile");
        profileName = textField("Profile name", "");
        card.addView(profileName, match());

        LinearLayout profileActions = row();
        Button save = button("Save / Update", true);
        save.setOnClickListener(v -> saveProfile());
        profileActions.addView(save, weight());

        Button delete = button("Delete Selected", false);
        delete.setTextColor(Color.parseColor("#E0A0A0"));
        delete.setOnClickListener(v -> deleteSelectedProfile());
        profileActions.addView(delete, weight());
        card.addView(profileActions, matchWithTop(8));

        return card;
    }

    private View buildCrystalRootCard() {
        LinearLayout card = card();
        sectionTitle(card, "CRYSTAL ROOT ENGINE");
        mutedText(card, "Root-first per-app inverse buffer scaling. Same X/Y factor preserves aspect ratio automatically. PUBG files and process memory are not modified.");

        crystalPackage = textField("Game package", "com.tencent.ig");
        card.addView(crystalPackage, matchWithTop(10));

        Button detect = button("Detect Running PUBG", false);
        detect.setOnClickListener(v -> detectRunningPubg());
        card.addView(detect, matchWithTop(8));

        List<String> presetNames = new ArrayList<>();
        for (CrystalPreset preset : CRYSTAL_PRESETS) presetNames.add(preset.name);
        crystalPresetSpinner = spinner();
        crystalPresetSpinner.setAdapter(spinnerAdapter(presetNames));
        crystalPresetSpinner.setSelection(0);
        crystalPresetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { updateCrystalPreview(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        card.addView(crystalPresetSpinner, matchWithTop(8));

        crystalPreview = label("", 12, true, ACCENT);
        crystalPreview.setPadding(dp(2), dp(8), dp(2), 0);
        card.addView(crystalPreview, match());

        TextView lock = label("Aspect lock: ON • identical horizontal/vertical scaling", 11, false, MUTED);
        lock.setPadding(dp(2), dp(4), dp(2), 0);
        card.addView(lock, match());

        LinearLayout actions = row();
        Button apply = button("APPLY CRYSTAL", true);
        apply.setOnClickListener(v -> applyCrystalMode());
        actions.addView(apply, weight());

        Button reset = button("Reset Crystal", false);
        reset.setOnClickListener(v -> resetCrystalMode());
        actions.addView(reset, weight());
        card.addView(actions, matchWithTop(10));

        crystalStatus = label("Root is required for Crystal mode. Android will be asked to apply and then report the compat override.", 11, false, MUTED);
        crystalStatus.setPadding(dp(2), dp(8), dp(2), 0);
        card.addView(crystalStatus, match());

        updateCrystalPreview();
        return card;
    }

    private View buildMonitorCard() {
        LinearLayout card = card();
        sectionTitle(card, "Monitor Output");
        mutedText(card, "Physical resolution/Hz and forced logical output are independent.");

        displaySpinner = spinner();
        card.addView(displaySpinner, matchWithTop(10));

        displayInfo = label("No display selected", 12, false, MUTED);
        displayInfo.setPadding(dp(2), dp(6), dp(2), dp(6));
        card.addView(displayInfo, match());

        miniTitle(card, "Physical Monitor Mode");
        modeSpinner = spinner();
        card.addView(modeSpinner, match());

        LinearLayout quick = row();
        Button best = button("Best Quality", false);
        best.setOnClickListener(v -> selectBestQuality());
        quick.addView(best, weight());

        Button best120 = button("Best ≥120 Hz", false);
        best120.setOnClickListener(v -> selectBest120());
        quick.addView(best120, weight());
        card.addView(quick, matchWithTop(8));

        Button applySelected = button("Apply Physical Mode", true);
        applySelected.setOnClickListener(v -> applySelectedExternalMode());
        card.addView(applySelected, matchWithTop(8));

        divider(card);
        miniTitle(card, "Forced Logical Output");
        mutedText(card, "Use any logical width/height here. Android scales it to the monitor's real physical mode.");

        LinearLayout extSize = row();
        externalWidth = numberField("Width", "1920");
        externalHeight = numberField("Height", "1080");
        extSize.addView(externalWidth, weight());
        extSize.addView(externalHeight, weight());
        card.addView(extSize, matchWithTop(8));

        LinearLayout extMeta = row();
        externalDensity = numberField("DPI (optional)", "");
        externalHz = decimalField("Saved Hz", "120");
        extMeta.addView(externalDensity, weight());
        extMeta.addView(externalHz, weight());
        card.addView(extMeta, matchWithTop(8));

        LinearLayout customActions = row();
        Button copy = button("Use Physical Size", false);
        copy.setOnClickListener(v -> fillExternalFromSelectedMode());
        customActions.addView(copy, weight());

        Button forceLogical = button("Force Logical Output", true);
        forceLogical.setOnClickListener(v -> applyCustomExternalMode());
        customActions.addView(forceLogical, weight());
        card.addView(customActions, matchWithTop(8));

        LinearLayout resetRow = row();
        Button resetLogical = button("Reset Forced Output", false);
        resetLogical.setOnClickListener(v -> resetForcedLogicalOutput());
        resetRow.addView(resetLogical, weight());

        Button restoreMonitor = button("Restore Monitor", false);
        restoreMonitor.setOnClickListener(v -> restoreSelectedExternal());
        resetRow.addView(restoreMonitor, weight());
        card.addView(resetRow, matchWithTop(8));

        monitorStatus = label("No forced output applied in this session.", 12, false, MUTED);
        monitorStatus.setPadding(dp(2), dp(10), dp(2), 0);
        card.addView(monitorStatus, match());

        return card;
    }

    private View buildSafetyCard() {
        LinearLayout card = card();
        sectionTitle(card, "Safety");
        safetyText = label("Safety rollback: inactive", 13, true, MUTED);
        card.addView(safetyText, match());

        keepButton = button("KEEP NEW OUTPUT", true);
        keepButton.setEnabled(false);
        keepButton.setAlpha(0.5f);
        keepButton.setOnClickListener(v -> cancelSafetyCountdown(true));
        card.addView(keepButton, matchWithTop(8));

        Button restoreAll = button("Restore Everything", false);
        restoreAll.setTextColor(Color.parseColor("#E0A0A0"));
        restoreAll.setOnClickListener(v -> restoreAllDefaults());
        card.addView(restoreAll, matchWithTop(8));
        return card;
    }

    private View buildDiagnosticsCard() {
        LinearLayout card = card();
        diagnosticsButton = button("Show Diagnostics", false);
        diagnosticsButton.setOnClickListener(v -> {
            boolean show = logView.getVisibility() != View.VISIBLE;
            logView.setVisibility(show ? View.VISIBLE : View.GONE);
            diagnosticsButton.setText(show ? "Hide Diagnostics" : "Show Diagnostics");
        });
        card.addView(diagnosticsButton, match());

        logView = label("", 11, false, MUTED);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(10), dp(10), dp(10), dp(10));
        logView.setBackground(rounded(FIELD, dp(12), BORDER));
        logView.setVisibility(View.GONE);
        card.addView(logView, matchWithTop(8));
        return card;
    }

    private void refreshPresetDropdown(String selectProfileName) {
        presetEntries.clear();
        List<SavedProfile> saved = loadProfiles();
        for (SavedProfile p : saved) {
            presetEntries.add(PresetEntry.saved(p));
        }
        for (BuiltInPreset p : BUILT_INS) {
            presetEntries.add(PresetEntry.builtIn(p));
        }

        List<String> labels = new ArrayList<>();
        int wanted = 0;
        for (int i = 0; i < presetEntries.size(); i++) {
            PresetEntry e = presetEntries.get(i);
            labels.add(e.saved ? "★  " + e.savedProfile.name : e.builtInPreset.name);
            if (selectProfileName != null && e.saved && e.savedProfile.name.equalsIgnoreCase(selectProfileName)) {
                wanted = i;
            }
        }
        presetSpinner.setAdapter(spinnerAdapter(labels));
        if (!labels.isEmpty()) presetSpinner.setSelection(Math.min(wanted, labels.size() - 1));
    }

    private void applyPresetSelection(int position) {
        if (position < 0 || position >= presetEntries.size()) return;
        PresetEntry e = presetEntries.get(position);
        if (e.saved) {
            SavedProfile p = e.savedProfile;
            profileName.setText(p.name);
            phoneWidth.setText(String.valueOf(p.phoneWidth));
            phoneHeight.setText(String.valueOf(p.phoneHeight));
            navigationSafe.setChecked(p.navigationSafe);
            phoneDensity.setText(p.phoneDensity > 0 ? String.valueOf(p.phoneDensity) : "");
            externalWidth.setText(String.valueOf(p.externalWidth));
            externalHeight.setText(String.valueOf(p.externalHeight));
            externalHz.setText(trimFloat(p.externalHz));
            externalDensity.setText(p.externalDensity > 0 ? String.valueOf(p.externalDensity) : "");
            presetHint.setText("Saved profile • game + monitor values loaded");
            presetHint.setTextColor(ACCENT);
        } else {
            BuiltInPreset p = e.builtInPreset;
            profileName.setText("");
            phoneWidth.setText(String.valueOf(p.width));
            phoneHeight.setText(String.valueOf(p.height));
            navigationSafe.setChecked(true);
            phoneDensity.setText(String.valueOf(p.dpi));
            presetHint.setText(p.note + "  •  " + p.width + "×" + p.height + "  •  Navigation Safe ON");
            presetHint.setTextColor(MUTED);
        }
        updateCrystalPreview();
    }

    private void saveProfile() {
        String name = profileName.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter a profile name first.", Toast.LENGTH_LONG).show();
            return;
        }

        Integer pw = parseInt(phoneWidth.getText().toString());
        Integer ph = parseInt(phoneHeight.getText().toString());
        Integer pd = parseOptionalInt(phoneDensity.getText().toString());
        Integer ew = parseInt(externalWidth.getText().toString());
        Integer eh = parseInt(externalHeight.getText().toString());
        Float hz = parseFloat(externalHz.getText().toString());
        Integer ed = parseOptionalInt(externalDensity.getText().toString());

        if (pw == null || ph == null || ew == null || eh == null || hz == null) {
            Toast.makeText(this, "Complete the resolution and Hz fields before saving.", Toast.LENGTH_LONG).show();
            return;
        }

        SavedProfile profile = new SavedProfile(name, pw, ph, pd == null ? 0 : pd,
                ew, eh, hz, ed == null ? 0 : ed, navigationSafe.isChecked());

        List<SavedProfile> profiles = loadProfiles();
        int existing = -1;
        for (int i = 0; i < profiles.size(); i++) {
            if (profiles.get(i).name.equalsIgnoreCase(name)) {
                existing = i;
                break;
            }
        }
        if (existing >= 0) profiles.set(existing, profile);
        else profiles.add(0, profile);

        saveProfiles(profiles);
        refreshPresetDropdown(name);
        Toast.makeText(this, existing >= 0 ? "Profile updated" : "Profile saved", Toast.LENGTH_SHORT).show();
    }

    private void deleteSelectedProfile() {
        int pos = presetSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= presetEntries.size()) return;
        PresetEntry e = presetEntries.get(pos);
        if (!e.saved) {
            Toast.makeText(this, "Built-in presets cannot be deleted.", Toast.LENGTH_LONG).show();
            return;
        }

        String name = e.savedProfile.name;
        List<SavedProfile> profiles = loadProfiles();
        profiles.removeIf(p -> p.name.equalsIgnoreCase(name));
        saveProfiles(profiles);
        profileName.setText("");
        refreshPresetDropdown(null);
        Toast.makeText(this, "Deleted: " + name, Toast.LENGTH_SHORT).show();
    }

    private List<SavedProfile> loadProfiles() {
        List<SavedProfile> out = new ArrayList<>();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PROFILES, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new SavedProfile(
                        o.optString("name", "Profile"),
                        o.optInt("phoneWidth", 1536),
                        o.optInt("phoneHeight", 2048),
                        o.optInt("phoneDensity", 420),
                        o.optInt("externalWidth", 1920),
                        o.optInt("externalHeight", 1080),
                        (float) o.optDouble("externalHz", 120.0),
                        o.optInt("externalDensity", 0),
                        o.optBoolean("navigationSafe", true)
                ));
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private void saveProfiles(List<SavedProfile> profiles) {
        JSONArray arr = new JSONArray();
        try {
            for (SavedProfile p : profiles) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("phoneWidth", p.phoneWidth);
                o.put("phoneHeight", p.phoneHeight);
                o.put("phoneDensity", p.phoneDensity);
                o.put("externalWidth", p.externalWidth);
                o.put("externalHeight", p.externalHeight);
                o.put("externalHz", p.externalHz);
                o.put("externalDensity", p.externalDensity);
                o.put("navigationSafe", p.navigationSafe);
                arr.put(o);
            }
        } catch (Throwable ignored) { }
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(KEY_PROFILES, arr.toString())
                .apply();
    }

    private void ensureShizuku() {
        ShizukuBridge.ensureConnected(false);
        RootBridge.probeAsync((rootState, rootMessage) -> runOnUiThread(() -> {
            refreshPrivilegeStatus();
            if (rootState == RootBridge.State.READY) flushPendingShellActions();
        }));
    }

    private void connectPrivileges() {
        RootBridge.probeAsync((rootState, rootMessage) -> runOnUiThread(() -> {
            refreshPrivilegeStatus();
            if (rootState == RootBridge.State.READY) {
                flushPendingShellActions();
                Toast.makeText(this, "Root backend ready.", Toast.LENGTH_SHORT).show();
            }
        }));
        if (!PrivilegedBridge.isRootCapable()) {
            boolean opened = ShizukuBridge.connectOrOpenManager(this);
            if (!ShizukuBridge.isShizukuRunning() && opened) {
                Toast.makeText(this, "Root requested. Shizuku opened as fallback.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void refreshPrivilegeStatus() {
        if (PrivilegedBridge.isRootCapable()) {
            setStatus(PrivilegedBridge.rootBackendLabel() + " ready • privileged", ACCENT);
        } else if (RootBridge.getState() == RootBridge.State.CHECKING) {
            setStatus("Requesting root…", MUTED);
        } else if (ShizukuBridge.isReady()) {
            setStatus("SHIZUKU ready • root unavailable", ACCENT);
        } else {
            setStatus("No privileged backend ready", Color.parseColor("#E0B27A"));
        }
    }

    @Override
    public void onShizukuState(ShizukuBridge.State state, String message) {
        runOnUiThread(() -> {
            if (PrivilegedBridge.isRootCapable()) {
                refreshPrivilegeStatus();
                flushPendingShellActions();
                return;
            }
            int color;
            switch (state) {
                case READY:
                    color = ACCENT;
                    break;
                case CONNECTING:
                    color = MUTED;
                    break;
                case PERMISSION_REQUIRED:
                case SHIZUKU_OFF:
                    color = Color.parseColor("#E0B27A");
                    break;
                default:
                    color = DANGER;
                    break;
            }
            setStatus(message, color);
            if (state == ShizukuBridge.State.READY) {
                PrivilegedBridge.refreshShizukuRootAsync();
                main.postDelayed(this::refreshPrivilegeStatus, 450L);
                appendLog("Shizuku persistent shell ready.");
                flushPendingShellActions();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ShizukuBridge.ensureConnected(false);
        refreshPrivilegeStatus();
        main.removeCallbacks(fpsDiagnosticsUpdater);
        main.post(fpsDiagnosticsUpdater);
    }

    @Override
    protected void onPause() {
        main.removeCallbacks(fpsDiagnosticsUpdater);
        super.onPause();
    }

    private void refreshFpsDiagnosticsText() {
        if (fpsDiagnosticsText == null) return;
        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        String diag = sp.getString(GamingPrefs.FPS_DIAG_STATUS, "waiting for HUD");
        String method = sp.getString(GamingPrefs.FPS_DIAG_METHOD, "");
        int last = sp.getInt(GamingPrefs.FPS_LAST_VALUE, -1);
        StringBuilder text = new StringBuilder("FPS diagnostics: ").append(diag);
        if (!method.isEmpty()) text.append(" • ").append(method);
        if (last > 0) text.append(" • ").append(last).append(" FPS");
        fpsDiagnosticsText.setText(text.toString());
        fpsDiagnosticsText.setTextColor(last > 0 ? ACCENT : MUTED);
    }

    private boolean ensureShellOrQueue(String label, Runnable retryAction) {
        if (PrivilegedBridge.isReady()) return true;

        if (!ShizukuBridge.isShizukuRunning()) {
            enqueueShellAction(label, retryAction);
            setStatus("Shizuku off • " + label + " queued", Color.parseColor("#E0B27A"));
            Toast.makeText(this, label + " queued. Tap Connect and start Shizuku.", Toast.LENGTH_LONG).show();
            return false;
        }

        enqueueShellAction(label, retryAction);
        setStatus("Reconnecting… • " + label + " queued", MUTED);
        ShizukuBridge.ensureConnected(false);
        return false;
    }

    private void enqueueShellAction(String label, Runnable action) {
        if (pendingShellActions.size() >= 12) pendingShellActions.removeFirst();
        pendingShellActions.addLast(new PendingShellAction(label, action));
        appendLog("Queued while Shizuku reconnects: " + label);
    }

    private void flushPendingShellActions() {
        if (!PrivilegedBridge.isReady()) return;
        while (!pendingShellActions.isEmpty()) {
            PendingShellAction pending = pendingShellActions.removeFirst();
            appendLog("Running queued action: " + pending.label);
            main.post(pending.action);
        }
    }

    private void refreshDisplays() {
        displayList.clear();
        Display[] all = displayManager.getDisplays();
        Arrays.sort(all, (a, b) -> Integer.compare(
                a.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0,
                b.getDisplayId() == Display.DEFAULT_DISPLAY ? 1 : 0));
        displayList.addAll(Arrays.asList(all));

        List<String> labels = new ArrayList<>();
        for (Display d : displayList) {
            Display.Mode m = d.getMode();
            labels.add(String.format(Locale.US, "%s  •  %d×%d @ %.0f Hz%s",
                    d.getName(), m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    d.getDisplayId() == 0 ? "  (phone)" : ""));
        }
        if (labels.isEmpty()) labels.add("No displays found");
        displaySpinner.setAdapter(spinnerAdapter(labels));
        if (!displayList.isEmpty()) displaySpinner.setSelection(0);
        refreshModes();
    }

    private void refreshModes() {
        modeList.clear();
        Display d = selectedDisplay();
        if (d == null) {
            modeSpinner.setAdapter(spinnerAdapter(Collections.singletonList("No modes")));
            displayInfo.setText("No display selected");
            return;
        }

        Display.Mode active = d.getMode();
        List<Display.Mode> modes = new ArrayList<>(Arrays.asList(d.getSupportedModes()));
        modes.sort(Comparator
                .comparingLong((Display.Mode m) -> (long) m.getPhysicalWidth() * m.getPhysicalHeight()).reversed()
                .thenComparing(Comparator.comparingDouble(Display.Mode::getRefreshRate).reversed()));
        modeList.addAll(modes);

        List<String> labels = new ArrayList<>();
        int activeIndex = 0;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            boolean isActive = m.getModeId() == active.getModeId();
            if (isActive) activeIndex = i;
            labels.add(String.format(Locale.US, "%d×%d @ %.2f Hz%s",
                    m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(),
                    isActive ? "  • active" : ""));
        }
        modeSpinner.setAdapter(spinnerAdapter(labels));
        if (!modeList.isEmpty()) modeSpinner.setSelection(activeIndex);

        displayInfo.setText(String.format(Locale.US, "Display %d  •  %d supported mode(s)",
                d.getDisplayId(), modeList.size()));
    }

    private void fillExternalFromSelectedMode() {
        Display.Mode m = selectedMode();
        if (m == null) return;
        externalWidth.setText(String.valueOf(m.getPhysicalWidth()));
        externalHeight.setText(String.valueOf(m.getPhysicalHeight()));
        externalHz.setText(trimFloat(m.getRefreshRate()));
    }

    private void selectBestQuality() {
        if (modeList.isEmpty()) return;
        int best = 0;
        long bestPixels = -1;
        float bestHz = -1f;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            long pixels = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (pixels > bestPixels || (pixels == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = pixels;
                bestHz = m.getRefreshRate();
            }
        }
        modeSpinner.setSelection(best);
        fillExternalFromSelectedMode();
    }

    private void selectBest120() {
        int best = -1;
        long bestPixels = -1;
        float bestHz = -1f;
        for (int i = 0; i < modeList.size(); i++) {
            Display.Mode m = modeList.get(i);
            if (m.getRefreshRate() < 119f) continue;
            long pixels = (long) m.getPhysicalWidth() * m.getPhysicalHeight();
            if (pixels > bestPixels || (pixels == bestPixels && m.getRefreshRate() > bestHz)) {
                best = i;
                bestPixels = pixels;
                bestHz = m.getRefreshRate();
            }
        }
        if (best < 0) {
            Toast.makeText(this, "No ≥120 Hz mode reported by this display.", Toast.LENGTH_LONG).show();
            return;
        }
        modeSpinner.setSelection(best);
        fillExternalFromSelectedMode();
    }

    private void updateCrystalPreview() {
        if (crystalPreview == null || crystalPresetSpinner == null) return;
        Integer w = phoneWidth == null ? null : parseInt(phoneWidth.getText().toString());
        Integer h = phoneHeight == null ? null : parseInt(phoneHeight.getText().toString());
        int p = crystalPresetSpinner.getSelectedItemPosition();
        if (w == null || h == null || p < 0 || p >= CRYSTAL_PRESETS.length) {
            crystalPreview.setText("Set a valid Game View resolution first.");
            return;
        }
        CrystalPreset preset = CRYSTAL_PRESETS[p];
        int rw = Math.round(w * preset.factor);
        int rh = Math.round(h * preset.factor);
        crystalPreview.setText(String.format(Locale.US, "Requested app space: %d×%d  →  about %d×%d (%.2f× each axis)",
                w, h, rw, rh, preset.factor));
    }

    private void detectRunningPubg() {
        if (!PrivilegedBridge.isReady()) {
            Toast.makeText(this, "Root or Shizuku is required for detection.", Toast.LENGTH_SHORT).show();
            return;
        }
        worker.execute(() -> {
            String found = null;
            try {
                for (String pkg : PUBG_PACKAGES) {
                    String out = execPriv("pidof " + shellQuote(pkg));
                    String cleaned = stripExit(out);
                    if (cleaned.matches("(?s).*\\d+.*")) { found = pkg; break; }
                }
            } catch (Throwable ignored) { }
            String result = found;
            runOnUiThread(() -> {
                if (result != null) {
                    crystalPackage.setText(result);
                    crystalStatus.setText("Detected: " + result);
                    crystalStatus.setTextColor(ACCENT);
                } else {
                    crystalStatus.setText("No running PUBG package detected. Enter the package manually or start the game once.");
                    crystalStatus.setTextColor(MUTED);
                }
            });
        });
    }

    private void applyCrystalMode() {
        String pkg = crystalPackage.getText().toString().trim();
        if (!pkg.matches("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+")) {
            Toast.makeText(this, "Enter a valid Android package name.", Toast.LENGTH_LONG).show();
            return;
        }
        int p = crystalPresetSpinner.getSelectedItemPosition();
        if (p < 0 || p >= CRYSTAL_PRESETS.length) return;
        CrystalPreset preset = CRYSTAL_PRESETS[p];
        crystalStatus.setText("Requesting UID 0 and applying " + preset.name + "… the game may be force-stopped by Android.");
        crystalStatus.setTextColor(MUTED);

        worker.execute(() -> {
            StringBuilder log = new StringBuilder();
            boolean failed = false;
            try {
                String installed = PrivilegedBridge.execRoot("pm path " + shellQuote(pkg), 8000L);
                if (installed == null || !installed.contains("package:")) {
                    throw new IllegalArgumentException("Package not installed: " + pkg);
                }
                for (long factorId : CRYSTAL_FACTOR_IDS) {
                    String out = PrivilegedBridge.execRoot("am compat reset " + factorId + " " + shellQuote(pkg), 8000L);
                    log.append("reset ").append(factorId).append(": ").append(out).append('\n');
                }
                String gate = PrivilegedBridge.execRoot("am compat enable " + CRYSTAL_INVERSE_ID + " " + shellQuote(pkg), 8000L);
                String factor = PrivilegedBridge.execRoot("am compat enable " + preset.changeId + " " + shellQuote(pkg), 8000L);
                log.append("inverse: ").append(gate).append('\n');
                log.append("factor: ").append(factor).append('\n');
                String verify = PrivilegedBridge.execRoot("dumpsys platform_compat | grep -E '273564678|" + preset.changeId + "'", 8000L);
                log.append("verify: ").append(verify).append('\n');
                String lower = (gate + factor).toLowerCase(Locale.US);
                failed = lower.contains("error") || lower.contains("not allowed") || lower.contains("security") || lower.contains("unknown") || lower.contains("failed");
                if (!verify.contains(pkg) || !verify.contains(String.valueOf(CRYSTAL_INVERSE_ID)) || !verify.contains(String.valueOf(preset.changeId))) failed = true;
            } catch (Throwable t) {
                failed = true;
                log.append("ERROR: ").append(t);
            }
            boolean finalFailed = failed;
            String finalLog = log.toString();
            runOnUiThread(() -> {
                appendLog("Crystal Root Engine\n" + finalLog);
                if (finalFailed) {
                    if (finalLog.contains("UID 0") || finalLog.contains("SecurityException")) {
                        crystalStatus.setText("UID 0 root was not available. Grant root directly or start Shizuku in root mode, then retry.");
                    } else {
                        crystalStatus.setText("Crystal override was not verified. This ROM may block per-app compat overrides; see Diagnostics.");
                    }
                    crystalStatus.setTextColor(Color.parseColor("#E0A0A0"));
                } else {
                    crystalStatus.setText("✓ Crystal override reported by Android for " + pkg + ". Reopen the game and compare FPS/clarity.");
                    crystalStatus.setTextColor(ACCENT);
                }
            });
        });
    }

    private void resetCrystalMode() {
        String pkg = crystalPackage.getText().toString().trim();
        if (pkg.isEmpty()) return;
        worker.execute(() -> {
            StringBuilder out = new StringBuilder();
            try {
                out.append(PrivilegedBridge.execRoot("am compat reset " + CRYSTAL_INVERSE_ID + " " + shellQuote(pkg), 8000L)).append('\n');
                for (long factorId : CRYSTAL_FACTOR_IDS) {
                    out.append(PrivilegedBridge.execRoot("am compat reset " + factorId + " " + shellQuote(pkg), 8000L)).append('\n');
                }
            } catch (Throwable t) { out.append("ERROR: ").append(t); }
            String finalOut = out.toString();
            runOnUiThread(() -> {
                appendLog("Reset Crystal\n" + finalOut);
                crystalStatus.setText("Crystal overrides reset for " + pkg + ". Reopen the game.");
                crystalStatus.setTextColor(MUTED);
            });
        });
    }

    private void applySelectedExternalMode() {
        Display d = selectedDisplay();
        Display.Mode m = selectedMode();
        if (d == null || m == null) return;
        if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_LONG).show();
            return;
        }
        applyPhysicalExternalMode(d.getDisplayId(), m.getPhysicalWidth(), m.getPhysicalHeight(),
                m.getRefreshRate());
    }

    private void applyPhysicalExternalMode(int displayId, int w, int h, float hz) {
        if (!ensureShellOrQueue("Apply physical monitor mode", () -> applyPhysicalExternalMode(displayId, w, h, hz))) return;
        worker.execute(() -> {
            try {
                RevertState state = captureRevertState(displayId);
                String command = String.format(Locale.US,
                        "cmd display set-user-preferred-display-mode %d %d %.3f %d",
                        w, h, hz, displayId);
                String result = execPriv(command);
                String preferred = execPriv("cmd display get-user-preferred-display-mode " + displayId);

                pendingRevert = state;
                runOnUiThread(() -> {
                    appendLog("Physical monitor request: " + w + "×" + h + " @ " + hz + " Hz\n$ "
                            + command + "\n" + result + "\n" + preferred);
                    monitorStatus.setText("Physical request: " + w + "×" + h + " @ "
                            + trimFloat(hz) + " Hz • forced logical size unchanged");
                    monitorStatus.setTextColor(ACCENT);
                    startSafetyCountdown();
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    appendLog("Physical monitor apply failed: " + t);
                    monitorStatus.setText("Physical mode request failed");
                    monitorStatus.setTextColor(DANGER);
                });
            }
        });
    }

    private void applyCustomExternalMode() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_LONG).show();
            return;
        }
        Integer w = parseInt(externalWidth.getText().toString());
        Integer h = parseInt(externalHeight.getText().toString());
        Integer density = parseOptionalInt(externalDensity.getText().toString());
        if (w == null || h == null || w < 480 || h < 480) {
            Toast.makeText(this, "Enter a valid logical output width and height.", Toast.LENGTH_LONG).show();
            return;
        }
        forceLogicalOutput(d.getDisplayId(), w, h, density);
    }

    private void forceLogicalOutput(int displayId, int w, int h, Integer density) {
        if (!ensureShellOrQueue("Force logical monitor output", () -> forceLogicalOutput(displayId, w, h, density))) return;
        worker.execute(() -> {
            try {
                RevertState state = captureRevertState(displayId);
                StringBuilder out = new StringBuilder();

                String sizeCommand = "wm size " + w + "x" + h + " -d " + displayId;
                out.append("$ ").append(sizeCommand).append('\n')
                        .append(execPriv(sizeCommand)).append('\n');

                if (density != null && density >= 72 && density <= 1000) {
                    String densityCommand = "wm density " + density + " -d " + displayId;
                    out.append("$ ").append(densityCommand).append('\n')
                            .append(execPriv(densityCommand)).append('\n');
                }

                String scalingCommand = "wm scaling auto -d " + displayId;
                out.append("$ ").append(scalingCommand).append('\n')
                        .append(execPriv(scalingCommand)).append('\n');

                String sizeStatus = execPriv("wm size -d " + displayId);
                String densityStatus = execPriv("wm density -d " + displayId);
                out.append("\nVERIFY SIZE:\n").append(sizeStatus)
                        .append("\nVERIFY DENSITY:\n").append(densityStatus);

                pendingRevert = state;
                runOnUiThread(() -> {
                    appendLog("Forced logical output: " + w + "×" + h + "\n" + out);
                    monitorStatus.setText("Forced logical output: " + w + "×" + h
                            + (density != null ? " • DPI " + density : "")
                            + " • physical Hz unchanged");
                    monitorStatus.setTextColor(ACCENT);
                    startSafetyCountdown();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    appendLog("Force logical output failed: " + t);
                    monitorStatus.setText("Forced output failed");
                    monitorStatus.setTextColor(DANGER);
                });
            }
        });
    }

    private void resetForcedLogicalOutput() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_LONG).show();
            return;
        }
        int id = d.getDisplayId();
        runCommands("Reset forced logical output", Arrays.asList(
                "wm size reset -d " + id,
                "wm density reset -d " + id,
                "wm scaling auto -d " + id));
        monitorStatus.setText("Forced logical output reset • physical mode unchanged");
        monitorStatus.setTextColor(MUTED);
    }

    private void applyPhoneCustom() {
        Integer w = parseInt(phoneWidth.getText().toString());
        Integer h = parseInt(phoneHeight.getText().toString());
        if (w == null || h == null || w < 480 || h < 480) {
            Toast.makeText(this, "Enter a valid game-view width and height.", Toast.LENGTH_LONG).show();
            return;
        }

        if (navigationSafe != null && navigationSafe.isChecked()) {
            applyPhoneNavigationSafe(w, h);
            return;
        }

        List<String> cmds = new ArrayList<>();
        cmds.add("wm size " + w + "x" + h + " -d 0");
        Integer dpi = parseOptionalInt(phoneDensity.getText().toString());
        if (dpi != null && dpi >= 72 && dpi <= 1000) {
            cmds.add("wm density " + dpi + " -d 0");
        }
        cmds.add("wm scaling auto -d 0");
        runCommands("Apply game view • manual DPI", cmds);
    }

    private void applyPhoneNavigationSafe(int w, int h) {
        if (!ensureShellOrQueue("Apply Navigation Safe game view", () -> applyPhoneNavigationSafe(w, h))) return;
        worker.execute(() -> {
            try {
                RevertState state = capturePhoneRevertState();
                String beforeSize = state.externalSize;
                String beforeDensity = state.externalDensity;

                int[] physical = parsePhysicalSize(beforeSize);
                Integer physicalDpi = parsePhysicalDensity(beforeDensity);
                if (physical == null || physicalDpi == null || physicalDpi <= 0) {
                    throw new IllegalStateException("Could not read physical phone size/density");
                }

                int physicalShort = Math.min(physical[0], physical[1]);
                int targetShort = Math.min(w, h);
                double scale = (double) targetShort / (double) physicalShort;
                int safeDpi = (int) Math.round(physicalDpi * scale);
                safeDpi = Math.max(72, Math.min(1000, safeDpi));

                StringBuilder out = new StringBuilder();
                String sizeCommand = "wm size " + w + "x" + h + " -d 0";
                String densityCommand = "wm density " + safeDpi + " -d 0";
                String scalingCommand = "wm scaling auto -d 0";

                out.append("PHYSICAL BASELINE:\n").append(beforeSize).append('\n')
                        .append(beforeDensity).append("\n\n")
                        .append("$ ").append(sizeCommand).append('\n').append(execPriv(sizeCommand)).append('\n')
                        .append("$ ").append(densityCommand).append('\n').append(execPriv(densityCommand)).append('\n')
                        .append("$ ").append(scalingCommand).append('\n').append(execPriv(scalingCommand)).append('\n')
                        .append("\nVERIFY SIZE:\n").append(execPriv("wm size -d 0"))
                        .append("\nVERIFY DENSITY:\n").append(execPriv("wm density -d 0"));

                pendingRevert = state;
                final int calculatedDpi = safeDpi;
                runOnUiThread(() -> {
                    phoneDensity.setText(String.valueOf(calculatedDpi));
                    navigationSafeInfo.setText("Applied safe DPI " + calculatedDpi
                            + " from physical " + physical[0] + "×" + physical[1]
                            + " @ " + physicalDpi + " DPI • short-edge scale "
                            + String.format(Locale.US, "%.3f×", scale));
                    navigationSafeInfo.setTextColor(ACCENT);
                    appendLog("Navigation Safe game view: " + w + "×" + h
                            + " • auto DPI " + calculatedDpi + "\n" + out);
                    startSafetyCountdown();
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    navigationSafeInfo.setText("Navigation Safe failed — reset phone view or use manual DPI.");
                    navigationSafeInfo.setTextColor(DANGER);
                    appendLog("Navigation Safe apply failed: " + t);
                    Toast.makeText(this, "Could not calculate Navigation Safe DPI.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void updateNavigationSafeUi() {
        if (phoneDensity == null || navigationSafe == null) return;
        boolean safe = navigationSafe.isChecked();
        phoneDensity.setEnabled(!safe);
        phoneDensity.setAlpha(safe ? 0.55f : 1f);
        if (navigationSafeInfo != null) {
            navigationSafeInfo.setText(safe
                    ? "Auto DPI will be calculated from the phone's physical display when you apply."
                    : "Manual DPI mode • use carefully; wrong DPI can break gesture navigation.");
            navigationSafeInfo.setTextColor(safe ? MUTED : Color.parseColor("#E0A0A0"));
        }
    }

    private int[] parsePhysicalSize(String output) {
        Matcher m = Pattern.compile("Physical size:\\s*(\\d+)x(\\d+)")
                .matcher(output == null ? "" : output);
        if (!m.find()) return null;
        try {
            return new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))};
        } catch (Throwable t) {
            return null;
        }
    }

    private Integer parsePhysicalDensity(String output) {
        Matcher m = Pattern.compile("Physical density:\\s*(\\d+)")
                .matcher(output == null ? "" : output);
        if (!m.find()) return null;
        try {
            return Integer.parseInt(m.group(1));
        } catch (Throwable t) {
            return null;
        }
    }

    private RevertState captureRevertState(int displayId) throws RemoteException {
        RevertState s = new RevertState();
        s.displayId = displayId;
        s.restorePreferredMode = true;
        s.preferredMode = execPriv("cmd display get-user-preferred-display-mode " + displayId);
        s.externalSize = execPriv("wm size -d " + displayId);
        s.externalDensity = execPriv("wm density -d " + displayId);
        return s;
    }

    private RevertState capturePhoneRevertState() throws RemoteException {
        RevertState s = new RevertState();
        s.displayId = Display.DEFAULT_DISPLAY;
        s.restorePreferredMode = false;
        s.externalSize = execPriv("wm size -d 0");
        s.externalDensity = execPriv("wm density -d 0");
        return s;
    }

    private void startSafetyCountdown() {
        cancelSafetyCountdown(false);
        keepButton.setEnabled(true);
        keepButton.setAlpha(1f);
        safetyDeadline = System.currentTimeMillis() + SAFETY_MS;
        autoRevertRunnable = () -> {
            RevertState state = pendingRevert;
            pendingRevert = null;
            if (state != null) restoreState(state, "Safety rollback");
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.5f);
            safetyText.setText("Safety rollback: reverted");
            safetyText.setTextColor(Color.parseColor("#E0A0A0"));
        };
        main.postDelayed(autoRevertRunnable, SAFETY_MS);
        tickSafety();
    }

    private void tickSafety() {
        if (autoRevertRunnable == null) return;
        long remain = Math.max(0, safetyDeadline - System.currentTimeMillis());
        safetyText.setText("Output rollback in " + ((remain + 999) / 1000) + " s");
        safetyText.setTextColor(ACCENT);
        if (remain > 0) main.postDelayed(this::tickSafety, 500);
    }

    private void cancelSafetyCountdown(boolean keep) {
        if (autoRevertRunnable != null) main.removeCallbacks(autoRevertRunnable);
        autoRevertRunnable = null;
        if (keep) {
            pendingRevert = null;
            safetyText.setText("Safety rollback: mode kept");
            safetyText.setTextColor(ACCENT);
            appendLog("Output change confirmed.");
        } else if (pendingRevert == null) {
            safetyText.setText("Safety rollback: inactive");
            safetyText.setTextColor(MUTED);
        }
        if (keepButton != null) {
            keepButton.setEnabled(false);
            keepButton.setAlpha(0.5f);
        }
    }

    private void restoreState(RevertState state, String reason) {
        if (!ensureShellOrQueue(reason, () -> restoreState(state, reason))) return;
        worker.execute(() -> {
            try {
                List<String> cmds = new ArrayList<>();
                if (state.restorePreferredMode) {
                    cmds.add(preferredModeRestoreCommand(state.displayId, state.preferredMode));
                }
                cmds.add(sizeRestoreCommand(state.displayId, state.externalSize));
                cmds.add(densityRestoreCommand(state.displayId, state.externalDensity));
                cmds.add("wm scaling auto -d " + state.displayId);
                StringBuilder out = new StringBuilder();
                for (String c : cmds) {
                    out.append("$ ").append(c).append('\n').append(execPriv(c)).append('\n');
                }
                runOnUiThread(() -> {
                    appendLog(reason + "\n" + out);
                    refreshDisplays();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> appendLog("Rollback failed: " + t));
            }
        });
    }

    private String preferredModeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("User preferred display mode:\\s*(\\d+)\\s+(\\d+)\\s+([0-9.]+)")
                .matcher(output == null ? "" : output);
        if (m.find()) {
            return "cmd display set-user-preferred-display-mode " + m.group(1) + " " + m.group(2)
                    + " " + m.group(3) + " " + displayId;
        }
        return "cmd display clear-user-preferred-display-mode " + displayId;
    }

    private String sizeRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override size:\\s*(\\d+)x(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm size " + m.group(1) + "x" + m.group(2) + " -d " + displayId;
        return "wm size reset -d " + displayId;
    }

    private String densityRestoreCommand(int displayId, String output) {
        Matcher m = Pattern.compile("Override density:\\s*(\\d+)")
                .matcher(output == null ? "" : output);
        if (m.find()) return "wm density " + m.group(1) + " -d " + displayId;
        return "wm density reset -d " + displayId;
    }

    private void restoreSelectedExternal() {
        Display d = selectedDisplay();
        if (d == null || d.getDisplayId() == 0) {
            Toast.makeText(this, "Select the external monitor first.", Toast.LENGTH_SHORT).show();
            return;
        }
        cancelSafetyCountdown(false);
        int id = d.getDisplayId();
        runCommands("Restore monitor", Arrays.asList(
                "cmd display clear-user-preferred-display-mode " + id,
                "wm size reset -d " + id,
                "wm density reset -d " + id,
                "wm scaling auto -d " + id));
    }

    private void restoreAllDefaults() {
        Display d = selectedDisplay();
        int id = d == null ? -1 : d.getDisplayId();
        cancelSafetyCountdown(false);
        List<String> cmds = new ArrayList<>();
        if (id > 0) {
            cmds.add("cmd display clear-user-preferred-display-mode " + id);
            cmds.add("wm size reset -d " + id);
            cmds.add("wm density reset -d " + id);
            cmds.add("wm scaling auto -d " + id);
        }
        cmds.add("wm size reset -d 0");
        cmds.add("wm density reset -d 0");
        cmds.add("wm scaling auto -d 0");
        runCommands("Restore everything", cmds);
    }

    private void runCommands(String title, List<String> commands) {
        List<String> queuedCopy = new ArrayList<>(commands);
        if (!ensureShellOrQueue(title, () -> runCommands(title, queuedCopy))) return;
        worker.execute(() -> {
            StringBuilder out = new StringBuilder();
            try {
                for (String c : commands) {
                    out.append("$ ").append(c).append('\n');
                    out.append(execPriv(c)).append('\n');
                }
            } catch (Throwable t) {
                out.append("ERROR: ").append(t);
            }
            runOnUiThread(() -> {
                appendLog(title + "\n" + out);
                refreshDisplays();
            });
        });
    }

    private String execPriv(String command) throws RemoteException {
        // Background commands survive a brief UserService disconnect caused by
        // display-size/DPI changes. ShizukuBridge waits for the daemon binder
        // and retries the interrupted command once.
        return PrivilegedBridge.exec(command, 8_000L);
    }

    private Display selectedDisplay() {
        int p = displaySpinner.getSelectedItemPosition();
        return (p >= 0 && p < displayList.size()) ? displayList.get(p) : null;
    }

    private Display.Mode selectedMode() {
        int p = modeSpinner.getSelectedItemPosition();
        return (p >= 0 && p < modeList.size()) ? modeList.get(p) : null;
    }

    private void setStatus(String value, int color) {
        status.setText(value);
        status.setTextColor(color);
    }

    private void appendLog(String value) {
        if (logView == null) return;
        String old = logView.getText().toString();
        if (old.length() > 9000) old = old.substring(old.length() - 7000);
        logView.setText(old + (old.isEmpty() ? "" : "\n\n") + value.trim());
    }

    @Override public void onDisplayAdded(int displayId) { refreshDisplays(); }
    @Override public void onDisplayRemoved(int displayId) { refreshDisplays(); }
    @Override public void onDisplayChanged(int displayId) { refreshDisplays(); }

    private LinearLayout card() {
        LinearLayout v = vertical();
        v.setPadding(dp(14), dp(14), dp(14), dp(14));
        v.setBackground(rounded(CARD, dp(18), BORDER));
        return v;
    }

    private void sectionTitle(LinearLayout parent, String value) {
        TextView t = label(value, 18, true, TEXT);
        parent.addView(t, match());
    }

    private void miniTitle(LinearLayout parent, String value) {
        TextView t = label(value, 12, true, ACCENT);
        t.setPadding(dp(2), dp(14), dp(2), dp(6));
        parent.addView(t, match());
    }

    private void mutedText(LinearLayout parent, String value) {
        TextView t = label(value, 12, false, MUTED);
        t.setPadding(0, dp(4), 0, 0);
        parent.addView(t, match());
    }

    private void divider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        p.setMargins(0, dp(16), 0, 0);
        parent.addView(line, p);
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTextColor(primary ? Color.parseColor("#141311") : TEXT);
        b.setBackground(rounded(primary ? ACCENT : FIELD_2, dp(14), primary ? ACCENT : BORDER));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        return b;
    }

    private Spinner spinner() {
        Spinner s = new Spinner(this);
        s.setPadding(dp(10), dp(4), dp(10), dp(4));
        s.setBackground(rounded(FIELD, dp(14), BORDER));
        return s;
    }

    private EditText numberField(String hint, String value) {
        EditText e = textField(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private EditText decimalField(String hint, String value) {
        EditText e = textField(hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private EditText textField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.parseColor("#77736E"));
        e.setText(value);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setBackground(rounded(FIELD, dp(14), BORDER));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    private ArrayAdapter<String> spinnerAdapter(List<String> items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(TEXT);
                    t.setTextSize(13f);
                    t.setPadding(dp(4), dp(7), dp(4), dp(7));
                    t.setBackgroundColor(Color.TRANSPARENT);
                }
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(TEXT);
                    t.setTextSize(13f);
                    t.setPadding(dp(14), dp(12), dp(14), dp(12));
                    t.setBackgroundColor(FIELD);
                }
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private GradientDrawable rounded(int fill, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWithTop(int topDp) {
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, dp(topDp), 0, 0);
        return p;
    }

    private LinearLayout.LayoutParams matchWithBottom(int bottomDp) {
        LinearLayout.LayoutParams p = match();
        p.setMargins(0, 0, 0, dp(bottomDp));
        return p;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String stripExit(String value) {
        if (value == null) return "";
        return value.replaceAll("(?m)^\\[(?:root )?exit=\\d+\\]$", "").trim();
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private Integer parseInt(String value) {
        try { return Integer.parseInt(value.trim()); }
        catch (Throwable t) { return null; }
    }

    private Integer parseOptionalInt(String value) {
        String s = value == null ? "" : value.trim();
        if (s.isEmpty()) return null;
        return parseInt(s);
    }

    private Float parseFloat(String value) {
        try { return Float.parseFloat(value.trim()); }
        catch (Throwable t) { return null; }
    }

    private String trimFloat(float value) {
        if (Math.abs(value - Math.round(value)) < 0.01f) {
            return String.valueOf(Math.round(value));
        }
        return String.format(Locale.US, "%.2f", value);
    }

    private static class PendingShellAction {
        final String label;
        final Runnable action;

        PendingShellAction(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
    }

    private static class CrystalPreset {
        final String name;
        final float factor;
        final long changeId;
        final String changeName;

        CrystalPreset(String name, float factor, long changeId, String changeName) {
            this.name = name;
            this.factor = factor;
            this.changeId = changeId;
            this.changeName = changeName;
        }
    }

    private static class BuiltInPreset {
        final String name;
        final int width;
        final int height;
        final int dpi;
        final String note;

        BuiltInPreset(String name, int width, int height, int dpi, String note) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.dpi = dpi;
            this.note = note;
        }
    }

    private static class SavedProfile {
        final String name;
        final int phoneWidth;
        final int phoneHeight;
        final int phoneDensity;
        final int externalWidth;
        final int externalHeight;
        final float externalHz;
        final int externalDensity;
        final boolean navigationSafe;

        SavedProfile(String name, int phoneWidth, int phoneHeight, int phoneDensity,
                     int externalWidth, int externalHeight, float externalHz, int externalDensity,
                     boolean navigationSafe) {
            this.name = name;
            this.phoneWidth = phoneWidth;
            this.phoneHeight = phoneHeight;
            this.phoneDensity = phoneDensity;
            this.externalWidth = externalWidth;
            this.externalHeight = externalHeight;
            this.externalHz = externalHz;
            this.externalDensity = externalDensity;
            this.navigationSafe = navigationSafe;
        }
    }

    private static class PresetEntry {
        final boolean saved;
        final SavedProfile savedProfile;
        final BuiltInPreset builtInPreset;

        private PresetEntry(boolean saved, SavedProfile savedProfile, BuiltInPreset builtInPreset) {
            this.saved = saved;
            this.savedProfile = savedProfile;
            this.builtInPreset = builtInPreset;
        }

        static PresetEntry saved(SavedProfile profile) {
            return new PresetEntry(true, profile, null);
        }

        static PresetEntry builtIn(BuiltInPreset preset) {
            return new PresetEntry(false, null, preset);
        }
    }

    private static class RevertState {
        int displayId;
        boolean restorePreferredMode;
        String preferredMode;
        String externalSize;
        String externalDensity;
    }
}
