package com.besnik.pixelperfect;

public final class GamingPrefs {
    public static final String PREFS = "vpqclan_gaming_tools_v43";

    public static final String FPS_ENABLED = "fps_enabled";
    public static final String CPU_TEMP_ENABLED = "cpu_temp_enabled";
    public static final String BATTERY_TEMP_ENABLED = "battery_temp_enabled";

    public static final String FPS_X = "fps_x";
    public static final String FPS_Y = "fps_y";
    public static final String CPU_X = "cpu_x";
    public static final String CPU_Y = "cpu_y";
    public static final String BAT_X = "bat_x";
    public static final String BAT_Y = "bat_y";

    public static final String LOCK_OVERLAYS = "lock_overlays";

    // Live monitor values and diagnostics written by PerfOverlayService.
    public static final String FPS_DIAG_STATUS = "fps_diag_status";
    public static final String FPS_DIAG_METHOD = "fps_diag_method";
    public static final String FPS_DIAG_PACKAGE = "fps_diag_package";
    public static final String FPS_DIAG_LAYER = "fps_diag_layer";
    public static final String FPS_LAST_VALUE = "fps_last_value";
    public static final String FPS_APPROXIMATE = "fps_approximate";

    public static final String CPU_LAST_VALUE = "cpu_last_value";
    public static final String CPU_SENSOR_NAME = "cpu_sensor_name";
    public static final String BATTERY_LAST_VALUE = "battery_last_value";

    private GamingPrefs() { }
}
