package com.besnik.pixelperfect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VPQCLAN C.R V4.6 performance overlay.
 *
 * BAT = Android battery sensor only.
 * CPU = Android thermalservice TYPE_CPU or CPU/SoC sysfs thermal sensors.
 * FPS = SurfaceFlinger layer latency -> SurfaceFlinger TimeStats -> gfxinfo ->
 *       display-compositor fallback (explicitly marked approximate with '~').
 */
public class PerfOverlayService extends Service
        implements ShizukuBridge.Listener, DisplayManager.DisplayListener {

    public static final String ACTION_REFRESH = "com.besnik.pixelperfect.action.REFRESH_HUD";

    private static final String CHANNEL_ID = "vpqclan_performance_monitor";
    private static final int NOTIFICATION_ID = 4505;
    private static final long FPS_SAMPLE_INTERVAL_MS = 900L;
    private static final long CPU_SAMPLE_INTERVAL_MS = 1500L;
    private static final long BATTERY_SAMPLE_INTERVAL_MS = 1500L;
    private static final long LAYER_RESCAN_MS = 3500L;

    private static final String[] PUBG_PACKAGES = {
            "com.tencent.ig",
            "com.pubg.imobile",
            "com.vng.pubgmobile",
            "com.rekoo.pubgm",
            "com.pubg.krmobile",
            "com.pubg.newstate"
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService fpsWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService cpuWorker = Executors.newSingleThreadExecutor();

    private WindowManager windowManager;
    private DisplayManager displayManager;

    private TextView fpsView;
    private TextView cpuView;
    private TextView batteryView;
    private WindowManager.LayoutParams fpsParams;
    private WindowManager.LayoutParams cpuParams;
    private WindowManager.LayoutParams batteryParams;

    private long lastFpsSampleMs;
    private long lastCpuSampleMs;
    private long lastBatterySampleMs;
    private boolean fpsReadInFlight;
    private boolean cpuReadInFlight;

    private volatile String cachedPackage;
    private volatile String cachedLayer;
    private volatile long cachedLayerAtMs;
    private volatile String timeStatsPackage;
    private volatile long timeStatsPreparedAtMs;

    private final Runnable updater = new Runnable() {
        @Override
        public void run() {
            syncOverlayViews();
            updateBatteryOverlay();
            updateCpuOverlayIfDue();
            updateFpsOverlayIfDue();
            main.postDelayed(this, 400L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        if (displayManager != null) displayManager.registerDisplayListener(this, main);

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Performance monitor active"));

        ShizukuBridge.init(this);
        ShizukuBridge.addListener(this);
        ShizukuBridge.ensureConnected(false);

        syncOverlayViews();
        writeFpsDiagnostics("waiting for game", "", "", "", -1, false);
        main.post(updater);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ShizukuBridge.ensureConnected(false);
        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            invalidateFpsTarget("HUD refreshed");
        }
        syncOverlayViews();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(updater);
        ShizukuBridge.removeListener(this);
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(this); } catch (Throwable ignored) { }
        }
        fpsWorker.shutdownNow();
        cpuWorker.shutdownNow();
        removeOverlay(fpsView);
        removeOverlay(cpuView);
        removeOverlay(batteryView);
        fpsView = null;
        cpuView = null;
        batteryView = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onShizukuState(ShizukuBridge.State state, String message) {
        if (state == ShizukuBridge.State.READY) {
            invalidateFpsTarget("Shizuku reconnected");
            tryEnableTimeStatsAsync();
        } else if (state == ShizukuBridge.State.SHIZUKU_OFF) {
            writeFpsDiagnostics("Shizuku is off", "", cachedPackage, cachedLayer, -1, false);
            if (fpsView != null) fpsView.setText("FPS --");
            if (cpuView != null) cpuView.setText("CPU --.-°C");
        } else if (state == ShizukuBridge.State.CONNECTING) {
            writeFpsDiagnostics("Shizuku reconnecting", "", cachedPackage, cachedLayer, -1, false);
            if (fpsView != null) fpsView.setText("FPS …");
            if (cpuView != null) cpuView.setText("CPU …");
        }
    }

    @Override public void onDisplayAdded(int displayId) { invalidateFpsTarget("display added"); }
    @Override public void onDisplayRemoved(int displayId) { invalidateFpsTarget("display removed"); }
    @Override public void onDisplayChanged(int displayId) { invalidateFpsTarget("display changed"); }

    private void syncOverlayViews() {
        if (!Settings.canDrawOverlays(this)) {
            removeOverlay(fpsView);
            removeOverlay(cpuView);
            removeOverlay(batteryView);
            fpsView = null;
            cpuView = null;
            batteryView = null;
            return;
        }

        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        boolean fpsEnabled = sp.getBoolean(GamingPrefs.FPS_ENABLED, false);
        boolean cpuEnabled = sp.getBoolean(GamingPrefs.CPU_TEMP_ENABLED, false);
        boolean batteryEnabled = sp.getBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, false);
        boolean locked = sp.getBoolean(GamingPrefs.LOCK_OVERLAYS, false);

        if (fpsEnabled && fpsView == null) {
            fpsView = createHudText("FPS --");
            fpsParams = createParams(
                    sp.getInt(GamingPrefs.FPS_X, dp(10)),
                    sp.getInt(GamingPrefs.FPS_Y, dp(34)));
            installDrag(fpsView, fpsParams, GamingPrefs.FPS_X, GamingPrefs.FPS_Y);
            windowManager.addView(fpsView, fpsParams);
            invalidateFpsTarget("FPS overlay enabled");
        } else if (!fpsEnabled && fpsView != null) {
            removeOverlay(fpsView);
            fpsView = null;
            fpsParams = null;
        }

        if (cpuEnabled && cpuView == null) {
            cpuView = createHudText("CPU --.-°C");
            cpuParams = createParams(
                    sp.getInt(GamingPrefs.CPU_X, dp(10)),
                    sp.getInt(GamingPrefs.CPU_Y, dp(72)));
            installDrag(cpuView, cpuParams, GamingPrefs.CPU_X, GamingPrefs.CPU_Y);
            windowManager.addView(cpuView, cpuParams);
        } else if (!cpuEnabled && cpuView != null) {
            removeOverlay(cpuView);
            cpuView = null;
            cpuParams = null;
        }

        if (batteryEnabled && batteryView == null) {
            batteryView = createHudText("BAT --.-°C");
            batteryParams = createParams(
                    sp.getInt(GamingPrefs.BAT_X, dp(10)),
                    sp.getInt(GamingPrefs.BAT_Y, dp(110)));
            installDrag(batteryView, batteryParams, GamingPrefs.BAT_X, GamingPrefs.BAT_Y);
            windowManager.addView(batteryView, batteryParams);
        } else if (!batteryEnabled && batteryView != null) {
            removeOverlay(batteryView);
            batteryView = null;
            batteryParams = null;
        }

        updateTouchThrough(fpsView, fpsParams, locked);
        updateTouchThrough(cpuView, cpuParams, locked);
        updateTouchThrough(batteryView, batteryParams, locked);
    }

    private TextView createHudText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13f);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xA61A1A1A);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0x66FFFFFF);
        view.setBackground(bg);
        view.setElevation(dp(4));
        return view;
    }

    private WindowManager.LayoutParams createParams(int x, int y) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        return p;
    }

    private void installDrag(View view, WindowManager.LayoutParams params, String xKey, String yKey) {
        view.setOnTouchListener(new View.OnTouchListener() {
            int startX;
            int startY;
            float downX;
            float downY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean locked = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE)
                        .getBoolean(GamingPrefs.LOCK_OVERLAYS, false);
                if (locked) return false;

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + Math.round(event.getRawX() - downX);
                        params.y = startY + Math.round(event.getRawY() - downY);
                        try { windowManager.updateViewLayout(v, params); } catch (Throwable ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                                .putInt(xKey, params.x)
                                .putInt(yKey, params.y)
                                .apply();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void updateTouchThrough(View view, WindowManager.LayoutParams params, boolean locked) {
        if (view == null || params == null) return;
        int desired = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (locked) desired |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (params.flags != desired) {
            params.flags = desired;
            try { windowManager.updateViewLayout(view, params); } catch (Throwable ignored) { }
        }
    }

    private void updateBatteryOverlay() {
        if (batteryView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastBatterySampleMs < BATTERY_SAMPLE_INTERVAL_MS) return;
        lastBatterySampleMs = now;

        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) {
            batteryView.setText("BAT --.-°C");
            return;
        }
        int tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        if (tenths == Integer.MIN_VALUE) {
            batteryView.setText("BAT --.-°C");
            return;
        }
        float c = tenths / 10f;
        batteryView.setText(String.format(Locale.US, "BAT %.1f°C", c));
        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                .putFloat(GamingPrefs.BATTERY_LAST_VALUE, c)
                .apply();
    }

    private void updateCpuOverlayIfDue() {
        if (cpuView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastCpuSampleMs < CPU_SAMPLE_INTERVAL_MS || cpuReadInFlight) return;
        lastCpuSampleMs = now;

        if (!ShizukuBridge.isReady()) {
            ShizukuBridge.ensureConnected(false);
            cpuView.setText("CPU …");
            return;
        }

        cpuReadInFlight = true;
        cpuWorker.execute(() -> {
            CpuTempSample sample = readCpuTemperature();
            main.post(() -> {
                cpuReadInFlight = false;
                if (cpuView == null) return;
                if (sample.valid()) {
                    cpuView.setText(String.format(Locale.US, "CPU %.1f°C", sample.celsius));
                    getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                            .putFloat(GamingPrefs.CPU_LAST_VALUE, sample.celsius)
                            .putString(GamingPrefs.CPU_SENSOR_NAME, sample.sensor)
                            .apply();
                } else {
                    cpuView.setText("CPU --.-°C");
                }
            });
        });
    }

    private CpuTempSample readCpuTemperature() {
        try {
            IUserService service = ShizukuBridge.awaitService(3000);
            String thermal = service.exec("dumpsys thermalservice");
            CpuTempSample fromService = parseThermalServiceCpu(thermal);
            if (fromService.valid()) return fromService;

            String sysfs = service.exec(
                    "for z in /sys/class/thermal/thermal_zone*; do " +
                    "n=$(cat \"$z/type\" 2>/dev/null); v=$(cat \"$z/temp\" 2>/dev/null); " +
                    "echo \"$n|$v\"; done");
            CpuTempSample fromSysfs = parseSysfsCpu(sysfs);
            if (fromSysfs.valid()) return fromSysfs;
        } catch (Throwable ignored) { }
        return CpuTempSample.none();
    }

    private CpuTempSample parseThermalServiceCpu(String raw) {
        if (raw == null) return CpuTempSample.none();
        float best = Float.NaN;
        String bestName = "";

        for (String line : raw.split("\\n")) {
            String lower = line.toLowerCase(Locale.US);
            if (!lower.contains("temperature")) continue;
            boolean typeCpu = lower.contains("mtype=0") || lower.contains("type=0");
            boolean namedCpu = lower.matches(".*(cpu|soc|ap[-_ ]?therm|cpuss|cluster|prime).*" );
            boolean excluded = lower.matches(".*(battery|batt|gpu|skin|usb|charger|pa[-_ ]?therm).*" );
            if ((!typeCpu && !namedCpu) || excluded) continue;

            Float value = extractFloat(line, "mValue\\s*=\\s*([-+]?\\d+(?:\\.\\d+)?)");
            if (value == null) value = extractFloat(line, "value\\s*=\\s*([-+]?\\d+(?:\\.\\d+)?)");
            if (value == null) continue;
            float c = normalizeThermalValue(value);
            if (!plausibleCpuTemp(c)) continue;

            String name = extractString(line, "mName\\s*=\\s*([^,}]+)");
            if (name == null) name = extractString(line, "name\\s*=\\s*([^,}]+)");
            if (name == null || name.trim().isEmpty()) name = "thermalservice CPU";
            if (Float.isNaN(best) || c > best) {
                best = c;
                bestName = name.trim();
            }
        }
        return Float.isNaN(best) ? CpuTempSample.none() : new CpuTempSample(best, bestName);
    }

    private CpuTempSample parseSysfsCpu(String raw) {
        if (raw == null) return CpuTempSample.none();
        float best = Float.NaN;
        String bestName = "";
        for (String line : raw.split("\\n")) {
            if (line.startsWith("[exit=")) continue;
            String[] p = line.trim().split("\\|", 2);
            if (p.length != 2) continue;
            String name = p[0].trim();
            String lower = name.toLowerCase(Locale.US);
            boolean candidate = lower.matches(".*(cpu|soc|cpuss|ap[-_]?therm|tsens|cluster|prime|big|little|silver|gold).*" );
            boolean excluded = lower.matches(".*(battery|batt|gpu|skin|usb|charger|pa[-_]?therm).*" );
            if (!candidate || excluded) continue;
            try {
                float c = normalizeThermalValue(Float.parseFloat(p[1].trim()));
                if (!plausibleCpuTemp(c)) continue;
                if (Float.isNaN(best) || c > best) {
                    best = c;
                    bestName = name;
                }
            } catch (Throwable ignored) { }
        }
        return Float.isNaN(best) ? CpuTempSample.none() : new CpuTempSample(best, bestName);
    }

    private float normalizeThermalValue(float value) {
        float abs = Math.abs(value);
        if (abs >= 1000f) return value / 1000f;
        if (abs >= 200f) return value / 10f;
        return value;
    }

    private boolean plausibleCpuTemp(float c) {
        return Float.isFinite(c) && c >= 5f && c <= 125f;
    }

    private Float extractFloat(String text, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
        if (!m.find()) return null;
        try { return Float.parseFloat(m.group(1)); } catch (Throwable ignored) { return null; }
    }

    private String extractString(String text, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text);
        return m.find() ? m.group(1) : null;
    }

    private void updateFpsOverlayIfDue() {
        if (fpsView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastFpsSampleMs < FPS_SAMPLE_INTERVAL_MS || fpsReadInFlight) return;
        lastFpsSampleMs = now;

        if (!ShizukuBridge.isReady()) {
            ShizukuBridge.ensureConnected(false);
            fpsView.setText("FPS …");
            return;
        }

        fpsReadInFlight = true;
        fpsWorker.execute(() -> {
            FpsSample sample = readActiveGameFps();
            main.post(() -> {
                fpsReadInFlight = false;
                if (fpsView == null) return;
                if (sample.fps > 0) fpsView.setText((sample.approximate ? "FPS~ " : "FPS ") + sample.fps);
                else fpsView.setText("FPS --");
            });
        });
    }

    private FpsSample readActiveGameFps() {
        try {
            IUserService service = ShizukuBridge.awaitService(3000);
            String focus = service.exec(
                    "dumpsys activity activities | grep -E -m 1 'mResumedActivity|topResumedActivity'; " +
                    "dumpsys window windows | grep -E -m 1 'mCurrentFocus|mFocusedApp'");

            String pkg = parseForegroundPackage(focus);
            if (pkg == null) pkg = findRunningPubgPackage(service);
            if (pkg == null) {
                writeFpsDiagnostics("waiting for game", "", "", "", -1, false);
                return FpsSample.none("waiting for game");
            }

            if (!pkg.equals(cachedPackage)) {
                cachedPackage = pkg;
                cachedLayer = null;
                cachedLayerAtMs = 0L;
                prepareTimeStats(service, pkg);
            }

            long now = System.currentTimeMillis();
            if (cachedLayer != null && now - cachedLayerAtMs <= LAYER_RESCAN_MS) {
                int fps = readSurfaceLayerFps(service, cachedLayer);
                if (fps > 0) {
                    writeFpsDiagnostics("game frame timing ✓", "SurfaceFlinger latency", pkg, cachedLayer, fps, false);
                    return new FpsSample(fps, false);
                }
                cachedLayer = null;
            }

            String layers = service.exec("dumpsys SurfaceFlinger --list");
            List<String> candidates = rankGameLayers(layers, pkg);
            for (int i = 0; i < Math.min(12, candidates.size()); i++) {
                String layer = candidates.get(i);
                int fps = readSurfaceLayerFps(service, layer);
                if (fps > 0) {
                    cachedLayer = layer;
                    cachedLayerAtMs = now;
                    writeFpsDiagnostics("game frame timing ✓", "SurfaceFlinger latency", pkg, layer, fps, false);
                    return new FpsSample(fps, false);
                }
            }

            if (!pkg.equals(timeStatsPackage)) prepareTimeStats(service, pkg);
            if (now - timeStatsPreparedAtMs >= 1200L) {
                TimeStatsSample ts = readTimeStatsFps(service, pkg);
                if (ts.fps > 0) {
                    cachedLayer = ts.layer;
                    cachedLayerAtMs = now;
                    writeFpsDiagnostics("game TimeStats ✓", "SurfaceFlinger TimeStats", pkg, ts.layer, ts.fps, false);
                    return new FpsSample(ts.fps, false);
                }
            }

            int gfxFps = readGfxInfoFps(service, pkg);
            if (gfxFps > 0) {
                writeFpsDiagnostics("game gfx framestats ✓", "gfxinfo", pkg, "", gfxFps, false);
                return new FpsSample(gfxFps, false);
            }

            String global = service.exec("dumpsys SurfaceFlinger --latency");
            int displayFps = parseSurfaceLatency(global);
            if (displayFps > 0) {
                writeFpsDiagnostics("game layer unavailable • display fallback", "display compositor", pkg, "", displayFps, true);
                return new FpsSample(displayFps, true);
            }

            writeFpsDiagnostics("game found • no usable frame counter", "", pkg, "", -1, false);
            return FpsSample.none("no usable frame counter");
        } catch (Throwable t) {
            writeFpsDiagnostics("FPS read failed: " + t.getClass().getSimpleName(), "", cachedPackage, cachedLayer, -1, false);
            return FpsSample.none("FPS read failed");
        }
    }

    private void prepareTimeStats(IUserService service, String pkg) {
        try {
            service.exec("dumpsys SurfaceFlinger --timestats -clear >/dev/null 2>&1; " +
                    "dumpsys SurfaceFlinger --timestats -enable >/dev/null 2>&1");
            timeStatsPackage = pkg;
            timeStatsPreparedAtMs = System.currentTimeMillis();
        } catch (Throwable ignored) { }
    }

    private void tryEnableTimeStatsAsync() {
        fpsWorker.execute(() -> {
            try {
                IUserService service = ShizukuBridge.awaitService(2500);
                service.exec("dumpsys SurfaceFlinger --timestats -enable >/dev/null 2>&1");
            } catch (Throwable ignored) { }
        });
    }

    private TimeStatsSample readTimeStatsFps(IUserService service, String pkg) {
        try {
            String raw = service.exec("dumpsys SurfaceFlinger --timestats -dump -maxlayers 200");
            if (raw == null || raw.isEmpty()) return TimeStatsSample.none();
            String lowerPkg = pkg.toLowerCase(Locale.US);
            String shortName = pkg.substring(pkg.lastIndexOf('.') + 1).toLowerCase(Locale.US);

            int bestScore = Integer.MIN_VALUE;
            int bestFps = -1;
            String bestLayer = "";

            String[] blocks = raw.split("(?=layerName\\s*=)");
            for (String block : blocks) {
                String layer = extractString(block, "layerName\\s*=\\s*([^\\n\\r]+)");
                String packageName = extractString(block, "packageName\\s*=\\s*([^\\n\\r]+)");
                if (layer == null) layer = "";
                if (packageName == null) packageName = "";
                String l = layer.toLowerCase(Locale.US);
                String p = packageName.toLowerCase(Locale.US);

                int score = 0;
                if (p.equals(lowerPkg)) score += 160;
                else if (p.contains(lowerPkg)) score += 120;
                if (l.contains(lowerPkg)) score += 100;
                if (shortName.length() >= 3 && l.contains(shortName)) score += 25;
                if (l.contains("surfaceview")) score += 50;
                if (l.contains("blast")) score += 35;
                if (l.contains("ue4") || l.contains("unreal")) score += 25;
                if (l.contains("snapshot") || l.contains("wallpaper") || l.contains("statusbar")) score -= 100;
                if (score <= 0) continue;

                Float average = extractFloat(block, "averageFPS\\s*=\\s*([-+]?\\d+(?:\\.\\d+)?)");
                if (average == null || average <= 0f) {
                    average = extractFloat(block, "renderRate\\s*=\\s*(\\d+)\\s*fps");
                }
                if (average == null) continue;
                int fps = Math.round(average);
                if (fps < 1 || fps > 360) continue;

                Float totalFrames = extractFloat(block, "totalFrames\\s*=\\s*(\\d+)");
                if (totalFrames != null) score += Math.min(30, Math.round(totalFrames / 120f));

                if (score > bestScore || (score == bestScore && fps > bestFps)) {
                    bestScore = score;
                    bestFps = fps;
                    bestLayer = layer.trim();
                }
            }
            return bestFps > 0 ? new TimeStatsSample(bestFps, bestLayer) : TimeStatsSample.none();
        } catch (Throwable ignored) {
            return TimeStatsSample.none();
        }
    }

    private String parseForegroundPackage(String output) {
        if (output == null) return null;
        Matcher m = Pattern.compile("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+){2,})/")
                .matcher(output);
        while (m.find()) {
            String pkg = m.group(1);
            if (BuildConfig.APPLICATION_ID.equals(pkg)) continue;
            if (pkg.startsWith("com.android.")) continue;
            if (pkg.startsWith("android.")) continue;
            return pkg;
        }
        return null;
    }

    private String findRunningPubgPackage(IUserService service) {
        for (String pkg : PUBG_PACKAGES) {
            try {
                String out = service.exec("pidof " + shellQuote(pkg));
                String cleaned = stripExit(out).trim();
                if (cleaned.matches(".*\\d+.*")) return pkg;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private List<String> rankGameLayers(String output, String pkg) {
        if (output == null || pkg == null) return Collections.emptyList();
        String lowerPkg = pkg.toLowerCase(Locale.US);
        String shortName = pkg.substring(pkg.lastIndexOf('.') + 1).toLowerCase(Locale.US);
        List<LayerCandidate> scored = new ArrayList<>();
        for (String raw : output.split("\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("[exit=")) continue;
            String lower = line.toLowerCase(Locale.US);
            int score = 0;
            if (lower.contains(lowerPkg)) score += 140;
            if (shortName.length() >= 3 && lower.contains(shortName)) score += 25;
            if (lower.contains("surfaceview")) score += 70;
            if (lower.contains("blast")) score += 55;
            if (lower.contains("gameactivity")) score += 30;
            if (lower.contains("ue4") || lower.contains("unreal")) score += 25;
            if (lower.contains("bufferqueue")) score += 10;
            if (lower.contains("snapshot") || lower.contains("wallpaper") || lower.contains("statusbar")) score -= 90;
            if (score > 0) scored.add(new LayerCandidate(line, score));
        }
        scored.sort(Comparator.comparingInt((LayerCandidate c) -> c.score).reversed());
        List<String> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (LayerCandidate c : scored) if (seen.add(c.layer)) result.add(c.layer);
        return result;
    }

    private int readSurfaceLayerFps(IUserService service, String layer) {
        if (layer == null || layer.isEmpty()) return -1;
        try {
            String out = service.exec("dumpsys SurfaceFlinger --latency " + shellQuote(layer));
            return parseSurfaceLatency(out);
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private int parseSurfaceLatency(String raw) {
        if (raw == null) return -1;
        List<Long> timestamps = new ArrayList<>();
        String[] lines = raw.split("\\n");
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("[exit=")) continue;
            String[] p = line.split("\\s+");
            if (p.length < 2) continue;
            try {
                long actualPresent = Long.parseLong(p[1]);
                if (validFrameTimestamp(actualPresent)) timestamps.add(actualPresent);
            } catch (Throwable ignored) { }
        }
        return fpsFromTimestamps(timestamps);
    }

    private int readGfxInfoFps(IUserService service, String pkg) {
        try {
            String raw = service.exec("dumpsys gfxinfo " + shellQuote(pkg) + " framestats");
            String[] lines = raw.split("\\n");
            int frameCompletedIndex = -1;
            List<Long> timestamps = new ArrayList<>();
            for (String rawLine : lines) {
                String line = rawLine.trim();
                if (line.startsWith("Flags,IntendedVsync")) {
                    String[] header = line.split(",");
                    for (int i = 0; i < header.length; i++) {
                        if ("FrameCompleted".equals(header[i].trim())) {
                            frameCompletedIndex = i;
                            break;
                        }
                    }
                    continue;
                }
                if (frameCompletedIndex < 0 || line.isEmpty() || !Character.isDigit(line.charAt(0))) continue;
                String[] cols = line.split(",");
                if (frameCompletedIndex >= cols.length) continue;
                try {
                    long completed = Long.parseLong(cols[frameCompletedIndex].trim());
                    if (validFrameTimestamp(completed)) timestamps.add(completed);
                } catch (Throwable ignored) { }
            }
            return fpsFromTimestamps(timestamps);
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private boolean validFrameTimestamp(long value) {
        return value > 0 && value < 9_000_000_000_000_000_000L;
    }

    private int fpsFromTimestamps(List<Long> raw) {
        if (raw == null || raw.size() < 3) return -1;
        Collections.sort(raw);
        List<Long> ts = new ArrayList<>();
        long previous = Long.MIN_VALUE;
        for (long value : raw) {
            if (value != previous) ts.add(value);
            previous = value;
        }
        if (ts.size() < 3) return -1;

        long newest = ts.get(ts.size() - 1);
        long nowNs = System.nanoTime();
        if (nowNs > newest && nowNs - newest > 2_500_000_000L) return -1;

        long windowStart = newest - 1_000_000_000L;
        int firstIndex = 0;
        while (firstIndex < ts.size() - 2 && ts.get(firstIndex) < windowStart) firstIndex++;
        long first = ts.get(firstIndex);
        long duration = newest - first;
        int intervals = ts.size() - 1 - firstIndex;
        if (intervals < 2 || duration < 120_000_000L) return -1;

        double fps = intervals * 1_000_000_000.0 / duration;
        if (!Double.isFinite(fps) || fps < 1.0 || fps > 360.0) return -1;
        return (int) Math.round(fps);
    }

    private void invalidateFpsTarget(String reason) {
        cachedLayer = null;
        cachedLayerAtMs = 0L;
        timeStatsPackage = null;
        timeStatsPreparedAtMs = 0L;
        if (fpsView != null) fpsView.setText("FPS …");
        writeFpsDiagnostics(reason + " • reacquiring game counter", "", cachedPackage, "", -1, false);
    }

    private void writeFpsDiagnostics(String status, String method, String pkg, String layer,
                                     int fps, boolean approximate) {
        String safeLayer = layer == null ? "" : layer;
        if (safeLayer.length() > 180) safeLayer = safeLayer.substring(0, 180);
        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                .putString(GamingPrefs.FPS_DIAG_STATUS, status == null ? "" : status)
                .putString(GamingPrefs.FPS_DIAG_METHOD, method == null ? "" : method)
                .putString(GamingPrefs.FPS_DIAG_PACKAGE, pkg == null ? "" : pkg)
                .putString(GamingPrefs.FPS_DIAG_LAYER, safeLayer)
                .putInt(GamingPrefs.FPS_LAST_VALUE, fps)
                .putBoolean(GamingPrefs.FPS_APPROXIMATE, approximate)
                .apply();
    }

    private String stripExit(String value) {
        if (value == null) return "";
        return value.replaceAll("(?m)^\\[exit=\\d+\\]$", "").trim();
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Throwable ignored) { }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "VPQCLAN Performance Monitor",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("FPS, CPU temperature and battery temperature overlay");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String message) {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("VPQCLAN Performance Monitor")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class LayerCandidate {
        final String layer;
        final int score;
        LayerCandidate(String layer, int score) { this.layer = layer; this.score = score; }
    }

    private static final class FpsSample {
        final int fps;
        final boolean approximate;
        FpsSample(int fps, boolean approximate) { this.fps = fps; this.approximate = approximate; }
        static FpsSample none(String ignored) { return new FpsSample(-1, false); }
    }

    private static final class TimeStatsSample {
        final int fps;
        final String layer;
        TimeStatsSample(int fps, String layer) { this.fps = fps; this.layer = layer; }
        static TimeStatsSample none() { return new TimeStatsSample(-1, ""); }
    }

    private static final class CpuTempSample {
        final float celsius;
        final String sensor;
        CpuTempSample(float celsius, String sensor) { this.celsius = celsius; this.sensor = sensor; }
        boolean valid() { return Float.isFinite(celsius) && celsius >= 5f && celsius <= 125f; }
        static CpuTempSample none() { return new CpuTempSample(Float.NaN, ""); }
    }
}
