package com.besnik.pixelperfect;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * VPQCLAN C.R V4.6 main page.
 *
 * Intentionally minimal: performance monitoring only. All custom-resolution
 * controls live on CustomResolutionActivity and are opened with one button.
 */
public class MainActivity extends Activity implements ShizukuBridge.Listener {

    private static final int BG = Color.parseColor("#0F1011");
    private static final int CARD = Color.parseColor("#17181A");
    private static final int TEXT = Color.parseColor("#F4F1EA");
    private static final int MUTED = Color.parseColor("#A5A19A");
    private static final int ACCENT = Color.parseColor("#C8A96B");
    private static final int BORDER = Color.parseColor("#303236");
    private static final int WARNING = Color.parseColor("#E0B27A");

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView shizukuStatus;
    private TextView fpsValue;
    private TextView cpuValue;
    private TextView batteryValue;
    private TextView fpsMethod;
    private CheckBox fpsToggle;
    private CheckBox cpuToggle;
    private CheckBox batteryToggle;
    private CheckBox lockToggle;

    private final Runnable liveUpdater = new Runnable() {
        @Override
        public void run() {
            refreshLiveValues();
            main.postDelayed(this, 850L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());

        ShizukuBridge.init(this);
        ShizukuBridge.addListener(this);
        ShizukuBridge.ensureConnected(false);

        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        boolean anyEnabled = sp.getBoolean(GamingPrefs.FPS_ENABLED, false)
                || sp.getBoolean(GamingPrefs.CPU_TEMP_ENABLED, false)
                || sp.getBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, false);
        if (anyEnabled && Settings.canDrawOverlays(this)) {
            startPerformanceService(PerfOverlayService.ACTION_REFRESH);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ShizukuBridge.ensureConnected(false);
        main.removeCallbacks(liveUpdater);
        main.post(liveUpdater);
    }

    @Override
    protected void onPause() {
        main.removeCallbacks(liveUpdater);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        ShizukuBridge.removeListener(this);
        main.removeCallbacks(liveUpdater);
        super.onDestroy();
    }

    private View buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);

        ImageView wallpaper = new ImageView(this);
        wallpaper.setImageResource(R.drawable.vpqclan_wallpaper);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setAlpha(0.25f);
        frame.addView(wallpaper, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = vertical();
        root.setPadding(dp(16), dp(18), dp(16), dp(26));
        root.setBackgroundColor(Color.TRANSPARENT);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = label("VPQCLAN Performance Monitor", 26, true, TEXT);
        root.addView(title, match());

        TextView version = label("VPQCLAN C.R  •  V4.6", 13, true, ACCENT);
        version.setPadding(0, dp(4), 0, dp(5));
        root.addView(version, match());

        TextView subtitle = label("FPS • CPU temperature • battery temperature", 13, false, MUTED);
        root.addView(subtitle, matchWithBottom(14));

        root.addView(buildMonitorCard(), matchWithBottom(14));
        root.addView(buildCustomResolutionButton(), matchWithBottom(14));

        TextView footer = label("This App is part of VPQCLAN, made by VPQ SNIKA", 12, true, MUTED);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(0, dp(8), 0, 0);
        root.addView(footer, match());

        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return frame;
    }

    private View buildMonitorCard() {
        LinearLayout card = card();

        LinearLayout statusRow = row();
        LinearLayout statusText = vertical();
        statusText.addView(label("Shizuku", 13, true, TEXT));
        shizukuStatus = label("Checking…", 12, true, MUTED);
        statusText.addView(shizukuStatus);
        statusRow.addView(statusText, weight());

        Button connect = button("Connect", false);
        connect.setOnClickListener(v -> {
            boolean opened = ShizukuBridge.connectOrOpenManager(this);
            if (!ShizukuBridge.isShizukuRunning()) {
                Toast.makeText(this,
                        opened
                                ? "Start Shizuku, then return. VPQCLAN reconnects automatically."
                                : "Shizuku is not installed or could not be opened.",
                        Toast.LENGTH_LONG).show();
            }
        });
        statusRow.addView(connect, wrap());
        card.addView(statusRow, match());

        divider(card);

        LinearLayout values = row();
        LinearLayout fpsCell = metricCell("FPS", "--");
        LinearLayout cpuCell = metricCell("CPU", "--.-°C");
        LinearLayout batteryCell = metricCell("BAT", "--.-°C");
        fpsValue = (TextView) fpsCell.getChildAt(1);
        cpuValue = (TextView) cpuCell.getChildAt(1);
        batteryValue = (TextView) batteryCell.getChildAt(1);
        values.addView(fpsCell, weight());
        values.addView(cpuCell, weight());
        values.addView(batteryCell, weight());
        card.addView(values, match());

        fpsMethod = label("FPS: waiting for monitor", 11, false, MUTED);
        fpsMethod.setPadding(dp(2), dp(8), dp(2), dp(2));
        card.addView(fpsMethod, match());

        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);

        fpsToggle = checkBox("FPS overlay", sp.getBoolean(GamingPrefs.FPS_ENABLED, false));
        cpuToggle = checkBox("CPU temperature overlay", sp.getBoolean(GamingPrefs.CPU_TEMP_ENABLED, false));
        batteryToggle = checkBox("Battery temperature overlay", sp.getBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, false));
        lockToggle = checkBox("Lock positions / touch-through", sp.getBoolean(GamingPrefs.LOCK_OVERLAYS, false));

        card.addView(fpsToggle, matchWithTop(8));
        card.addView(cpuToggle, match());
        card.addView(batteryToggle, match());
        card.addView(lockToggle, match());

        TextView tip = label("Each overlay is independent and draggable while unlocked. CPU uses CPU/SoC thermal sensors; BAT uses Android's battery sensor.", 11, false, MUTED);
        tip.setPadding(dp(2), dp(5), dp(2), 0);
        card.addView(tip, match());

        LinearLayout actions = row();
        Button permission = button("Overlay Permission", false);
        permission.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        actions.addView(permission, weight());

        Button apply = button("Apply HUD", true);
        apply.setOnClickListener(v -> applyHud());
        actions.addView(apply, weight());
        card.addView(actions, matchWithTop(10));

        Button stop = button("Stop Monitor", false);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, PerfOverlayService.class));
            Toast.makeText(this, "Performance monitor stopped", Toast.LENGTH_SHORT).show();
        });
        card.addView(stop, matchWithTop(8));

        return card;
    }

    private View buildCustomResolutionButton() {
        LinearLayout card = card();
        TextView title = label("Custom Resolution", 15, true, TEXT);
        card.addView(title, match());
        TextView text = label("Resolution, DPI, Navigation Safe, monitor output and saved profiles are kept on a separate page.", 12, false, MUTED);
        text.setPadding(0, dp(4), 0, dp(8));
        card.addView(text, match());

        Button open = button("OPEN CUSTOM RESOLUTION TOOLS", true);
        open.setOnClickListener(v -> startActivity(new Intent(this, CustomResolutionActivity.class)));
        card.addView(open, match());
        return card;
    }

    private void applyHud() {
        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        sp.edit()
                .putBoolean(GamingPrefs.FPS_ENABLED, fpsToggle.isChecked())
                .putBoolean(GamingPrefs.CPU_TEMP_ENABLED, cpuToggle.isChecked())
                .putBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, batteryToggle.isChecked())
                .putBoolean(GamingPrefs.LOCK_OVERLAYS, lockToggle.isChecked())
                .apply();

        boolean wantsOverlay = fpsToggle.isChecked() || cpuToggle.isChecked() || batteryToggle.isChecked();
        if (wantsOverlay && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant overlay permission first.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }

        if ((fpsToggle.isChecked() || cpuToggle.isChecked()) && !ShizukuBridge.isReady()) {
            if (!ShizukuBridge.isShizukuRunning()) {
                ShizukuBridge.openManager(this);
                Toast.makeText(this,
                        "Start Shizuku and return. CPU/FPS monitoring will reconnect automatically.",
                        Toast.LENGTH_LONG).show();
            } else {
                ShizukuBridge.ensureConnected(false);
            }
        }

        startPerformanceService(PerfOverlayService.ACTION_REFRESH);
        Toast.makeText(this, "Performance HUD updated", Toast.LENGTH_SHORT).show();
    }

    private void startPerformanceService(String action) {
        Intent i = new Intent(this, PerfOverlayService.class);
        i.setAction(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
    }

    private void refreshLiveValues() {
        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);

        int fps = sp.getInt(GamingPrefs.FPS_LAST_VALUE, -1);
        boolean approx = sp.getBoolean(GamingPrefs.FPS_APPROXIMATE, false);
        fpsValue.setText(fps > 0 ? (approx ? "~" : "") + fps : "--");

        float cpu = sp.getFloat(GamingPrefs.CPU_LAST_VALUE, Float.NaN);
        cpuValue.setText(Float.isNaN(cpu) ? "--.-°C" : String.format(Locale.US, "%.1f°C", cpu));

        float bat = readBatteryTemperature();
        if (Float.isNaN(bat)) bat = sp.getFloat(GamingPrefs.BATTERY_LAST_VALUE, Float.NaN);
        batteryValue.setText(Float.isNaN(bat) ? "--.-°C" : String.format(Locale.US, "%.1f°C", bat));

        String diag = sp.getString(GamingPrefs.FPS_DIAG_STATUS, "waiting for monitor");
        String method = sp.getString(GamingPrefs.FPS_DIAG_METHOD, "");
        String sensor = sp.getString(GamingPrefs.CPU_SENSOR_NAME, "");
        StringBuilder line = new StringBuilder("FPS: ").append(diag);
        if (!method.isEmpty()) line.append(" • ").append(method);
        if (!sensor.isEmpty()) line.append("   CPU: ").append(sensor);
        fpsMethod.setText(line.toString());
        fpsMethod.setTextColor(fps > 0 ? ACCENT : MUTED);
    }

    private float readBatteryTemperature() {
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return Float.NaN;
        int tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        return tenths == Integer.MIN_VALUE ? Float.NaN : tenths / 10f;
    }

    @Override
    public void onShizukuState(ShizukuBridge.State state, String message) {
        runOnUiThread(() -> {
            shizukuStatus.setText(message == null ? state.name() : message);
            if (state == ShizukuBridge.State.READY) shizukuStatus.setTextColor(ACCENT);
            else if (state == ShizukuBridge.State.SHIZUKU_OFF || state == ShizukuBridge.State.PERMISSION_REQUIRED)
                shizukuStatus.setTextColor(WARNING);
            else shizukuStatus.setTextColor(MUTED);
        });
    }

    private CheckBox checkBox(String text, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setTextColor(TEXT);
        box.setTextSize(13f);
        box.setChecked(checked);
        return box;
    }

    private LinearLayout metricCell(String title, String value) {
        LinearLayout box = vertical();
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(10), dp(4), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xAA111214);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), BORDER);
        box.setBackground(bg);

        TextView t = label(title, 11, true, MUTED);
        t.setGravity(Gravity.CENTER);
        box.addView(t, match());
        TextView v = label(value, 18, true, TEXT);
        v.setGravity(Gravity.CENTER);
        box.addView(v, match());
        return box;
    }

    private LinearLayout card() {
        LinearLayout l = vertical();
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE817181A);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), BORDER);
        l.setBackground(bg);
        return l;
    }

    private void divider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(12), 0, dp(12));
        parent.addView(line, lp);
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12f);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.parseColor("#151515") : TEXT);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? ACCENT : Color.parseColor("#25272A"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), primary ? ACCENT : BORDER);
        b.setBackground(bg);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        return b;
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWithBottom(int bottom) {
        LinearLayout.LayoutParams lp = match();
        lp.bottomMargin = dp(bottom);
        return lp;
    }

    private LinearLayout.LayoutParams matchWithTop(int top) {
        LinearLayout.LayoutParams lp = match();
        lp.topMargin = dp(top);
        return lp;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
