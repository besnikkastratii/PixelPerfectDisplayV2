package com.besnik.pixelperfect;

import android.os.RemoteException;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Root shell backend. It never edits game files or game process memory. */
public final class RootBridge {
    public enum State { UNKNOWN, CHECKING, READY, UNAVAILABLE }
    public interface Callback { void onRootState(State state, String message); }

    private static volatile State state = State.UNKNOWN;
    private static volatile String message = "Root not checked";

    private static final IUserService ROOT_SERVICE = new IUserService.Stub() {
        @Override public void destroy() { }
        @Override public String exec(String command) throws RemoteException {
            try {
                return RootBridge.exec(command, 10_000L);
            } catch (Throwable t) {
                RemoteException e = new RemoteException("Root command failed: " + t.getMessage());
                e.initCause(t);
                throw e;
            }
        }
    };

    private RootBridge() { }

    public static State getState() { return state; }
    public static String getMessage() { return message; }
    public static boolean isReady() { return state == State.READY; }
    public static IUserService getService() { return isReady() ? ROOT_SERVICE : null; }

    public static void probeAsync(Callback callback) {
        if (state == State.READY) {
            if (callback != null) callback.onRootState(state, message);
            return;
        }
        if (state == State.CHECKING) {
            if (callback != null) {
                new Thread(() -> {
                    for (int i = 0; i < 60 && state == State.CHECKING; i++) {
                        try { Thread.sleep(100L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                    }
                    callback.onRootState(state, message);
                }, "vpq-root-waiter").start();
            }
            return;
        }
        state = State.CHECKING;
        message = "Requesting root…";
        new Thread(() -> {
            boolean ok = false;
            String detail;
            try {
                String out = runSu("id", 5_000L);
                ok = out.contains("uid=0") || out.contains("gid=0(root)");
                detail = ok ? "Root ready" : "Root unavailable";
            } catch (Throwable t) {
                detail = "Root unavailable";
            }
            state = ok ? State.READY : State.UNAVAILABLE;
            message = detail;
            if (callback != null) callback.onRootState(state, message);
        }, "vpq-root-probe").start();
    }

    public static boolean probeBlocking(long timeoutMs) {
        if (isReady()) return true;
        try {
            String out = runSu("id", Math.max(1000L, timeoutMs));
            boolean ok = out.contains("uid=0") || out.contains("gid=0(root)");
            state = ok ? State.READY : State.UNAVAILABLE;
            message = ok ? "Root ready" : "Root unavailable";
            return ok;
        } catch (Throwable t) {
            state = State.UNAVAILABLE;
            message = "Root unavailable";
            return false;
        }
    }

    public static String exec(String command, long timeoutMs) throws Exception {
        if (!isReady() && !probeBlocking(Math.min(timeoutMs, 5000L))) {
            throw new SecurityException("Root permission is not available");
        }
        return runSu(command, timeoutMs);
    }

    private static String runSu(String command, long timeoutMs) throws Exception {
        Process process = new ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        Thread reader = new Thread(() -> {
            try (InputStream in = process.getInputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) >= 0) bytes.write(buffer, 0, n);
            } catch (Throwable ignored) { }
        }, "vpq-root-reader");
        reader.start();

        boolean finished = process.waitFor(Math.max(1000L, timeoutMs), TimeUnit.MILLISECONDS);
        if (!finished) {
            process.destroyForcibly();
            reader.join(400L);
            throw new RuntimeException("Root command timed out");
        }
        reader.join(800L);
        String out = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
        return out + (out.endsWith("\n") || out.isEmpty() ? "" : "\n") + "[root exit=" + process.exitValue() + "]";
    }
}
