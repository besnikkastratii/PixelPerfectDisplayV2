# VPQCLAN C.R V4.4

Package: `com.besnik.pixelperfect`

## V4.4 reliability priorities

- One persistent Shizuku daemon bridge shared by the main app and Performance HUD.
- Display resolution/DPI configuration changes no longer intentionally tear down the shell connection.
- Automatic Shizuku UserService rebind after binder/service interruption.
- Privileged shell commands wait briefly and retry once after reconnect.
- User actions are queued while Shizuku is reconnecting and replayed when the shell is ready.
- Connect opens the Shizuku manager when Shizuku itself is not running; returning to VPQCLAN triggers automatic reconnect.
- FPS detector rebuilt around foreground package detection + ranked SurfaceFlinger game-layer discovery.
- FPS layer is reacquired after resolution, orientation, display, Shizuku and HUD changes.
- `gfxinfo framestats` fallback when SurfaceFlinger layer timing is unavailable.
- Last-resort compositor FPS is clearly shown as `FPS~` so it is not confused with exact game FPS.
- Live FPS diagnostics are shown inside Gaming Tools.
- Battery overlay continues to use `BatteryManager.EXTRA_TEMPERATURE` only (battery temperature, never CPU temperature).

## Preserved from V4.3

- FPS and battery overlays are independent, draggable and lockable/touch-through.
- VPQCLAN Kosovo + Albania battlefield wallpaper and matching launcher icon.
- HyperX/USB audio recovery controls.
- Navigation Safe resolution + DPI logic and 15-second rollback.
- Physical monitor mode and forced logical external output remain separate.
