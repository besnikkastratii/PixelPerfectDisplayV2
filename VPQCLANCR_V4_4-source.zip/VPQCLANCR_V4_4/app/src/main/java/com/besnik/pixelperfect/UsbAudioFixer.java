package com.besnik.pixelperfect;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;

/**
 * Tries to normalize Android's USB headset/device media volume without applying
 * software gain above Android's real maximum. This is intentionally best-effort
 * because vendor audio stacks expose slightly different shell commands.
 */
public final class UsbAudioFixer {
    private static final int STREAM_MUSIC = AudioManager.STREAM_MUSIC;

    // Native AudioSystem output device constants used by Android's audio shell.
    private static final int DEVICE_OUT_USB_DEVICE = 0x00004000;
    private static final int DEVICE_OUT_USB_HEADSET = 0x04000000;

    private UsbAudioFixer() { }

    public static String applyFix(Context context, IUserService shellService) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int max = 15;
        StringBuilder log = new StringBuilder();

        if (am != null) {
            try {
                max = am.getStreamMaxVolume(STREAM_MUSIC);
                am.adjustStreamVolume(STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
                am.setStreamVolume(STREAM_MUSIC, max, 0);
                log.append("Android media volume -> ").append(max).append('\n');
            } catch (Throwable t) {
                log.append("Media volume API: ").append(t.getClass().getSimpleName()).append('\n');
            }
        }

        if (shellService == null) {
            log.append("Shizuku shell unavailable; only normal media volume was changed.");
            return log.toString();
        }

        final int volumeIndex = max;
        Runnable pass = () -> {
            tryCommand(shellService, "cmd audio set-device-volume 3 " + volumeIndex + " " + DEVICE_OUT_USB_HEADSET);
            tryCommand(shellService, "cmd audio set-device-volume 3 " + volumeIndex + " " + DEVICE_OUT_USB_DEVICE);
            tryCommand(shellService, "cmd media_session volume --stream 3 --set " + volumeIndex);
        };

        // Run immediately and twice again after the USB route has had time to settle.
        pass.run();
        Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(pass, 700);
        h.postDelayed(pass, 1600);

        log.append("USB headset/device volume requested at Android max = ")
                .append(volumeIndex).append(" (3 passes)");
        return log.toString();
    }

    private static void tryCommand(IUserService service, String command) {
        try {
            service.exec(command);
        } catch (Throwable ignored) { }
    }
}
