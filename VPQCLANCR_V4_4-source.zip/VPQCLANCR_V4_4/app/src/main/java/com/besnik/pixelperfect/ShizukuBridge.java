package com.besnik.pixelperfect;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import rikka.shizuku.Shizuku;

/**
 * Process-wide Shizuku connection used by the Activity and the gaming HUD.
 *
 * V4.4 intentionally keeps one daemon UserService alive instead of binding a
 * second temporary service from every screen/service.  Display-size/DPI
 * changes may recreate Android UI resources, but they should no longer tear
 * down the privileged shell connection.
 */
public final class ShizukuBridge {

    public enum State {
        READY,
        CONNECTING,
        PERMISSION_REQUIRED,
        SHIZUKU_OFF,
        ERROR
    }

    public interface Listener {
        void onShizukuState(State state, String message);
    }

    private static final int REQ_SHIZUKU = 4102;
    private static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    private static final Object LOCK = new Object();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Set<Listener> LISTENERS = new CopyOnWriteArraySet<>();

    private static volatile IUserService service;
    private static volatile boolean binding;
    private static volatile boolean initialized;
    private static volatile State state = State.CONNECTING;
    private static volatile String stateMessage = "Checking Shizuku…";
    private static Context appContext;

    private static final Shizuku.UserServiceArgs SERVICE_ARGS = new Shizuku.UserServiceArgs(
            new ComponentName(BuildConfig.APPLICATION_ID, UserService.class.getName()))
            .daemon(true)
            .processNameSuffix("vpqclan-shell-v44")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
            .tag("vpqclan-shell-v44");

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            synchronized (LOCK) {
                binding = false;
                if (binder != null && binder.pingBinder()) {
                    service = IUserService.Stub.asInterface(binder);
                    setStateLocked(State.READY, "Ready");
                } else {
                    service = null;
                    setStateLocked(State.ERROR, "Privileged service unavailable");
                }
                LOCK.notifyAll();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            markServiceDisconnected("Reconnecting to Shizuku…");
            scheduleReconnect(250);
        }

        @Override
        public void onBindingDied(ComponentName name) {
            markServiceDisconnected("Shizuku service restarted — reconnecting…");
            scheduleReconnect(250);
        }
    };

    private static final Shizuku.OnBinderReceivedListener BINDER_RECEIVED = () -> {
        setState(State.CONNECTING, "Shizuku started — connecting…");
        ensureConnected(false);
    };

    private static final Shizuku.OnBinderDeadListener BINDER_DEAD = () -> {
        synchronized (LOCK) {
            service = null;
            binding = false;
            setStateLocked(State.SHIZUKU_OFF, "Shizuku stopped");
            LOCK.notifyAll();
        }
    };

    private static final Shizuku.OnRequestPermissionResultListener PERMISSION_RESULT =
            (requestCode, grantResult) -> {
                if (requestCode != REQ_SHIZUKU) return;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    setState(State.CONNECTING, "Permission granted — connecting…");
                    bindUserService();
                } else {
                    setState(State.PERMISSION_REQUIRED, "Shizuku permission denied");
                }
            };

    private ShizukuBridge() { }

    public static void init(Context context) {
        if (context != null) appContext = context.getApplicationContext();
        synchronized (LOCK) {
            if (initialized) return;
            // Mark initialized before the sticky callback is registered: Shizuku may
            // invoke that callback synchronously when its binder is already alive.
            initialized = true;
        }
        Shizuku.addBinderReceivedListenerSticky(BINDER_RECEIVED);
        Shizuku.addBinderDeadListener(BINDER_DEAD);
        Shizuku.addRequestPermissionResultListener(PERMISSION_RESULT);
        ensureConnected(false);
    }

    public static void addListener(Listener listener) {
        if (listener == null) return;
        LISTENERS.add(listener);
        final State s = state;
        final String message = stateMessage;
        MAIN.post(() -> listener.onShizukuState(s, message));
    }

    public static void removeListener(Listener listener) {
        if (listener != null) LISTENERS.remove(listener);
    }

    public static State getState() {
        return state;
    }

    public static String getStateMessage() {
        return stateMessage;
    }

    public static boolean isReady() {
        IUserService s = service;
        if (s == null) return false;
        try {
            return s.asBinder().pingBinder();
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static IUserService getService() {
        return isReady() ? service : null;
    }

    public static boolean isShizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Connect when possible. If openManagerWhenOff is true and Shizuku is not
     * running, launch the Shizuku manager so the user can press Start.
     */
    public static void ensureConnected(boolean openManagerWhenOff) {
        if (!initialized && appContext != null) init(appContext);
        if (isReady()) {
            setState(State.READY, "Ready");
            return;
        }

        try {
            if (!Shizuku.pingBinder()) {
                setState(State.SHIZUKU_OFF, "Shizuku is not running");
                if (openManagerWhenOff && appContext != null) openManager(appContext);
                return;
            }
            if (Shizuku.isPreV11()) {
                setState(State.ERROR, "Shizuku v11+ required");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setState(State.PERMISSION_REQUIRED, "Shizuku permission required");
                Shizuku.requestPermission(REQ_SHIZUKU);
                return;
            }
            bindUserService();
        } catch (Throwable t) {
            setState(State.ERROR, "Shizuku error: " + t.getClass().getSimpleName());
        }
    }

    public static boolean connectOrOpenManager(Context context) {
        init(context);
        if (!isShizukuRunning()) {
            setState(State.SHIZUKU_OFF, "Opening Shizuku…");
            return openManager(context);
        }
        ensureConnected(false);
        return true;
    }

    public static boolean openManager(Context context) {
        if (context == null) return false;
        try {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return true;
            }
        } catch (Throwable ignored) { }

        try {
            Intent market = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + SHIZUKU_PACKAGE));
            market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(market);
            return true;
        } catch (Throwable ignored) { }
        return false;
    }

    private static void bindUserService() {
        synchronized (LOCK) {
            if (isReady() || binding) return;
            binding = true;
            setStateLocked(State.CONNECTING, "Connecting to Shizuku…");
        }
        try {
            Shizuku.bindUserService(SERVICE_ARGS, CONNECTION);
        } catch (Throwable t) {
            synchronized (LOCK) {
                binding = false;
                service = null;
                setStateLocked(State.ERROR, "Could not connect: " + t.getClass().getSimpleName());
                LOCK.notifyAll();
            }
            scheduleReconnect(700);
        }
    }

    private static void markServiceDisconnected(String message) {
        synchronized (LOCK) {
            service = null;
            binding = false;
            setStateLocked(isShizukuRunning() ? State.CONNECTING : State.SHIZUKU_OFF, message);
            LOCK.notifyAll();
        }
    }

    private static void scheduleReconnect(long delayMs) {
        MAIN.postDelayed(() -> {
            if (isReady()) return;
            if (isShizukuRunning()) ensureConnected(false);
        }, delayMs);
    }

    /**
     * Wait for the shared UserService. Call only from a background thread.
     */
    public static IUserService awaitService(long timeoutMs) throws RemoteException {
        if (isReady()) return service;
        ensureConnected(false);

        long deadline = System.currentTimeMillis() + Math.max(0, timeoutMs);
        synchronized (LOCK) {
            while (!isReady()) {
                long remain = deadline - System.currentTimeMillis();
                if (remain <= 0) break;
                try {
                    LOCK.wait(Math.min(remain, 500));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                if (!isShizukuRunning()) break;
            }
        }
        IUserService s = getService();
        if (s == null) throw new RemoteException("Shizuku service not connected");
        return s;
    }

    /**
     * Execute one shell command with one automatic rebind/retry if the daemon
     * binder disappears during a display-size/DPI change.
     */
    public static String exec(String command, long timeoutMs) throws RemoteException {
        IUserService s = awaitService(timeoutMs);
        try {
            return s.exec(command);
        } catch (RemoteException first) {
            markServiceDisconnected("Command interrupted — reconnecting…");
            scheduleReconnect(100);
            IUserService retry = awaitService(timeoutMs);
            return retry.exec(command);
        }
    }

    private static void setState(State newState, String message) {
        synchronized (LOCK) {
            setStateLocked(newState, message);
        }
    }

    private static void setStateLocked(State newState, String message) {
        state = newState;
        stateMessage = message == null ? "" : message;
        notifyListeners(newState, stateMessage);
    }

    private static void notifyListeners(State s, String message) {
        MAIN.post(() -> {
            for (Listener listener : LISTENERS) {
                try {
                    listener.onShizukuState(s, message);
                } catch (Throwable ignored) { }
            }
        });
    }
}
