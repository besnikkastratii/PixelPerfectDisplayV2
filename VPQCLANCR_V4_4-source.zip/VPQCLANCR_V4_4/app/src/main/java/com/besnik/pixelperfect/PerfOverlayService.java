package com.besnik.pixelperfect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VPQCLAN V4.4 gaming overlay.
 *
 * - Battery temperature always comes from ACTION_BATTERY_CHANGED / BatteryManager.
 *   It never reads CPU thermal zones.
 * - FPS first targets the active game's SurfaceFlinger layer, then falls back to
 *   gfxinfo framestats. A final display-compositor fallback is marked with '~'
 *   so it is never presented as exact game FPS.
 * - Shizuku is shared through ShizukuBridge and survives display resolution/DPI
 *   changes instead of creating a second temporary UserService.
 */
public class PerfOverlayService extends Service
        implements ShizukuBridge.Listener, DisplayManager.DisplayListener {

    public static final String ACTION_REFRESH = "com.besnik.pixelperfect.action.REFRESH_HUD";
    public static final String ACTION_USB_FIX_NOW = "com.besnik.pixelperfect.action.USB_FIX_NOW";

    private static final String CHANNEL_ID = "vpqclan_gaming_tools";
    private static final int NOTIFICATION_ID = 4404;
    private static final long FPS_SAMPLE_INTERVAL_MS = 850L;
    private static final long LAYER_RESCAN_MS = 4000L;

    private static final String[] PUBG_PACKAGES = {
            "com.tencent.ig",
            "com.pubg.imobile",
            "com.vng.pubgmobile",
            "com.rekoo.pubgm",
            "com.pubg.krmobile",
            "com.pubg.newstate"
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService fpsWorker = Executors.newSingleThreadExecutor();

    private WindowManager windowManager;
    private DisplayManager displayManager;
    private TextView fpsView;
    private TextView batteryView;
    private WindowManager.LayoutParams fpsParams;
    private WindowManager.LayoutParams batteryParams;

    private boolean pendingUsbFix;
    private long lastFpsSampleMs;
    private long lastBatterySampleMs;
    private boolean fpsReadInFlight;

    private volatile String cachedPackage;
    private volatile String cachedLayer;
    private volatile long cachedLayerAtMs;
    private volatile int consecutiveFpsFailures;

    private final Runnable updater = new Runnable() {
        @Override
        public void run() {
            syncOverlayViews();
            updateBatteryOverlay();
            updateFpsOverlayIfDue();
            main.postDelayed(this, 450);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        if (displayManager != null) displayManager.registerDisplayListener(this, main);

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());

        ShizukuBridge.init(this);
        ShizukuBridge.addListener(this);
        ShizukuBridge.ensureConnected(false);

        syncOverlayViews();
        writeFpsDiagnostics("waiting for PUBG", "", "", "", -1, false);
        main.post(updater);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ShizukuBridge.ensureConnected(false);

        if (intent != null && ACTION_USB_FIX_NOW.equals(intent.getAction())) {
            IUserService service = ShizukuBridge.getService();
            if (service != null) {
                UsbAudioFixer.applyFix(this, service);
                updateNotification("USB audio fix applied");
            } else {
                pendingUsbFix = true;
                updateNotification("USB audio fix queued • reconnecting Shizuku");
            }
        }

        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            invalidateFpsTarget("HUD refreshed");
        }

        syncOverlayViews();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(updater);
        ShizukuBridge.removeListener(this);
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(this); } catch (Throwable ignored) { }
        }
        fpsWorker.shutdownNow();
        removeOverlay(fpsView);
        removeOverlay(batteryView);
        fpsView = null;
        batteryView = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onShizukuState(ShizukuBridge.State state, String message) {
        if (state == ShizukuBridge.State.READY) {
            invalidateFpsTarget("Shizuku reconnected");
            if (pendingUsbFix) {
                IUserService service = ShizukuBridge.getService();
                if (service != null) {
                    pendingUsbFix = false;
                    UsbAudioFixer.applyFix(this, service);
                    updateNotification("USB audio fix applied after reconnect");
                }
            }
        } else if (state == ShizukuBridge.State.SHIZUKU_OFF) {
            writeFpsDiagnostics("Shizuku is off", "", cachedPackage, cachedLayer, -1, false);
        } else if (state == ShizukuBridge.State.CONNECTING) {
            writeFpsDiagnostics("Shizuku reconnecting", "", cachedPackage, cachedLayer, -1, false);
        }
    }

    @Override
    public void onDisplayAdded(int displayId) {
        invalidateFpsTarget("display added");
    }

    @Override
    public void onDisplayRemoved(int displayId) {
        invalidateFpsTarget("display removed");
    }

    @Override
    public void onDisplayChanged(int displayId) {
        invalidateFpsTarget("display changed");
    }

    private void syncOverlayViews() {
        if (!Settings.canDrawOverlays(this)) {
            removeOverlay(fpsView);
            removeOverlay(batteryView);
            fpsView = null;
            batteryView = null;
            return;
        }

        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        boolean fpsEnabled = sp.getBoolean(GamingPrefs.FPS_ENABLED, false);
        boolean batteryEnabled = sp.getBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, false);
        boolean locked = sp.getBoolean(GamingPrefs.LOCK_OVERLAYS, false);

        if (fpsEnabled && fpsView == null) {
            fpsView = createHudText("FPS --");
            fpsParams = createParams(
                    sp.getInt(GamingPrefs.FPS_X, dp(10)),
                    sp.getInt(GamingPrefs.FPS_Y, dp(34)));
            installDrag(fpsView, fpsParams, GamingPrefs.FPS_X, GamingPrefs.FPS_Y);
            windowManager.addView(fpsView, fpsParams);
            invalidateFpsTarget("FPS overlay enabled");
        } else if (!fpsEnabled && fpsView != null) {
            removeOverlay(fpsView);
            fpsView = null;
            fpsParams = null;
        }

        if (batteryEnabled && batteryView == null) {
            batteryView = createHudText("BAT --.-°C");
            batteryParams = createParams(
                    sp.getInt(GamingPrefs.BAT_X, dp(10)),
                    sp.getInt(GamingPrefs.BAT_Y, dp(72)));
            installDrag(batteryView, batteryParams, GamingPrefs.BAT_X, GamingPrefs.BAT_Y);
            windowManager.addView(batteryView, batteryParams);
        } else if (!batteryEnabled && batteryView != null) {
            removeOverlay(batteryView);
            batteryView = null;
            batteryParams = null;
        }

        updateTouchThrough(fpsView, fpsParams, locked);
        updateTouchThrough(batteryView, batteryParams, locked);
    }

    private TextView createHudText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13f);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xA61A1A1A);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0x66FFFFFF);
        view.setBackground(bg);
        view.setElevation(dp(4));
        return view;
    }

    private WindowManager.LayoutParams createParams(int x, int y) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        return p;
    }

    private void installDrag(View view, WindowManager.LayoutParams params, String xKey, String yKey) {
        view.setOnTouchListener(new View.OnTouchListener() {
            int startX;
            int startY;
            float downX;
            float downY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean locked = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE)
                        .getBoolean(GamingPrefs.LOCK_OVERLAYS, false);
                if (locked) return false;

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + Math.round(event.getRawX() - downX);
                        params.y = startY + Math.round(event.getRawY() - downY);
                        try { windowManager.updateViewLayout(v, params); } catch (Throwable ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                                .putInt(xKey, params.x)
                                .putInt(yKey, params.y)
                                .apply();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void updateTouchThrough(View view, WindowManager.LayoutParams params, boolean locked) {
        if (view == null || params == null) return;
        int desired = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (locked) desired |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (params.flags != desired) {
            params.flags = desired;
            try { windowManager.updateViewLayout(view, params); } catch (Throwable ignored) { }
        }
    }

    private void updateBatteryOverlay() {
        if (batteryView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastBatterySampleMs < 1500) return;
        lastBatterySampleMs = now;

        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) {
            batteryView.setText("BAT --.-°C");
            return;
        }
        int tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        if (tenths == Integer.MIN_VALUE) {
            batteryView.setText("BAT --.-°C");
        } else {
            batteryView.setText(String.format(Locale.US, "BAT %.1f°C", tenths / 10f));
        }
    }

    private void updateFpsOverlayIfDue() {
        if (fpsView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastFpsSampleMs < FPS_SAMPLE_INTERVAL_MS || fpsReadInFlight) return;
        lastFpsSampleMs = now;

        if (!ShizukuBridge.isReady()) {
            ShizukuBridge.ensureConnected(false);
            fpsView.setText("FPS …");
            return;
        }

        fpsReadInFlight = true;
        fpsWorker.execute(() -> {
            FpsSample sample = readActiveGameFps();
            main.post(() -> {
                fpsReadInFlight = false;
                if (fpsView == null) return;
                if (sample.fps > 0) {
                    fpsView.setText((sample.approximate ? "FPS~ " : "FPS ") + sample.fps);
                } else {
                    fpsView.setText("FPS --");
                }
            });
        });
    }

    private FpsSample readActiveGameFps() {
        try {
            IUserService service = ShizukuBridge.awaitService(3000);
            String focus = service.exec(
                    "dumpsys activity activities | grep -E -m 1 'mResumedActivity|topResumedActivity'; " +
                    "dumpsys window windows | grep -E -m 1 'mCurrentFocus|mFocusedApp'");

            String pkg = parseForegroundPackage(focus);
            if (pkg == null) pkg = findRunningPubgPackage(service);
            if (pkg == null) {
                consecutiveFpsFailures++;
                writeFpsDiagnostics("waiting for PUBG", "", "", "", -1, false);
                return FpsSample.none("waiting for PUBG");
            }

            if (!pkg.equals(cachedPackage)) {
                cachedPackage = pkg;
                cachedLayer = null;
                cachedLayerAtMs = 0;
            }

            long now = System.currentTimeMillis();
            if (cachedLayer != null && now - cachedLayerAtMs <= LAYER_RESCAN_MS) {
                int fps = readSurfaceLayerFps(service, cachedLayer);
                if (fps > 0) {
                    consecutiveFpsFailures = 0;
                    writeFpsDiagnostics("game + layer + frame timing ✓", "SurfaceFlinger", pkg,
                            cachedLayer, fps, false);
                    return new FpsSample(fps, false, "SurfaceFlinger", pkg, cachedLayer,
                            "game + layer + frame timing ✓");
                }
                cachedLayer = null;
            }

            String layers = service.exec("dumpsys SurfaceFlinger --list");
            List<String> candidates = rankGameLayers(layers, pkg);
            for (int i = 0; i < Math.min(8, candidates.size()); i++) {
                String layer = candidates.get(i);
                int fps = readSurfaceLayerFps(service, layer);
                if (fps > 0) {
                    cachedLayer = layer;
                    cachedLayerAtMs = now;
                    consecutiveFpsFailures = 0;
                    writeFpsDiagnostics("game + layer + frame timing ✓", "SurfaceFlinger", pkg,
                            layer, fps, false);
                    return new FpsSample(fps, false, "SurfaceFlinger", pkg, layer,
                            "game + layer + frame timing ✓");
                }
            }

            int gfxFps = readGfxInfoFps(service, pkg);
            if (gfxFps > 0) {
                consecutiveFpsFailures = 0;
                writeFpsDiagnostics("game found • gfx framestats ✓", "gfxinfo", pkg,
                        "", gfxFps, false);
                return new FpsSample(gfxFps, false, "gfxinfo", pkg, "",
                        "game found • gfx framestats ✓");
            }

            // Last-resort compositor cadence. This is deliberately shown as FPS~
            // because it can represent display composition rather than exact game rendering.
            String global = service.exec("dumpsys SurfaceFlinger --latency");
            int displayFps = parseSurfaceLatency(global);
            if (displayFps > 0) {
                consecutiveFpsFailures++;
                writeFpsDiagnostics("game layer unavailable • display fallback", "display fallback",
                        pkg, "", displayFps, true);
                return new FpsSample(displayFps, true, "display fallback", pkg, "",
                        "game layer unavailable • display fallback");
            }

            consecutiveFpsFailures++;
            cachedLayer = null;
            writeFpsDiagnostics("PUBG found • no usable frame timestamps", "", pkg,
                    "", -1, false);
            return FpsSample.none("PUBG found • no usable frame timestamps");
        } catch (Throwable t) {
            consecutiveFpsFailures++;
            writeFpsDiagnostics("FPS read failed: " + t.getClass().getSimpleName(), "",
                    cachedPackage, cachedLayer, -1, false);
            return FpsSample.none("FPS read failed");
        }
    }

    private String parseForegroundPackage(String output) {
        if (output == null) return null;
        Matcher m = Pattern.compile("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+){2,})/")
                .matcher(output);
        while (m.find()) {
            String pkg = m.group(1);
            if (BuildConfig.APPLICATION_ID.equals(pkg)) continue;
            if (pkg.startsWith("com.android.")) continue;
            if (pkg.startsWith("android.")) continue;
            return pkg;
        }
        return null;
    }

    private String findRunningPubgPackage(IUserService service) {
        for (String pkg : PUBG_PACKAGES) {
            try {
                String out = service.exec("pidof " + shellQuoteBare(pkg));
                String cleaned = stripExit(out).trim();
                if (cleaned.matches(".*\\d+.*")) return pkg;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private List<String> rankGameLayers(String output, String pkg) {
        if (output == null || pkg == null) return Collections.emptyList();
        String shortName = pkg.substring(pkg.lastIndexOf('.') + 1).toLowerCase(Locale.US);
        List<LayerCandidate> scored = new ArrayList<>();
        for (String raw : output.split("\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("[exit=")) continue;
            String lower = line.toLowerCase(Locale.US);
            int score = 0;
            if (lower.contains(pkg.toLowerCase(Locale.US))) score += 120;
            if (shortName.length() >= 3 && lower.contains(shortName)) score += 25;
            if (lower.contains("surfaceview")) score += 70;
            if (lower.contains("blast")) score += 55;
            if (lower.contains("gameactivity")) score += 30;
            if (lower.contains("ue4") || lower.contains("unreal")) score += 25;
            if (lower.contains("bufferqueue")) score += 10;
            if (lower.contains("snapshot") || lower.contains("wallpaper") || lower.contains("statusbar")) score -= 80;
            if (score > 0) scored.add(new LayerCandidate(line, score));
        }
        scored.sort(Comparator.comparingInt((LayerCandidate c) -> c.score).reversed());
        List<String> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (LayerCandidate c : scored) {
            if (seen.add(c.layer)) result.add(c.layer);
        }
        return result;
    }

    private int readSurfaceLayerFps(IUserService service, String layer) {
        if (layer == null || layer.isEmpty()) return -1;
        try {
            String out = service.exec("dumpsys SurfaceFlinger --latency " + shellQuote(layer));
            return parseSurfaceLatency(out);
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private int parseSurfaceLatency(String raw) {
        if (raw == null) return -1;
        List<Long> timestamps = new ArrayList<>();
        String[] lines = raw.split("\\n");
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("[exit=")) continue;
            String[] p = line.split("\\s+");
            if (p.length < 2) continue;
            try {
                long actualPresent = Long.parseLong(p[1]);
                if (validFrameTimestamp(actualPresent)) timestamps.add(actualPresent);
            } catch (Throwable ignored) { }
        }
        return fpsFromTimestamps(timestamps);
    }

    private int readGfxInfoFps(IUserService service, String pkg) {
        try {
            String raw = service.exec("dumpsys gfxinfo " + shellQuoteBare(pkg) + " framestats");
            String[] lines = raw.split("\\n");
            int frameCompletedIndex = -1;
            List<Long> timestamps = new ArrayList<>();

            for (String rawLine : lines) {
                String line = rawLine.trim();
                if (line.startsWith("Flags,IntendedVsync")) {
                    String[] header = line.split(",");
                    for (int i = 0; i < header.length; i++) {
                        if ("FrameCompleted".equals(header[i].trim())) {
                            frameCompletedIndex = i;
                            break;
                        }
                    }
                    continue;
                }
                if (frameCompletedIndex < 0 || line.isEmpty() || !Character.isDigit(line.charAt(0))) continue;
                String[] cols = line.split(",");
                if (frameCompletedIndex >= cols.length) continue;
                try {
                    long completed = Long.parseLong(cols[frameCompletedIndex].trim());
                    if (validFrameTimestamp(completed)) timestamps.add(completed);
                } catch (Throwable ignored) { }
            }
            return fpsFromTimestamps(timestamps);
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private boolean validFrameTimestamp(long value) {
        return value > 0 && value < 9_000_000_000_000_000_000L;
    }

    private int fpsFromTimestamps(List<Long> raw) {
        if (raw == null || raw.size() < 3) return -1;
        Collections.sort(raw);

        List<Long> ts = new ArrayList<>();
        long previous = Long.MIN_VALUE;
        for (long value : raw) {
            if (value != previous) ts.add(value);
            previous = value;
        }
        if (ts.size() < 3) return -1;

        long newest = ts.get(ts.size() - 1);
        long nowNs = System.nanoTime();
        // SurfaceFlinger/gfxinfo frame timestamps use the same monotonic time base
        // on Android. Reject a paused/stale frame history rather than freezing a fake FPS.
        if (nowNs > newest && nowNs - newest > 2_500_000_000L) return -1;

        long windowStart = newest - 1_000_000_000L;
        int firstIndex = 0;
        while (firstIndex < ts.size() - 2 && ts.get(firstIndex) < windowStart) firstIndex++;

        long first = ts.get(firstIndex);
        long duration = newest - first;
        int intervals = ts.size() - 1 - firstIndex;
        if (intervals < 2 || duration < 120_000_000L) return -1;

        double fps = intervals * 1_000_000_000.0 / duration;
        if (!Double.isFinite(fps) || fps < 1.0 || fps > 360.0) return -1;
        return (int) Math.round(fps);
    }

    private void invalidateFpsTarget(String reason) {
        cachedLayer = null;
        cachedLayerAtMs = 0;
        consecutiveFpsFailures = 0;
        if (fpsView != null) fpsView.setText("FPS …");
        writeFpsDiagnostics(reason + " • reacquiring game layer", "", cachedPackage, "", -1, false);
    }

    private void writeFpsDiagnostics(String status, String method, String pkg, String layer,
                                     int fps, boolean approximate) {
        String safeLayer = layer == null ? "" : layer;
        if (safeLayer.length() > 180) safeLayer = safeLayer.substring(0, 180);
        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                .putString(GamingPrefs.FPS_DIAG_STATUS, status == null ? "" : status)
                .putString(GamingPrefs.FPS_DIAG_METHOD, method == null ? "" : method)
                .putString(GamingPrefs.FPS_DIAG_PACKAGE, pkg == null ? "" : pkg)
                .putString(GamingPrefs.FPS_DIAG_LAYER, safeLayer)
                .putInt(GamingPrefs.FPS_LAST_VALUE, fps)
                .putBoolean(GamingPrefs.FPS_APPROXIMATE, approximate)
                .apply();
    }

    private String stripExit(String value) {
        if (value == null) return "";
        return value.replaceAll("(?m)^\\[exit=\\d+\\]$", "").trim();
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private String shellQuoteBare(String value) {
        return shellQuote(value);
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Throwable ignored) { }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "VPQCLAN Gaming Tools",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("FPS and battery-temperature overlay");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("VPQCLAN Gaming Tools")
                .setContentText("Performance HUD is available")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("VPQCLAN Gaming Tools")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
        nm.notify(NOTIFICATION_ID, n);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class LayerCandidate {
        final String layer;
        final int score;

        LayerCandidate(String layer, int score) {
            this.layer = layer;
            this.score = score;
        }
    }

    private static final class FpsSample {
        final int fps;
        final boolean approximate;
        final String method;
        final String pkg;
        final String layer;
        final String status;

        FpsSample(int fps, boolean approximate, String method, String pkg, String layer, String status) {
            this.fps = fps;
            this.approximate = approximate;
            this.method = method;
            this.pkg = pkg;
            this.layer = layer;
            this.status = status;
        }

        static FpsSample none(String status) {
            return new FpsSample(-1, false, "", "", "", status);
        }
    }
}
