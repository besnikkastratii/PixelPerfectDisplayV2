package com.besnik.pixelperfect;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/** Starts the gaming service when a USB device is attached and Auto USB Fix is enabled. */
public class UsbAudioReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.hardware.usb.action.USB_DEVICE_ATTACHED".equals(intent.getAction())) {
            return;
        }

        SharedPreferences sp = context.getSharedPreferences(GamingPrefs.PREFS, Context.MODE_PRIVATE);
        if (!sp.getBoolean(GamingPrefs.AUTO_USB_FIX, false)) return;

        Intent service = new Intent(context, PerfOverlayService.class);
        service.setAction(PerfOverlayService.ACTION_USB_FIX_NOW);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (Throwable ignored) { }
    }
}
