package com.besnik.pixelperfect;

public final class GamingPrefs {
    public static final String PREFS = "vpqclan_gaming_tools_v43";

    public static final String FPS_ENABLED = "fps_enabled";
    public static final String BATTERY_TEMP_ENABLED = "battery_temp_enabled";
    public static final String FPS_X = "fps_x";
    public static final String FPS_Y = "fps_y";
    public static final String BAT_X = "bat_x";
    public static final String BAT_Y = "bat_y";
    public static final String LOCK_OVERLAYS = "lock_overlays";
    public static final String AUTO_USB_FIX = "auto_usb_fix";

    private GamingPrefs() { }
}
