package com.besnik.pixelperfect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import rikka.shizuku.Shizuku;

/**
 * Foreground service for lightweight gaming overlays.
 * FPS is derived from SurfaceFlinger presentation timestamps through Shizuku.
 * Temperature is Android battery temperature (BatteryManager), never CPU temperature.
 */
public class PerfOverlayService extends Service {
    public static final String ACTION_REFRESH = "com.besnik.pixelperfect.action.REFRESH_HUD";
    public static final String ACTION_USB_FIX_NOW = "com.besnik.pixelperfect.action.USB_FIX_NOW";

    private static final String CHANNEL_ID = "vpqclan_gaming_tools";
    private static final int NOTIFICATION_ID = 4303;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private TextView fpsView;
    private TextView batteryView;
    private WindowManager.LayoutParams fpsParams;
    private WindowManager.LayoutParams batteryParams;
    private IUserService shellService;
    private boolean binding;
    private boolean pendingUsbFix;

    private long lastFpsSampleMs;
    private long lastBatterySampleMs;
    private boolean fpsReadInFlight;

    private final Shizuku.UserServiceArgs serviceArgs = new Shizuku.UserServiceArgs(
            new ComponentName(BuildConfig.APPLICATION_ID, UserService.class.getName()))
            .daemon(false)
            .processNameSuffix("vpq-hud-v43")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
            .tag("vpq-hud-v43");

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            binding = false;
            if (binder != null && binder.pingBinder()) {
                shellService = IUserService.Stub.asInterface(binder);
                if (pendingUsbFix) {
                    pendingUsbFix = false;
                    UsbAudioFixer.applyFix(PerfOverlayService.this, shellService);
                    updateNotification("USB audio fix applied");
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            binding = false;
            shellService = null;
        }
    };

    private final Runnable updater = new Runnable() {
        @Override
        public void run() {
            syncOverlayViews();
            updateBatteryOverlay();
            updateFpsOverlayIfDue();
            main.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        bindShizukuIfPossible();
        syncOverlayViews();
        main.post(updater);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        bindShizukuIfPossible();
        if (intent != null && ACTION_USB_FIX_NOW.equals(intent.getAction())) {
            // Normal Android media volume is raised immediately. If Shizuku has not bound
            // yet, repeat the USB-device-specific part as soon as the shell arrives.
            UsbAudioFixer.applyFix(this, shellService);
            if (shellService == null) pendingUsbFix = true;
            updateNotification("USB audio fix requested");
        }
        syncOverlayViews();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(updater);
        removeOverlay(fpsView);
        removeOverlay(batteryView);
        fpsView = null;
        batteryView = null;
        try {
            Shizuku.unbindUserService(serviceArgs, connection, true);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void bindShizukuIfPossible() {
        if (shellService != null || binding) return;
        try {
            if (!Shizuku.pingBinder()) return;
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return;
            binding = true;
            Shizuku.bindUserService(serviceArgs, connection);
        } catch (Throwable t) {
            binding = false;
        }
    }

    private void syncOverlayViews() {
        if (!Settings.canDrawOverlays(this)) {
            removeOverlay(fpsView);
            removeOverlay(batteryView);
            fpsView = null;
            batteryView = null;
            return;
        }

        SharedPreferences sp = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE);
        boolean fpsEnabled = sp.getBoolean(GamingPrefs.FPS_ENABLED, false);
        boolean batteryEnabled = sp.getBoolean(GamingPrefs.BATTERY_TEMP_ENABLED, false);
        boolean locked = sp.getBoolean(GamingPrefs.LOCK_OVERLAYS, false);

        if (fpsEnabled && fpsView == null) {
            fpsView = createHudText("FPS --");
            fpsParams = createParams(
                    sp.getInt(GamingPrefs.FPS_X, dp(10)),
                    sp.getInt(GamingPrefs.FPS_Y, dp(34)));
            installDrag(fpsView, fpsParams, GamingPrefs.FPS_X, GamingPrefs.FPS_Y);
            windowManager.addView(fpsView, fpsParams);
        } else if (!fpsEnabled && fpsView != null) {
            removeOverlay(fpsView);
            fpsView = null;
            fpsParams = null;
        }

        if (batteryEnabled && batteryView == null) {
            batteryView = createHudText("BAT --.-°C");
            batteryParams = createParams(
                    sp.getInt(GamingPrefs.BAT_X, dp(10)),
                    sp.getInt(GamingPrefs.BAT_Y, dp(72)));
            installDrag(batteryView, batteryParams, GamingPrefs.BAT_X, GamingPrefs.BAT_Y);
            windowManager.addView(batteryView, batteryParams);
        } else if (!batteryEnabled && batteryView != null) {
            removeOverlay(batteryView);
            batteryView = null;
            batteryParams = null;
        }

        updateTouchThrough(fpsView, fpsParams, locked);
        updateTouchThrough(batteryView, batteryParams, locked);
    }

    private TextView createHudText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13f);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xA61A1A1A);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0x66FFFFFF);
        view.setBackground(bg);
        view.setElevation(dp(4));
        return view;
    }

    private WindowManager.LayoutParams createParams(int x, int y) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        return p;
    }

    private void installDrag(View view, WindowManager.LayoutParams params, String xKey, String yKey) {
        view.setOnTouchListener(new View.OnTouchListener() {
            int startX;
            int startY;
            float downX;
            float downY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean locked = getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE)
                        .getBoolean(GamingPrefs.LOCK_OVERLAYS, false);
                if (locked) return false;

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + Math.round(event.getRawX() - downX);
                        params.y = startY + Math.round(event.getRawY() - downY);
                        try { windowManager.updateViewLayout(v, params); } catch (Throwable ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences(GamingPrefs.PREFS, MODE_PRIVATE).edit()
                                .putInt(xKey, params.x)
                                .putInt(yKey, params.y)
                                .apply();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void updateTouchThrough(View view, WindowManager.LayoutParams params, boolean locked) {
        if (view == null || params == null) return;
        int desired = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (locked) desired |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (params.flags != desired) {
            params.flags = desired;
            try { windowManager.updateViewLayout(view, params); } catch (Throwable ignored) { }
        }
    }

    private void updateBatteryOverlay() {
        if (batteryView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastBatterySampleMs < 1500) return;
        lastBatterySampleMs = now;
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) {
            batteryView.setText("BAT --.-°C");
            return;
        }
        int tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        if (tenths == Integer.MIN_VALUE) {
            batteryView.setText("BAT --.-°C");
        } else {
            batteryView.setText(String.format(Locale.US, "BAT %.1f°C", tenths / 10f));
        }
    }

    private void updateFpsOverlayIfDue() {
        if (fpsView == null) return;
        long now = System.currentTimeMillis();
        if (now - lastFpsSampleMs < 900 || fpsReadInFlight) return;
        lastFpsSampleMs = now;

        IUserService service = shellService;
        if (service == null) {
            bindShizukuIfPossible();
            fpsView.setText("FPS --");
            return;
        }

        fpsReadInFlight = true;
        new Thread(() -> {
            int fps = readActiveGameFps(service);
            main.post(() -> {
                fpsReadInFlight = false;
                if (fpsView != null) fpsView.setText(fps > 0 ? "FPS " + fps : "FPS --");
            });
        }, "VPQ-FPS").start();
    }

    private int readActiveGameFps(IUserService service) {
        try {
            String layers = service.exec("dumpsys SurfaceFlinger --list");
            String layer = chooseGameLayer(layers);
            if (layer == null) return -1;
            String latency = service.exec("dumpsys SurfaceFlinger --latency " + shellQuote(layer));
            return parseFps(latency);
        } catch (Throwable t) {
            return -1;
        }
    }

    private String chooseGameLayer(String output) {
        if (output == null) return null;
        String[] packageHints = {
                "com.tencent.ig", "com.pubg.imobile", "com.vng.pubgmobile",
                "com.rekoo.pubgm", "com.pubg.krmobile", "pubg"
        };
        String[] lines = output.split("\\n");
        List<String> matches = new ArrayList<>();
        for (String raw : lines) {
            String line = raw.trim();
            String lower = line.toLowerCase(Locale.US);
            for (String hint : packageHints) {
                if (lower.contains(hint.toLowerCase(Locale.US))) {
                    matches.add(line);
                    break;
                }
            }
        }
        if (matches.isEmpty()) return null;
        for (String match : matches) {
            if (match.contains("SurfaceView") || match.toLowerCase(Locale.US).contains("blast")) {
                return match;
            }
        }
        return matches.get(0);
    }

    private int parseFps(String raw) {
        if (raw == null) return -1;
        String[] lines = raw.trim().split("\\n");
        if (lines.length < 3) return -1;

        List<Long> timestamps = new ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            String[] p = lines[i].trim().split("\\s+");
            if (p.length < 2) continue;
            try {
                long presented = Long.parseLong(p[1]);
                if (presented > 0 && presented < Long.MAX_VALUE / 4) timestamps.add(presented);
            } catch (Throwable ignored) { }
        }
        if (timestamps.size() < 2) return -1;

        long newest = timestamps.get(timestamps.size() - 1);
        long start = newest - 1_000_000_000L;
        int count = 0;
        for (long ts : timestamps) if (ts >= start && ts <= newest) count++;
        if (count <= 1) return -1;

        // Count frame intervals rather than raw timestamps.
        int fps = count - 1;
        return Math.max(1, Math.min(300, fps));
    }

    private String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Throwable ignored) { }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "VPQCLAN Gaming Tools",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("FPS and battery-temperature overlay");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("VPQCLAN Gaming Tools")
                .setContentText("Performance HUD is available")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("VPQCLAN Gaming Tools")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
        nm.notify(NOTIFICATION_ID, n);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
