# VPQCLAN C.R V4.3

VPQCLAN Custom Resolution for Android / REDMAGIC gaming setups.

## V4.3 additions

- VPQCLAN Kosovo + Albania battle-royale wallpaper in the app at ~25% opacity.
- Matching VPQCLAN crest launcher icon.
- FPS overlay powered by SurfaceFlinger frame presentation data through Shizuku.
- Battery-temperature overlay using Android's battery temperature sensor value (not CPU temperature).
- FPS and battery overlays can be enabled independently.
- Separate draggable positions, defaulting to the top-left.
- Lock mode makes overlay windows touch-through for gameplay.
- USB Audio Fix for the HyperX Cloud II USB sound card / USB audio route.
- Optional automatic USB audio fix when a USB device is attached.

## Existing features retained

- Elegant preset/profile UI.
- Saved custom profiles with custom names and delete support.
- Navigation Safe automatic DPI calculation with 15-second rollback.
- Physical monitor mode controls separated from forced logical external output.
- Custom external logical resolution and density.
- Shizuku-backed privileged display commands.

## Important FPS behavior

The FPS widget intentionally displays `FPS --` if a PUBG SurfaceFlinger layer cannot be found. It does not substitute monitor refresh rate and call that FPS.

## Battery temperature

Temperature comes from Android `BatteryManager.EXTRA_TEMPERATURE`; no CPU thermal-zone value is used.

## Build

Requires JDK 17, Android SDK 36 and Gradle 8.11.1.

```bash
gradle :app:assembleDebug
```
