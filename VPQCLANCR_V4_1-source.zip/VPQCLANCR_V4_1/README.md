# VPQCLAN C.R V4.1

Patch release for monitor-output handling.

## What changed

- Physical monitor mode and forced logical output are now separate.
- **Apply Physical Mode** only requests a real mode from the monitor's supported-mode list.
- **Force Logical Output** uses Android's logical external-display override (`wm size -d <displayId>`).
- Forcing a logical output no longer changes the selected physical refresh rate.
- Applying a physical mode no longer resets the forced logical width/height.
- Added **Reset Forced Output**.
- Added a live status line after monitor changes.
- The forced logical command verifies `wm size` and `wm density` after applying.
- Existing saved-profile system and elegant V4 UI are retained.

Branding:
- App: **VPQCLAN C.R**
- Banner: **VPQCLAN Custom Resolution**
- Footer: **This App is part of VPQCLAN, made by VPQ SNIKA**
