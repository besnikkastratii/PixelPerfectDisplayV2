# VPQCLAN C.R V4.2

Navigation-safe phone resolution patch built on V4.1.

## New in V4.2

- Added **Navigation Safe • auto DPI** to Game View and enabled it by default.
- Reads the phone's real `Physical size` and `Physical density` through Shizuku.
- Calculates safe DPI from the physical short edge:
  `safe DPI = physical DPI × target short edge / physical short edge`.
- Applies phone logical size + calculated DPI + automatic scaling together.
- Manual DPI remains available when Navigation Safe is switched off.
- Navigation Safe state is saved inside custom profiles.
- Existing V4/V4.1 profiles remain compatible and default to Navigation Safe ON.
- Navigation Safe phone changes use the existing 15-second safety rollback.
- Phone rollback restores only the phone size/density and does not touch its preferred physical display mode.
- V4.1 physical monitor mode and forced logical external output remain separate.

Branding:
- App: **VPQCLAN C.R**
- Banner: **VPQCLAN Custom Resolution**
- Footer: **This App is part of VPQCLAN, made by VPQ SNIKA**
